-- MariaDB dump 10.17  Distrib 10.4.14-MariaDB, for Win64 (AMD64)
--
-- Host: 103.199.168.69    Database: irrigation_scheme_service
-- ------------------------------------------------------
-- Server version	10.1.38-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `deep_tubewell_yearly_final_report`
--

DROP TABLE IF EXISTS `deep_tubewell_yearly_final_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deep_tubewell_yearly_final_report` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `pump_id` bigint(20) unsigned NOT NULL,
  `division_id` bigint(20) unsigned NOT NULL,
  `district_id` bigint(20) unsigned NOT NULL,
  `upazilla_id` bigint(20) unsigned NOT NULL,
  `union_id` bigint(20) unsigned NOT NULL,
  `report_type_id` int(11) NOT NULL,
  `mouza_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mouza_no_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jl_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jl_no_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plot_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plot_no_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `install_date_of_excavation` date DEFAULT NULL,
  `install_date_of_commission` date DEFAULT NULL,
  `install_accepted_participation` double DEFAULT NULL,
  `rehab_date_of_excavation` date DEFAULT NULL,
  `rehab_date_of_commission` date DEFAULT NULL,
  `rehab_accepted_participation` double DEFAULT NULL,
  `project_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `project_name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `operator_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `operator_name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deep_tube_well_nature` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deep_tube_well_nature_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ms` double DEFAULT NULL,
  `fg` double DEFAULT NULL,
  `updc` double DEFAULT NULL,
  `filter_ms` double DEFAULT NULL,
  `filter_fg` double DEFAULT NULL,
  `filter_updc` double DEFAULT NULL,
  `dia` double DEFAULT NULL,
  `amount` double(8,2) DEFAULT NULL,
  `vertical_make_o_model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vertical_power` double DEFAULT NULL,
  `vertical_unit_consumption` double DEFAULT NULL,
  `turbine_make_o_model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `turbine_power` double DEFAULT NULL,
  `turbine_unit_consumption` double DEFAULT NULL,
  `head` double DEFAULT NULL,
  `discharge` double DEFAULT NULL,
  `command_area` double DEFAULT NULL,
  `kharif_1_aus` double DEFAULT NULL,
  `kharif_1_others` double DEFAULT NULL,
  `kharif_1_total` double DEFAULT NULL,
  `kharif_2_aman` double DEFAULT NULL,
  `kharif_2_others` double DEFAULT NULL,
  `kharif_2_total` double DEFAULT NULL,
  `borou` double DEFAULT NULL,
  `wheat` double DEFAULT NULL,
  `potato` double DEFAULT NULL,
  `corn` double DEFAULT NULL,
  `mustard` double DEFAULT NULL,
  `lentils` double DEFAULT NULL,
  `vegetables` double DEFAULT NULL,
  `robi_total` double DEFAULT NULL,
  `actual` double DEFAULT NULL,
  `barga` double DEFAULT NULL,
  `beneficial_farmer_total` double(8,2) DEFAULT NULL,
  `start_reading` double DEFAULT NULL,
  `end_reading` double DEFAULT NULL,
  `total_uses_unit` double(8,2) DEFAULT NULL,
  `hourly_used_unit` double DEFAULT NULL,
  `total_active_hour` double(8,2) DEFAULT NULL,
  `hourly_irri_charge` double DEFAULT NULL,
  `recoverable_irri_payment` double DEFAULT NULL,
  `collected_irri_payment` double DEFAULT NULL,
  `unpaid_money` double DEFAULT NULL,
  `total_electricity_cost` double DEFAULT NULL,
  `operator_salary` double DEFAULT NULL,
  `maintance_cost` double DEFAULT NULL,
  `other_cost` double DEFAULT NULL,
  `total_cost` double(8,2) DEFAULT NULL,
  `total_income` double(8,2) DEFAULT NULL,
  `ganku_details` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ganku_details_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `super_v_mechanic` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `super_v_mechanic_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `super_v_higher_engr` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `super_v_higher_engr_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `kharif_1_aus_per_hector_cost` double NOT NULL,
  `kharif_2_aman_per_hector_cost` double NOT NULL,
  `borou_per_hector_cost` double NOT NULL,
  `wheat_per_hector_cost` double NOT NULL,
  `potato_per_hector_cost` double NOT NULL,
  `vegetables_per_hector_cost` int(11) NOT NULL,
  `corn_per_hector_cost` double NOT NULL,
  `mustard_per_hector_cost` double NOT NULL,
  `lentils_per_hector_cost` double NOT NULL,
  `other_scheme_area` double NOT NULL,
  `llp_expense` double NOT NULL,
  `pontoon_expense` double NOT NULL,
  `kharif_1_llp` double NOT NULL,
  `kharif_2_llp` double NOT NULL,
  `robi_llp` double NOT NULL,
  `kharif_1_total_gonku` double DEFAULT NULL,
  `kharif_2_total_gonku` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`,`org_id`,`pump_id`,`division_id`,`district_id`,`upazilla_id`,`union_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deep_tubewell_yearly_final_report`
--

LOCK TABLES `deep_tubewell_yearly_final_report` WRITE;
/*!40000 ALTER TABLE `deep_tubewell_yearly_final_report` DISABLE KEYS */;
INSERT INTO `deep_tubewell_yearly_final_report` VALUES (20,3,25,2,16,143,1294,1,'10',NULL,'12',NULL,'60',NULL,'2021-03-01','2021-03-02',47,'2021-03-02','2021-03-02',34,'Megan Church',NULL,'Jameson Holcomb',NULL,'Mollit mollit eum et',NULL,22,44,4,50,55,14,12,672.00,'Accusamus consequatu',51,65,'Officia molestiae pr',47,33,3,25,45,46,34,61,43,94,56,77,17,65,49,47,7,78,17,72,76,54.00,38,96,29.00,7,37.00,70,3,6,85,61,73,15,53,74.00,578.00,'Suscipit optio obca',NULL,'Whoopi Sykes',NULL,'Zorita Frost',NULL,'Ea deserunt ex conse',NULL,0,NULL,NULL,'2021-03-28 05:00:34','2021-03-28 05:00:34',23,43,5,19,72,34,50,78,6,1,85,36,50,38,83,83,37),(21,3,24,2,16,143,1292,1,'3',NULL,'10',NULL,'5',NULL,'2021-03-01','2021-03-02',59,'2021-03-04','2021-03-05',11,'Lenore Delaney',NULL,'Elmo Glass',NULL,'Exercitationem imped',NULL,53,50,77,80,65,50,24,939.00,'Reprehenderit volupt',70,58,'Vitae aut repellendu',21,71,50,49,94,94,87,80,46,52,59,33,37,75,82,4,1,38,47,71,54,77.00,99,63,43.00,56,41.00,59,92,22,16,76,87,31,31,60.00,495.00,'Delectus pariatur ',NULL,'Daniel Bell',NULL,'Patience Dudley',NULL,'Et quia eligendi asp',NULL,0,NULL,NULL,'2021-03-28 05:01:41','2021-03-28 05:01:41',55,27,81,76,66,50,11,85,14,17,42,31,47,44,85,5,42);
/*!40000 ALTER TABLE `deep_tubewell_yearly_final_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_app_payment_refunds_deducts`
--

DROP TABLE IF EXISTS `far_app_payment_refunds_deducts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_app_payment_refunds_deducts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `application_id` bigint(20) unsigned NOT NULL,
  `payment_id` int(10) unsigned DEFAULT NULL,
  `farmer_id` bigint(20) unsigned DEFAULT NULL,
  `master_payment_id` bigint(20) unsigned DEFAULT NULL,
  `application_type_id` bigint(20) unsigned NOT NULL,
  `payment_type_id` bigint(20) unsigned DEFAULT NULL,
  `refund_amount` double(8,2) DEFAULT NULL,
  `refund_balance` double(8,2) DEFAULT NULL,
  `amount_paid` double(8,2) DEFAULT NULL,
  `previously_deducted` double(8,2) DEFAULT NULL,
  `previously_refunded` double(8,2) DEFAULT NULL,
  `present_balance` double(8,2) DEFAULT NULL,
  `deduction_amount` double(8,2) DEFAULT NULL,
  `balance_after_deduction` double(8,2) DEFAULT NULL,
  `refunding_to` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `refund_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '1=Bkash,2=Rocket,3=Bank,4=Cash',
  `account_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `operation_type` int(11) NOT NULL DEFAULT '0' COMMENT '1=refund, 2=deduct',
  `operation_date` date NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_app_payment_refunds_deducts`
--

LOCK TABLES `far_app_payment_refunds_deducts` WRITE;
/*!40000 ALTER TABLE `far_app_payment_refunds_deducts` DISABLE KEYS */;
INSERT INTO `far_app_payment_refunds_deducts` VALUES (25,3,8,10,13,11,4,2,5.00,5.00,300.00,NULL,0.00,295.00,NULL,NULL,NULL,'01723019011','2','14412700000726','sdfsdf','Test farmer name',1,'2021-03-30',1,1,'2021-03-07 04:31:48','2021-03-07 04:31:48'),(26,3,7,8,13,10,4,1,10.00,10.00,500.00,NULL,0.00,490.00,NULL,NULL,NULL,'01723019011','1','14412700000726','fsdgdfg','Test farmer name',1,'2021-03-18',1,1,'2021-03-07 04:32:00','2021-03-07 04:32:00'),(27,3,8,10,13,11,4,2,14.00,19.00,300.00,NULL,5.00,281.00,NULL,NULL,NULL,'01723019011','2','14412700000726','werwerwe','Test farmer name',1,'2021-03-31',1,1,'2021-03-07 06:05:11','2021-03-07 06:05:11'),(28,3,7,8,13,10,4,1,90.00,100.00,500.00,NULL,10.00,400.00,NULL,NULL,NULL,'01723019011','2','4565465654654','werewrwerwe','Test farmer name',1,'2021-03-23',1,1,'2021-03-07 06:05:33','2021-03-07 06:05:33'),(29,3,4,4,12,10,4,1,NULL,NULL,500.00,0.00,NULL,480.00,20.00,20.00,NULL,'undefined',NULL,'14412700000726','ertertetet',NULL,2,'2021-03-24',1,1,'2021-03-07 06:05:47','2021-03-07 06:05:47'),(30,3,7,8,13,10,4,1,NULL,NULL,500.00,NULL,NULL,350.00,50.00,50.00,NULL,'01723019011',NULL,'14412700000726','ewrfgsd',NULL,2,'2021-03-15',1,1,'2021-03-07 06:07:50','2021-03-07 06:07:50'),(31,3,8,10,13,11,4,2,200.00,219.00,300.00,NULL,14.00,81.00,NULL,NULL,NULL,'01723019011','2','14412700000726','fghgfhfghf','Test farmer name',1,'2021-03-29',1,1,'2021-03-07 06:11:16','2021-03-07 06:11:16'),(32,3,8,10,13,11,4,2,NULL,NULL,300.00,NULL,NULL,1.00,80.00,80.00,NULL,'01723019011',NULL,'14412700000726','fghfgh',NULL,2,'2021-03-23',1,1,'2021-03-07 06:11:37','2021-03-07 06:11:37'),(33,3,7,8,13,10,4,1,100.00,200.00,500.00,NULL,NULL,250.00,NULL,NULL,NULL,'01723019011','1','01723019011','test','Test farmer name',1,'2021-03-07',1,1,'2021-03-07 07:09:02','2021-03-07 07:09:02'),(34,3,4,4,12,10,4,1,100.00,100.00,500.00,NULL,NULL,380.00,NULL,NULL,NULL,'undefined','1','01723019011','test','Ruhul',1,'2021-03-07',1,1,'2021-03-07 07:14:24','2021-03-07 07:14:24'),(35,3,4,4,12,10,4,1,10.00,110.00,500.00,NULL,100.00,370.00,NULL,NULL,NULL,'undefined','1','01723019011','test','Ruhul',1,'2021-03-07',1,1,'2021-03-07 07:14:47','2021-03-07 07:14:47'),(36,3,4,4,12,10,4,1,NULL,NULL,500.00,NULL,NULL,355.00,15.00,35.00,NULL,'undefined',NULL,'01723019011','test',NULL,2,'2021-03-07',1,1,'2021-03-07 07:15:09','2021-03-07 07:15:09'),(37,3,8,10,13,11,4,2,1.00,220.00,300.00,NULL,NULL,0.00,NULL,NULL,NULL,'01723019011','2','2','122','Test farmer name',1,'2021-03-31',1,1,'2021-03-07 01:45:12','2021-03-07 01:45:12'),(38,3,3,3,12,10,4,1,6000.00,6000.00,500.00,NULL,0.00,-5500.00,NULL,NULL,NULL,'undefined','1','20','sunny test','Ruhul',1,'2021-03-28',1,1,'2021-03-07 01:53:05','2021-03-07 01:53:05'),(39,3,38,164,14,NULL,1,3,100.00,100.00,900.00,NULL,0.00,800.00,NULL,NULL,NULL,'1723019023','1','01723019011','test reason','Suman ',1,'2021-03-07',1,1,'2021-03-07 10:57:01','2021-03-07 10:57:01'),(40,3,38,164,14,NULL,1,3,NULL,NULL,900.00,NULL,NULL,678.00,122.00,122.00,NULL,'1723019023',NULL,'123','123',NULL,2,'2021-03-09',1,1,'2021-03-09 00:56:51','2021-03-09 00:56:51'),(41,3,38,164,14,NULL,1,3,1.00,101.00,900.00,NULL,NULL,677.00,NULL,NULL,NULL,'1723019023','1','2','88','Suman ',1,'2021-03-09',1,1,'2021-03-09 00:57:07','2021-03-09 00:57:07'),(42,3,38,164,14,NULL,1,3,NULL,NULL,900.00,NULL,NULL,676.00,1.00,123.00,NULL,'1723019023',NULL,'2','123',NULL,2,'2021-03-09',1,1,'2021-03-09 00:57:19','2021-03-09 00:57:19'),(43,3,38,164,14,NULL,1,3,NULL,NULL,900.00,1.00,NULL,600.00,76.00,199.00,NULL,'1723019023',NULL,'01723019011','test deduct reason',NULL,2,'2021-03-10',1,1,'2021-03-10 08:06:54','2021-03-10 08:06:54'),(44,3,3,6,19,0,4,1,20.00,20.00,40.00,NULL,0.00,20.00,NULL,NULL,NULL,'01723019011','1','5706907256','test check','Md Mamunur Rashid',1,'2021-03-02',1,1,'2021-03-21 05:22:01','2021-03-21 05:22:01');
/*!40000 ALTER TABLE `far_app_payment_refunds_deducts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_basic_infos`
--

DROP TABLE IF EXISTS `far_basic_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_basic_infos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `farmer_id` bigint(20) unsigned NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attachment` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name_bn` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `gender` int(11) DEFAULT '1',
  `father_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `father_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nid` bigint(20) unsigned NOT NULL,
  `far_division_id` bigint(20) unsigned NOT NULL,
  `far_district_id` bigint(20) unsigned NOT NULL,
  `far_upazilla_id` bigint(20) unsigned NOT NULL,
  `far_union_id` bigint(20) unsigned NOT NULL,
  `far_village` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `far_village_bn` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1=draft, 2=final save',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_basic_infos`
--

LOCK TABLES `far_basic_infos` WRITE;
/*!40000 ALTER TABLE `far_basic_infos` DISABLE KEYS */;
INSERT INTO `far_basic_infos` VALUES (1,145,'farmer3@gmail.com',NULL,'','Test Farmer Name ','পরীক্ষার কৃষকের নাম',1,'test father name','test father name bn','test mother name','test mother name bn',52212121212424,19,71,495,4543,'test village','test village bn',2,'2021-02-24 07:34:40','2021-02-24 07:34:40'),(2,9,'nadim.syntech@gmail.com',NULL,'','Nadim','Nadim',1,'ddddd','ccccc','dddd','ccccc',11111111,6,47,365,3271,'dddd','cccccc',2,'2021-02-24 03:17:55','2021-02-24 03:18:14'),(3,11,'biswas862@gmail.com','018844453300','','limon','লিমন',1,'Md litu biswas','Md litu biswas','abcd','abcd',87023619999,6,51,389,3557,'chandibardi','চন্দিবরদী',2,'2021-02-25 14:24:52','2021-03-06 00:35:55'),(4,12,'ruhul@gmail.com','01843867772','1616921182.jpg','Ruhul','রুহুল',1,'Abdur Rahman','আব্দুর রহমান','Asiya Begum','আছিয়া বেগম',12121212121,1,1,4,51,'Islabari','করোটা',2,'2021-03-01 04:32:27','2021-03-28 08:46:22'),(5,13,'farmer3@gmail.com','01723019011','','Test farmer name','Test farmer name bn',1,'test father name','test father name bn','test mother name','test mother name bn',1425472454,1,1,1,1,'Test village ','Test village bn',2,'2021-03-02 05:06:40','2021-03-02 05:06:40'),(6,14,'suman@gmail.com','1723019023','','Suman ','Suman bn',1,'MD.Rafiqul Islam','মোঃ রফিকুল ইসলাম','Shahanara Begum','শাহানারা বেগম',5641238745,1,1,1,1,'Sreemontapur','শ্রীমন্তপুর',2,'2021-03-02 05:12:15','2021-03-02 05:12:15'),(7,19,'mamunur@gmail.com','01730233032','','Md Mamunur Rashid','মোঃ মামুনুর রশিদ',1,'Md Mijanur Rashman','মোঃ মিজানুর রহমান','Most Lucky Begum','লাকি বেগম',73438483043,7,60,452,4155,'Debalaya','দেবালয়1',2,'2021-03-02 09:33:30','2021-03-23 06:55:01'),(8,44,'ismail.khan.sunny@gmail.com','01723019011','','Sunny Khan','Sunny Khan',1,'shamsuddin khan','shamsuddin khan','suriya begum','suriya begum',111111111,1,1,1,1,'dhaka','dhaka',2,'2021-03-02 23:06:14','2021-03-02 23:06:14'),(9,46,'badc@gmail.com','01723019011','','BADC User','BADC User bn',1,'Badc Father','Badc Father bn','Badc Mother','Badc Mother bn',45748540584,1,1,1,1,'Badc village','Badc village bn',2,'2021-03-03 09:56:38','2021-03-03 09:56:38'),(10,47,'tests@gmail.com','01723019011','','Test Admin 12','Test Admin 12 Bn',1,'shamsuddin khan','shamsuddin khan','suriya begum','suriya begum',1111111111,1,1,1,1,'dhaka','dhaka',2,'2021-03-03 03:57:34','2021-03-03 03:57:34'),(11,48,'d@gmail.com','1723019023','','d','অজানা নাম',1,'d','d','d','d',1346587,6,47,365,3271,'d','d',2,'2021-03-03 10:39:00','2021-03-03 10:39:00'),(12,27,'test@gmail.com','01723019011','','test  rg','অজানা নাম',1,'2','shamsuddin khan','2','suriya begum',1,1,1,1,1,'3','1',2,'2021-03-03 22:04:21','2021-03-03 22:04:21'),(13,17,'mamun@gmail.com','undefined','','Md Mamunur Rashid','মামুনুর রশিদ',1,'Md Mijanur Rahman','মোঃ মামুনুর রশিদ','Most Lucky Begum','মোছাঃ লাকি বেগম',37848394739,1,1,1,1,'Dabalay','দেবালয়',2,'2021-03-03 23:34:49','2021-03-03 23:34:49'),(14,52,'bmda@gmail.com','01723019011','','Md BMDA','এমডি বিএমডিএ',1,'Md Father','বিএমডিএ','Most Mother','Md BMDA',4574859495,1,1,1,1,'এমডি বিএমডিএ','বিএমডিএ',2,'2021-03-04 06:34:47','2021-03-04 06:34:47'),(15,55,'qatestfarmer@yopmail.com','undefined','','QA Test Farmer','QA Test Farmer Bn',1,'QA Test Farmer Father','QA Test Farmer Father','QA Test Farmer Mother','QA Test Farmer Mother',55435435,10,65,492,4541,'QA Test village','QA Test Village Bn',2,'2021-03-04 00:52:49','2021-03-04 00:52:49'),(16,62,'nadim.syntech@gmail.com','01791894967','','Nadim Mridha','Nadim Mridha',1,'rty','fg','trhyth','ythtrh',1223,4,31,239,2172,'trtr','fd',2,'2021-03-04 11:21:47','2021-03-04 11:21:48'),(17,18,'limon@gmail.com','01723019011','','limon','লিমন',1,'Md litu biswas','Md litu biswas','abcd','abcd',8702361199,6,51,389,3557,'chandibardi','চন্দিবরদী',2,'2021-03-05 23:14:30','2021-03-05 23:14:30'),(18,28,'badcfarmer@gmail.com','01791894967','','BADC Farmer','বিএডিসি কৃষক ',1,'Abul Kashem','Abul Kashem','Safia','Safia',1234,6,47,365,3271,'dff','dff',1,'2021-03-05 23:49:22','2021-03-05 23:49:22'),(19,29,'bmdafarmer@gmail.com','01723019011','','BMDA Farmer','বিএমডিএ কৃষক ',1,'Abul Kashem','Abul Kashem','Safia','Safia',1234,2,15,139,1250,'dff','dff',1,'2021-03-05 23:56:59','2021-03-05 23:56:59'),(20,35,'badcfarmer@gmail.com','01723019012','','BADC Farmer','BADC Farmer',1,'Abul Kashem','Abul Kashem','Safia','Safia',11111111,6,47,365,3271,'dff','dff',2,'2021-03-06 00:43:07','2021-03-06 00:43:53'),(21,20,'mamunur@gmail.com','01723019011','','Md Mamunur Rashid','মোঃ মামুনুর রশিদ',1,'Md Mijanur Rashman','মোঃ মিজানুর রহমান','Most Lucky Begum','লাকি বেগম',73438483043,7,60,452,4155,'Debalaya','দেবালয়',1,'2021-03-06 07:21:08','2021-03-06 07:21:08'),(22,103,'admin11@gmail.com','01723019011','','Admin11','অ্যাডমিন11',1,'Freya Jefferson','Emi Steele','Yvonne Huber','Francis Barlow',66655656546,1,1,1,1,'Est doloremque faci','sadsadsad lorem m',2,'2021-03-07 10:53:41','2021-03-07 10:53:50'),(39,182,'mamrr3rrrun@gmail.com',NULL,'','Md Mamun Test','Md Mamun test bn',1,'Mamuns Fathers','Mamuns Fathers Bn','Mamun Mothers',' Mamun Mother bn',23434343,1,1,1,1,' vill name','vill name bn',0,'2021-03-10 06:54:58','2021-03-10 06:54:58'),(41,184,'mamrrvvvccvv3rrrun@gmail.com','01990185993','','Md Mamun bbbTest','Md Mambbbun test bn',1,'Mamuns Fathers','Mamuns Fathers Bn','Mamun Mothers',' Mamun Mother bn',40549,1,1,1,1,' vill name','vill name bn',1,'2021-03-10 07:16:50','2021-03-10 07:16:50'),(42,185,'maymuna@gmail.com','01792938447','','Md Mamun bbbTest','Md Mambbbun test bn',1,'Mamuns Fathers','Mamuns Fathers Bn','Mamun Mothers',' Mamun Mother bn',40549,1,1,1,1,' vill name','vill name bn',1,'2021-03-10 07:19:07','2021-03-10 07:19:07'),(43,186,'maymutna@gmail.com','01723019011','','Md Mamun bbbTest','অজানা নাম',1,'Mamuns Fathers','Mamuns Fathers Bn','Mamun Mothers',' Mamun Mother bn',40550,1,1,1,1,' vill name','vill name bn',1,'2021-03-10 07:23:22','2021-03-10 07:24:14'),(44,201,'fm_98824662@gmail.com','01730233032','','Mamun','Mamun bn',1,'fdfdf','dffdf','fddfdf','fdfdfd',25245343,1,1,1,1,'Debalayad','দেবালয়1',2,'2021-03-23 07:35:51','2021-03-23 07:35:51'),(45,202,'fm_49015793@gmail.com','01730233032','1616921540.jfif','test Mamun','mama bn',1,'fdfdf','dffdf','fddfdf','fdfdfd',4535,1,1,1,1,'Debalaya','দেবালয়1',2,'2021-03-23 10:15:55','2021-03-28 08:52:20'),(49,222,'hanfi@gmail.com','01850953185','1616908323.png','hanif','hanif',1,'1','2','1','2',12,4,35,266,2393,'1','2',2,'2021-03-27 23:12:03','2021-03-27 23:12:03'),(51,225,'01531875147@test.com','01531875147','1616910394.jpg','01531875147','01531875147',1,'operator','operator','operator','operator',111,1,5,48,442,'12','1',2,'2021-03-27 23:46:34','2021-03-27 23:46:34'),(55,226,'tt@gmail.com','01924496004','1616912312.png','1','1',1,'1','4','1','4',4,1,1,1,8,'4','4',2,'2021-03-28 00:18:32','2021-03-28 00:18:32'),(56,110,'01531875147@test.com','01924496004','1616918843.png','sunny','khan',1,'1','1','1','1',1,1,1,1,1,'1','1',2,'2021-03-28 02:07:23','2021-03-28 02:07:23'),(57,112,'admin20@gmail.com','01733322220','1616934414.jfif','Admin20','অ্যাডমিন20',1,'fdfdf','Norman Frank','Lev Ruiz','Zorita Alford',54343,1,1,1,1,'Ipsum quo quam labo','দেবালয়1',2,'2021-03-28 12:26:54','2021-03-28 12:26:54'),(58,113,'admin21@gmail.com','01733322221','1616991968.jpg','Admin21','অ্যাডমিন21',1,'ss','ss','ss','ss',784528888,1,1,1,1,'ss','ss',2,'2021-03-29 04:26:08','2021-03-29 04:26:08'),(59,114,'admin22@gmail.com','01733322222','1616992872.jpg','Admin22','অ্যাডমিন22',1,'MD.Rafiqul Islam','মোঃ রফিকুল ইসলাম','Shahanara Begum','শাহানারা বেগম',23156456,1,1,1,1,'Sreemontapur','শ্রীমন্তপুর',2,'2021-03-29 04:41:12','2021-03-29 04:41:12'),(60,248,'fm_67959140@gmail.com','01754019430','1618116813.jpg','QA Test Farmer','QA Test Farmer(Bn)',1,'QA Test Father Name','QA Test Father Name(Bn)','QA Test Mother Name','QA Test Mother Name',45634636,10,65,492,4541,'QA Test Village','QA Test Village(Bn)',2,'2021-04-10 22:53:33','2021-04-10 22:53:33'),(61,132,'fm_01620656565@gmail.com','01620656565','1618136545.jpg','sd','অজানা নাম',1,'ghfh','ghfgh','gfhfd','hfdh',456,10,65,492,4541,'ghfd','hgfdh',2,'2021-04-11 04:22:25','2021-04-11 04:22:25'),(62,98,'basheragro@gmail.com','01620506565','1618136739.jpg','Basher','অজানা নাম',1,'vbcbc','ncc','ncvnv','bvnbv',56456,10,65,492,4541,'cnbvcn','bvnv',2,'2021-04-11 04:25:39','2021-04-11 04:25:39');
/*!40000 ALTER TABLE `far_basic_infos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_complain_approvals`
--

DROP TABLE IF EXISTS `far_complain_approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_complain_approvals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `complain_id` bigint(20) unsigned NOT NULL,
  `requisition_id` bigint(20) unsigned NOT NULL,
  `sender_id` bigint(20) unsigned NOT NULL,
  `receiver_id` bigint(20) unsigned NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1=pending, 2=approved',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_complain_approvals_complain_id_foreign` (`complain_id`),
  KEY `far_complain_approvals_requisition_id_foreign` (`requisition_id`),
  CONSTRAINT `far_complain_approvals_complain_id_foreign` FOREIGN KEY (`complain_id`) REFERENCES `far_complains` (`id`),
  CONSTRAINT `far_complain_approvals_requisition_id_foreign` FOREIGN KEY (`requisition_id`) REFERENCES `far_complain_requisitions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_complain_approvals`
--

LOCK TABLES `far_complain_approvals` WRITE;
/*!40000 ALTER TABLE `far_complain_approvals` DISABLE KEYS */;
INSERT INTO `far_complain_approvals` VALUES (1,6,1,1,1,'1','1',1,1,1,NULL,NULL),(2,7,6,1,9,'test office hanif','test office hanif',1,NULL,NULL,'2021-03-28 09:52:45','2021-03-28 09:52:45');
/*!40000 ALTER TABLE `far_complain_approvals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_complain_progress_reports`
--

DROP TABLE IF EXISTS `far_complain_progress_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_complain_progress_reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `complain_id` bigint(20) unsigned NOT NULL,
  `progress_type` tinyint(4) NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note_bn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `progress_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_complain_progress_reports_complain_id_foreign` (`complain_id`),
  CONSTRAINT `far_complain_progress_reports_complain_id_foreign` FOREIGN KEY (`complain_id`) REFERENCES `far_complains` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_complain_progress_reports`
--

LOCK TABLES `far_complain_progress_reports` WRITE;
/*!40000 ALTER TABLE `far_complain_progress_reports` DISABLE KEYS */;
INSERT INTO `far_complain_progress_reports` VALUES (1,2,3,'fsdfhfdsh','dhfdhd','2021-03-03','2021-03-03 05:53:34','2021-03-03 05:53:34'),(2,6,1,'test note','test note bn','2021-03-03','2021-03-03 11:24:24','2021-03-03 11:24:24'),(3,7,1,'1','11','2021-03-04','2021-03-04 01:44:16','2021-03-04 01:44:16'),(4,10,1,'vert vad no','vert vad no','2021-03-04','2021-03-04 03:19:26','2021-03-04 03:19:26'),(5,11,2,'55','77','2021-03-04','2021-03-04 03:44:11','2021-03-04 03:44:11'),(6,12,3,'10','10','2021-03-04','2021-03-04 04:34:20','2021-03-04 04:34:20'),(7,13,1,'33','33','2021-03-04','2021-03-04 05:50:33','2021-03-04 05:50:33'),(8,1,2,'xdsgfgf','fdfdhfhfdh','2021-03-06','2021-03-06 04:35:52','2021-03-06 04:35:52'),(9,16,3,'done','done bn','2021-03-10','2021-03-10 05:04:41','2021-03-10 05:04:41'),(10,5,1,'sd','sdf','2021-03-25','2021-03-25 09:12:09','2021-03-25 09:12:09');
/*!40000 ALTER TABLE `far_complain_progress_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_complain_req_details`
--

DROP TABLE IF EXISTS `far_complain_req_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_complain_req_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `requisition_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `quantity` double(8,2) NOT NULL,
  `accepted_quantity` double(8,2) NOT NULL DEFAULT '0.00',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_complain_req_details_requisition_id_foreign` (`requisition_id`),
  CONSTRAINT `far_complain_req_details_requisition_id_foreign` FOREIGN KEY (`requisition_id`) REFERENCES `far_complain_requisitions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_complain_req_details`
--

LOCK TABLES `far_complain_req_details` WRITE;
/*!40000 ALTER TABLE `far_complain_req_details` DISABLE KEYS */;
INSERT INTO `far_complain_req_details` VALUES (1,1,1,10.00,0.00,NULL,NULL,'2021-03-02 10:35:30','2021-03-02 10:35:30'),(2,2,1,3.00,0.00,NULL,NULL,'2021-03-03 11:27:53','2021-03-03 11:27:53'),(3,3,1,5.00,0.00,NULL,NULL,'2021-03-10 05:04:19','2021-03-10 05:04:19'),(4,4,1,50.00,0.00,NULL,NULL,'2021-03-24 13:13:23','2021-03-24 13:13:23'),(5,5,1,50.00,0.00,NULL,NULL,'2021-03-25 09:11:47','2021-03-25 09:11:47'),(6,6,1,50.00,0.00,NULL,NULL,'2021-03-28 08:47:21','2021-03-28 08:47:21');
/*!40000 ALTER TABLE `far_complain_req_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_complain_requisitions`
--

DROP TABLE IF EXISTS `far_complain_requisitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_complain_requisitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `office_id` bigint(20) unsigned NOT NULL,
  `pump_type_id` bigint(20) unsigned NOT NULL,
  `requisition_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remarks` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remarks_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `requisition_date` date NOT NULL,
  `id_serial` bigint(20) unsigned NOT NULL,
  `complain_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1=Pending, 2=Receive, 3=Approve, 4=Forward, 5=Allocate, 6=Quantity edit',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_complain_requisitions_complain_id_foreign` (`complain_id`),
  KEY `far_complain_requisitions_pump_type_id_foreign` (`pump_type_id`),
  CONSTRAINT `far_complain_requisitions_complain_id_foreign` FOREIGN KEY (`complain_id`) REFERENCES `far_complains` (`id`),
  CONSTRAINT `far_complain_requisitions_pump_type_id_foreign` FOREIGN KEY (`pump_type_id`) REFERENCES `master_pump_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_complain_requisitions`
--

LOCK TABLES `far_complain_requisitions` WRITE;
/*!40000 ALTER TABLE `far_complain_requisitions` DISABLE KEYS */;
INSERT INTO `far_complain_requisitions` VALUES (1,3,1,1,'200001','fgfdfdsgf','dfgdxsg','2021-03-02',0,2,1,1,3,'2021-03-02 10:35:30','2021-03-03 05:50:54'),(2,3,1,1,'200002','test remarks','test remarks bn','2021-03-03',0,6,1,1,3,'2021-03-03 11:27:52','2021-03-03 11:28:25'),(3,3,1,2,'200003','test remark','test remark bn','2021-03-10',0,16,1,1,3,'2021-03-10 05:04:19','2021-03-10 05:06:01'),(4,3,1,1,'200004','trtr','trtrtr','2021-03-24',0,17,1,1,3,'2021-03-24 13:13:23','2021-03-24 13:13:28'),(5,3,1,1,'200005','sadd','sfsd','2021-03-25',0,5,1,1,1,'2021-03-25 09:11:47','2021-03-25 09:11:47'),(6,3,1,1,'200006','test remark','test remark bn','2021-03-28',0,7,74,74,5,'2021-03-28 08:47:21','2021-03-28 09:52:45');
/*!40000 ALTER TABLE `far_complain_requisitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_complain_resolves`
--

DROP TABLE IF EXISTS `far_complain_resolves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_complain_resolves` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `complain_id` bigint(20) unsigned NOT NULL,
  `resolve_note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `resolve_note_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_complain_resolves_complain_id_foreign` (`complain_id`),
  CONSTRAINT `far_complain_resolves_complain_id_foreign` FOREIGN KEY (`complain_id`) REFERENCES `far_complains` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_complain_resolves`
--

LOCK TABLES `far_complain_resolves` WRITE;
/*!40000 ALTER TABLE `far_complain_resolves` DISABLE KEYS */;
INSERT INTO `far_complain_resolves` VALUES (1,6,'test resolved note','test resolved note bn',1,1,0,'2021-03-03 11:31:58','2021-03-03 11:31:58'),(2,2,'1','22',1,1,0,'2021-03-03 22:52:42','2021-03-03 22:52:42'),(3,16,'test','test bn',1,1,0,'2021-03-15 10:55:05','2021-03-15 10:55:05'),(4,5,'done','done ',1,1,0,'2021-03-25 09:12:19','2021-03-25 09:12:19'),(5,20,'ssd','ssd',1,1,0,'2021-03-28 09:44:17','2021-03-28 09:44:17');
/*!40000 ALTER TABLE `far_complain_resolves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_complain_reviews`
--

DROP TABLE IF EXISTS `far_complain_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_complain_reviews` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `complain_id` bigint(20) unsigned NOT NULL,
  `review_note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `review_note_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_complain_reviews_complain_id_foreign` (`complain_id`),
  CONSTRAINT `far_complain_reviews_complain_id_foreign` FOREIGN KEY (`complain_id`) REFERENCES `far_complains` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_complain_reviews`
--

LOCK TABLES `far_complain_reviews` WRITE;
/*!40000 ALTER TABLE `far_complain_reviews` DISABLE KEYS */;
INSERT INTO `far_complain_reviews` VALUES (1,8,'1','12',1,1,0,'2021-03-04 03:04:47','2021-03-04 03:04:47');
/*!40000 ALTER TABLE `far_complain_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_complain_supply_equipments`
--

DROP TABLE IF EXISTS `far_complain_supply_equipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_complain_supply_equipments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `supply_note` text COLLATE utf8_unicode_ci NOT NULL,
  `supply_note_bn` text COLLATE utf8_unicode_ci,
  `supply_date` date NOT NULL,
  `requisition_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_complain_supply_equipments_requisition_id_foreign` (`requisition_id`),
  CONSTRAINT `far_complain_supply_equipments_requisition_id_foreign` FOREIGN KEY (`requisition_id`) REFERENCES `far_complain_requisitions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_complain_supply_equipments`
--

LOCK TABLES `far_complain_supply_equipments` WRITE;
/*!40000 ALTER TABLE `far_complain_supply_equipments` DISABLE KEYS */;
INSERT INTO `far_complain_supply_equipments` VALUES (1,'dfhgdh','dhdhd','2021-03-03',1,40,40,'2021-03-03 05:52:57','2021-03-03 05:52:57'),(2,'test supply note','test supply note bn','2021-03-03',2,1,1,'2021-03-03 11:29:01','2021-03-03 11:29:01'),(3,'test','test bn','2021-03-10',3,1,1,'2021-03-10 05:06:52','2021-03-10 05:06:52'),(5,'aa','aaa','2021-03-24',4,1,1,'2021-03-24 13:15:37','2021-03-24 13:15:37');
/*!40000 ALTER TABLE `far_complain_supply_equipments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_complain_tro_equipment_details`
--

DROP TABLE IF EXISTS `far_complain_tro_equipment_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_complain_tro_equipment_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tro_equipments_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name_bn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note_bn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_complain_tro_equipment_details_tro_equipments_id_foreign` (`tro_equipments_id`),
  CONSTRAINT `far_complain_tro_equipment_details_tro_equipments_id_foreign` FOREIGN KEY (`tro_equipments_id`) REFERENCES `far_complain_tro_equipments` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_complain_tro_equipment_details`
--

LOCK TABLES `far_complain_tro_equipment_details` WRITE;
/*!40000 ALTER TABLE `far_complain_tro_equipment_details` DISABLE KEYS */;
INSERT INTO `far_complain_tro_equipment_details` VALUES (1,1,'Pump','Pump','efrgtr','trgrg',0,NULL,NULL,'2021-03-02 10:30:56','2021-03-02 10:30:56'),(2,1,'pipe','pipe','cefghhg','fhfhgfhbb',0,NULL,NULL,'2021-03-02 10:30:56','2021-03-02 10:30:56'),(3,2,'Pump','Pump','efrgtr','trgrg',0,NULL,NULL,'2021-03-03 05:46:56','2021-03-03 05:46:56'),(4,2,'Pump','Pump','efrgtr','trgrg',0,NULL,NULL,'2021-03-03 05:46:56','2021-03-03 05:46:56'),(5,3,'test','test name bn','test note','test note bn',0,NULL,NULL,'2021-03-03 11:17:45','2021-03-03 11:17:45'),(6,4,'1','1','2','2',0,NULL,NULL,'2021-03-03 23:18:35','2021-03-03 23:18:35'),(7,5,'1','1','2','12',0,NULL,NULL,'2021-03-04 01:40:29','2021-03-04 01:40:29'),(8,6,'test',' test ','test ','test',0,NULL,NULL,'2021-03-10 05:03:20','2021-03-10 05:03:20'),(9,7,'ss','ss','ss','ss',0,NULL,NULL,'2021-03-24 13:07:30','2021-03-24 13:07:30'),(10,8,'s','sss','ss','ss',0,NULL,NULL,'2021-03-25 09:07:00','2021-03-25 09:07:00'),(11,8,'sssdfd','dfd','dfsf','sdf',0,NULL,NULL,'2021-03-25 09:07:01','2021-03-25 09:07:01');
/*!40000 ALTER TABLE `far_complain_tro_equipment_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_complain_tro_equipments`
--

DROP TABLE IF EXISTS `far_complain_tro_equipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_complain_tro_equipments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `complain_id` bigint(20) unsigned NOT NULL,
  `division_id` bigint(20) unsigned NOT NULL,
  `district_id` bigint(20) unsigned NOT NULL,
  `upazilla_id` bigint(20) unsigned NOT NULL,
  `union_id` bigint(20) unsigned NOT NULL,
  `mauza_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `jl_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `plot_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_complain_tro_equipments_complain_id_foreign` (`complain_id`),
  CONSTRAINT `far_complain_tro_equipments_complain_id_foreign` FOREIGN KEY (`complain_id`) REFERENCES `far_complains` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_complain_tro_equipments`
--

LOCK TABLES `far_complain_tro_equipments` WRITE;
/*!40000 ALTER TABLE `far_complain_tro_equipments` DISABLE KEYS */;
INSERT INTO `far_complain_tro_equipments` VALUES (1,2,6,47,365,3271,'1234','1234','1234',0,1,1,'2021-03-02 10:30:56','2021-03-02 10:30:56'),(2,3,6,47,365,3271,'1234','1234','1234',0,40,40,'2021-03-03 05:46:56','2021-03-03 05:46:56'),(3,6,1,1,1,1,'test mouza no','test','test',0,1,1,'2021-03-03 11:17:45','2021-03-03 11:17:45'),(4,1,1,1,1,1,'123','12','1',0,1,1,'2021-03-03 23:18:35','2021-03-03 23:18:35'),(5,7,1,1,1,1,'123','123','1',0,54,54,'2021-03-04 01:40:29','2021-03-04 01:40:29'),(6,16,1,1,1,1,'20','10','10',0,1,1,'2021-03-10 05:03:20','2021-03-10 05:03:20'),(7,14,1,1,1,1,'2','2','2',0,1,1,'2021-03-24 13:07:30','2021-03-24 13:07:30'),(8,18,1,3,28,282,'5','5','5',0,1,1,'2021-03-25 09:07:00','2021-03-25 09:07:00');
/*!40000 ALTER TABLE `far_complain_tro_equipments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_complains`
--

DROP TABLE IF EXISTS `far_complains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_complains` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `farmer_id` bigint(20) unsigned NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `complain_id` int(11) NOT NULL,
  `id_serial` int(11) DEFAULT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `far_division_id` bigint(20) unsigned NOT NULL,
  `far_district_id` bigint(20) unsigned NOT NULL,
  `far_upazilla_id` bigint(20) unsigned NOT NULL,
  `far_union_id` bigint(20) unsigned NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subject_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8_unicode_ci NOT NULL,
  `details_bn` text COLLATE utf8_unicode_ci,
  `attachment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Pending, 2=Resolved, 3=Reviewed, 4=Required Maintenance, 5=Maintenance Task, 6=Requisition, 7=Complete, 8=Resunk',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `pump_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `far_complains_complain_id_unique` (`complain_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_complains`
--

LOCK TABLES `far_complains` WRITE;
/*!40000 ALTER TABLE `far_complains` DISABLE KEYS */;
INSERT INTO `far_complains` VALUES (1,14,'suman@gmail.com',100000,NULL,3,1,1,4,51,'Pump not working','','<p>Pump not working</p>','',NULL,7,'2021-03-02 05:12:42','2021-03-06 04:35:52',NULL),(2,9,'nadim.syntech@gmail.com',100001,NULL,3,6,47,365,3271,'pump nosto','pump nosto','<p>Nosto</p>','<p>Nosto</p>',NULL,5,'2021-03-02 08:51:06','2021-03-04 02:54:51',NULL),(3,9,'nadim.syntech@gmail.com',100002,NULL,15,6,47,365,3271,'Resunk','Resunk','<p>dddd</p>','<p>ggff</p>',NULL,5,'2021-03-02 08:51:34','2021-03-03 05:47:04',NULL),(4,9,'nadim.syntech@gmail.com',100003,NULL,3,6,47,365,3271,'pump nosto','ewrgewgf','<p>gregregre</p>','<p>rewtewr</p>','1614154583.pdf',8,'2021-03-03 06:42:51','2021-03-03 06:45:31',NULL),(5,9,'nadim.syntech@gmail.com',100004,NULL,3,6,47,365,3271,'dfsgfagdg','fsdgfdg','<p>sdgsgdsg</p>','<p>dsgsgdsgggs</p>',NULL,2,'2021-03-03 09:41:25','2021-03-25 09:12:19',NULL),(6,13,'farmer3@gmail.com',100005,NULL,3,1,1,1,1,'In anim nobis a moll','Enim natus blanditii','<p>Non voluptates sunt .</p>','<p>Excepteur deleniti e.</p>','1614768742.jpg',5,'2021-03-03 10:52:22','2021-03-04 01:41:59',NULL),(7,55,'qatestfarmer@yopmail.com',100006,NULL,3,10,65,492,4541,'Bad Service Complain','Bad Service Complain Bn','<p>Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain </p>','<p>Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain Bad Service Complain </p>','1614840877.pdf',7,'2021-03-04 00:54:37','2021-03-04 01:44:17',NULL),(8,27,'test@gmail.com',100007,NULL,15,1,1,1,1,'complanin','complanin','<p>complanin</p>','<p>complanin</p>',NULL,3,'2021-03-04 03:04:00','2021-03-04 03:04:47',NULL),(9,27,'test@gmail.com',100008,NULL,15,1,1,1,1,'complain','bangla complain','<p>58</p>','<p>96</p>',NULL,5,'2021-03-04 03:06:34','2021-03-04 12:31:53',NULL),(10,27,'test@gmail.com',100009,NULL,2,1,1,1,1,'complanin','complanin','<p>12</p>','<p>21</p>',NULL,7,'2021-03-04 03:08:14','2021-03-04 03:19:26',NULL),(11,27,'test@gmail.com',100010,NULL,2,1,1,1,1,'1','2','<p>3</p>','<p>2</p>',NULL,5,'2021-03-04 03:21:09','2021-03-04 03:44:11',NULL),(12,27,'test@gmail.com',100011,NULL,2,1,1,1,1,'12','2','<p>1</p>','<p>2</p>',NULL,7,'2021-03-04 03:45:44','2021-03-04 04:34:20',NULL),(13,44,'ismail.khan.sunny@gmail.com',100012,NULL,2,1,1,1,1,'1','12','<p>1</p>','<p>2</p>',NULL,7,'2021-03-04 05:49:36','2021-03-04 05:50:33',NULL),(14,13,'farmer3@gmail.com',100013,NULL,3,1,1,1,1,'test','test bn','<p>test detils</p>','<p>test detils</p>',NULL,5,'2021-03-06 07:37:15','2021-03-24 13:07:34',NULL),(15,13,'farmer3@gmail.com',100014,NULL,2,1,1,1,1,'Quia aliquid autem l','Qui Nam qui et place','<p>Aut earum dolores pa.</p>','<p>\\</p>',NULL,5,'2021-03-09 06:10:42','2021-03-10 05:47:58',NULL),(16,13,'farmer3@gmail.com',100015,NULL,15,1,1,1,1,'Nam magnam illum es','','<p>Ex perspiciatis, cul.</p>','',NULL,2,'2021-03-09 06:12:08','2021-03-15 10:55:05',NULL),(17,12,'ruhul@gmail.com',100016,NULL,3,1,1,4,51,'ss','ss','<p>ss</p>','<p>ss</p>',NULL,6,'2021-03-24 11:05:47','2021-03-24 13:13:28',NULL),(18,12,'ruhul@gmail.com',100017,NULL,2,1,1,4,51,'Pump not working','Pump not working','<p>ss</p>','<p>ss</p>',NULL,5,'2021-03-25 03:35:27','2021-03-25 09:07:04',NULL),(19,225,'01531875147@test.com',100018,NULL,3,1,5,48,442,'complanin','complanin','<p>1</p>','<p>2</p>','1616910726.pdf',1,'2021-03-27 23:52:06','2021-03-27 23:52:06',NULL),(20,202,'fm_49015793@gmail.com',100019,NULL,3,1,1,1,1,'Pump not working','Pump not working','<p>sdadfdsf</p>','<p>asdfsdf</p>',NULL,2,'2021-03-28 09:31:54','2021-03-28 09:44:17',NULL),(21,202,'fm_49015793@gmail.com',100020,NULL,3,1,1,1,1,'sss','sss','<p>sss</p>','<p>sss</p>',NULL,4,'2021-03-28 09:32:09','2021-03-28 09:43:44',NULL),(22,114,'admin22@gmail.com',100021,NULL,15,1,1,1,1,'Pump not working','Pump fault bn','<p>dsad</p>','<p>asdsad</p>',NULL,1,'2021-03-29 05:07:54','2021-03-29 05:07:54',NULL);
/*!40000 ALTER TABLE `far_complains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_pump_install`
--

DROP TABLE IF EXISTS `far_pump_install`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_pump_install` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scheme_application_id` bigint(20) unsigned NOT NULL,
  `contractor_id` bigint(20) unsigned NOT NULL,
  `pump_progress_type_step_id` bigint(20) unsigned NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `note_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_pump_install_scheme_application_id_foreign` (`scheme_application_id`),
  CONSTRAINT `far_pump_install_scheme_application_id_foreign` FOREIGN KEY (`scheme_application_id`) REFERENCES `far_scheme_application` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_pump_install`
--

LOCK TABLES `far_pump_install` WRITE;
/*!40000 ALTER TABLE `far_pump_install` DISABLE KEYS */;
INSERT INTO `far_pump_install` VALUES (17,26,1,6,'2021-03-08','2021-03-09','note 1','note 1 bn','2021-03-08 13:04:21','2021-03-08 13:04:21'),(18,26,1,7,'2021-03-08','2021-03-10','note 2','note 2 bn','2021-03-08 13:04:21','2021-03-08 13:04:21'),(20,39,1,6,'2021-03-29','2021-03-23','note 2','note 2 bn','2021-03-08 14:44:55','2021-03-08 14:44:55'),(21,39,1,7,'2021-03-09','2021-03-24','a','a','2021-03-08 14:44:55','2021-03-08 14:44:55'),(23,32,4,6,'2021-03-08','2021-03-10','note 1','note 1 bn','2021-03-08 14:47:06','2021-03-08 14:47:06'),(24,32,4,7,'2021-03-17','2021-03-24','note 2','note 2 bn','2021-03-08 14:47:06','2021-03-08 14:47:06'),(26,3,1,6,'2021-03-23','2021-03-31','note 1','note 1 bn','2021-03-23 05:31:28','2021-03-23 05:31:28'),(27,3,1,7,'2021-03-23','2021-03-31','note 2','note 2 bn','2021-03-23 05:31:28','2021-03-23 05:31:28'),(29,6,1,6,'2021-03-01','2021-03-01','y','y','2021-03-23 11:24:35','2021-03-23 11:24:35'),(30,6,1,7,'2021-03-23','2021-03-23','h','h','2021-03-23 11:24:35','2021-03-23 11:24:35'),(32,4,1,6,'2021-03-27','2021-03-31','note 1','c','2021-03-27 04:34:40','2021-03-27 04:34:40'),(33,4,1,7,'2021-03-02','2021-03-10','afdgdsf','asdfsdf','2021-03-27 04:34:40','2021-03-27 04:34:40');
/*!40000 ALTER TABLE `far_pump_install` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_pump_opt_app_reniews`
--

DROP TABLE IF EXISTS `far_pump_opt_app_reniews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_pump_opt_app_reniews` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pump_opt_apps_id` bigint(20) unsigned NOT NULL,
  `application_date` date NOT NULL,
  `payment_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=Unpaid, 1=Application Fee',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=Pending, 1=processing, 2=Approved, 3=Reject',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_pump_opt_app_reniews_pump_opt_apps_id_foreign` (`pump_opt_apps_id`),
  CONSTRAINT `far_pump_opt_app_reniews_pump_opt_apps_id_foreign` FOREIGN KEY (`pump_opt_apps_id`) REFERENCES `far_pump_opt_apps` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_pump_opt_app_reniews`
--

LOCK TABLES `far_pump_opt_app_reniews` WRITE;
/*!40000 ALTER TABLE `far_pump_opt_app_reniews` DISABLE KEYS */;
INSERT INTO `far_pump_opt_app_reniews` VALUES (1,8,'2021-03-28',0,0,'2021-03-28 09:09:05','2021-03-28 09:09:05'),(2,9,'2021-03-28',0,0,'2021-03-28 09:28:06','2021-03-28 09:28:06'),(3,10,'2021-03-28',0,0,'2021-03-28 09:37:35','2021-03-28 09:37:35'),(4,11,'2021-03-28',0,0,'2021-03-28 09:40:16','2021-03-28 09:40:16'),(5,12,'2021-03-28',0,0,'2021-03-28 09:43:35','2021-03-28 09:43:35'),(6,13,'2021-03-28',0,0,'2021-03-28 10:41:06','2021-03-28 10:41:06'),(7,14,'2021-03-28',0,0,'2021-03-28 10:41:06','2021-03-28 10:41:06'),(8,15,'2021-03-28',0,0,'2021-03-28 10:55:03','2021-03-28 10:55:03'),(9,16,'2021-03-28',0,0,'2021-03-28 11:18:03','2021-03-28 11:18:03'),(10,17,'2021-03-28',0,0,'2021-03-28 11:19:51','2021-03-28 11:19:51'),(11,18,'2021-03-28',0,0,'2021-03-28 11:20:24','2021-03-28 11:20:24'),(12,19,'2021-03-28',1,0,'2021-03-28 11:24:36','2021-03-28 11:24:36'),(13,20,'2021-03-28',1,0,'2021-03-28 12:21:04','2021-03-28 12:25:21'),(14,23,'2021-03-29',1,0,'2021-03-29 04:32:23','2021-03-29 04:32:29'),(15,25,'2021-03-29',1,0,'2021-03-29 05:05:52','2021-03-29 05:06:43');
/*!40000 ALTER TABLE `far_pump_opt_app_reniews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_pump_opt_apps`
--

DROP TABLE IF EXISTS `far_pump_opt_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_pump_opt_apps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `farmer_id` bigint(20) unsigned NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `pump_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name_bn` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `gender` int(11) DEFAULT NULL,
  `father_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `father_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nid` bigint(20) unsigned NOT NULL,
  `far_mobile_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `far_division_id` bigint(20) unsigned NOT NULL,
  `far_district_id` bigint(20) unsigned NOT NULL,
  `far_upazilla_id` bigint(20) unsigned NOT NULL,
  `far_union_id` bigint(20) unsigned NOT NULL,
  `far_village` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `far_village_bn` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `date_of_birth` date NOT NULL,
  `qualification` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Pending, 2=processing, 3=Approved, 4=Reject, 5=Send, 6=Send for Survey, 7=Receive, 8=Survey Submit',
  `is_renew` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1=renew',
  `payment_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=unpaid 1=application fee, 2= security fee',
  `final_approve` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `application_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_serial` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_pump_opt_apps_name_index` (`name`),
  KEY `far_pump_opt_apps_email_index` (`email`),
  KEY `far_pump_opt_apps_far_division_id_index` (`far_division_id`),
  KEY `far_pump_opt_apps_far_district_id_index` (`far_district_id`),
  KEY `far_pump_opt_apps_far_upazilla_id_index` (`far_upazilla_id`),
  KEY `far_pump_opt_apps_far_union_id_index` (`far_union_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_pump_opt_apps`
--

LOCK TABLES `far_pump_opt_apps` WRITE;
/*!40000 ALTER TABLE `far_pump_opt_apps` DISABLE KEYS */;
INSERT INTO `far_pump_opt_apps` VALUES (1,46,'01846633959',3,'23','BADC User','BADC User bn',1,'Badc Father','Badc Father bn','Badc Mother','Badc Mother bn',45748540584,'01991652700',1,1,1,1,'Badc village','Badc village bn','2021-03-18','BSC',3,0,1,0,'2021-03-18 11:24:29','2021-03-24 10:54:33','poappid#1000',1000),(2,14,'01767778333',3,'23','Suman ','Suman bn',1,'MD.Rafiqul Islam','মোঃ রফিকুল ইসলাম','Shahanara Begum','শাহানারা বেগম',5641238745,'01620506565',1,1,1,1,'Sreemontapur','শ্রীমন্তপুর','2021-03-23','',3,0,1,0,'2021-03-23 07:51:18','2021-03-24 11:08:15','poappid#1001',1001),(3,202,'01730233032',15,'13','test Mamun','mama bn',1,'fdfdf','dffdf','fddfdf','fdfdfd',4535,'01730233032',1,1,1,1,'Debalaya','দেবালয়1','2021-03-08','test',3,0,2,0,'2021-03-23 10:34:42','2021-03-28 09:30:12','poappid#1002',1002),(5,219,'01531875147',3,'13','123','12',1,'22','3','1','21',11,'01531875147',1,1,1,14,'12','1','2021-03-27','1',1,0,0,0,'2021-03-27 00:07:53','2021-03-27 00:07:53','poappid#1003',1003),(6,220,'01531875147',3,'41','01531875147','01531875147',1,'shamsuddin khan','shamsuddin khan','suriya begum','suriya begum',12,'01531875147',1,1,5,56,'12','dhaka','2021-03-23','1',1,0,0,0,'2021-03-27 00:42:28','2021-03-27 00:45:24','poappid#1004',1004),(7,225,'01531875147',3,'13','01531875147','01531875147',1,'operator','operator','operator','operator',111,'01531875147',1,1,1,14,'12','1','2021-03-03','',1,0,0,0,'2021-03-27 23:49:22','2021-03-27 23:49:22','poappid#1005',1005),(19,202,'01730233032',15,'13','test Mamun','mama bn',1,'fdfdf','dffdf','fddfdf','fdfdfd',4535,'01730233032',1,1,1,1,'Debalaya','দেবালয়1','2021-03-08','test',1,1,2,0,'2021-03-28 11:24:36','2021-03-28 11:24:36','poappid#1006',1006),(20,202,'01730233032',15,'13','test Mamun','mama bn',1,'fdfdf','dffdf','fddfdf','fdfdfd',4535,'01730233032',1,1,1,1,'Debalaya','দেবালয়1','2021-03-08','test',2,1,2,0,'2021-03-28 12:21:03','2021-03-28 12:25:21','poappid#1007',1007),(21,112,'01733322220',15,'13','Admin20','অ্যাডমিন20',1,'fdfdf','Norman Frank','Lev Ruiz','Zorita Alford',54343,'01733322220',1,1,1,1,'Ipsum quo quam labo','দেবালয়1','2021-03-28','test',6,0,2,0,'2021-03-28 12:27:25','2021-03-28 12:34:25','poappid#1008',1008),(22,113,'01733322221',15,'41','Admin21','অ্যাডমিন21',1,'ss','ss','ss','ss',784528888,'01733322221',1,1,1,1,'ss','ss','2021-03-01','BSC',3,0,2,0,'2021-03-29 04:26:42','2021-03-29 04:31:17','poappid#1009',1009),(23,113,'01733322221',15,'41','Admin21','অ্যাডমিন21',1,'ss','ss','ss','ss',784528888,'01733322221',1,1,1,1,'ss','ss','2021-03-01','BSC',2,1,2,0,'2021-03-29 04:32:22','2021-03-29 04:32:29','poappid#1010',1010),(24,114,'01733322222',15,'38','Admin22','অ্যাডমিন22',1,'MD.Rafiqul Islam','মোঃ রফিকুল ইসলাম','Shahanara Begum','শাহানারা বেগম',23156456,'01733322222',1,1,1,1,'Sreemontapur','শ্রীমন্তপুর','2021-03-29','BSC',3,0,2,0,'2021-03-29 04:41:42','2021-03-29 05:05:15','poappid#1011',1011),(25,114,'01733322222',15,'38','Admin22','অ্যাডমিন22',1,'MD.Rafiqul Islam','মোঃ রফিকুল ইসলাম','Shahanara Begum','শাহানারা বেগম',23156456,'01733322222',1,1,1,1,'Sreemontapur','শ্রীমন্তপুর','2021-03-29','BSC',2,1,2,0,'2021-03-29 05:05:52','2021-03-29 05:06:43','poappid#1012',1012),(26,248,'01754019430',3,'42','QA Test Farmer','QA Test Farmer(Bn)',1,'QA Test Father Name','QA Test Father Name(Bn)','QA Test Mother Name','QA Test Mother Name',45634636,'01754019431',10,65,492,4541,'QA Test Village','QA Test Village(Bn)','2021-04-11','SSC',3,0,2,0,'2021-04-10 23:28:29','2021-04-11 03:53:02','poappid#1013',1013);
/*!40000 ALTER TABLE `far_pump_opt_apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_pump_opt_docs`
--

DROP TABLE IF EXISTS `far_pump_opt_docs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_pump_opt_docs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pump_opt_apps_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `document_title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `document_title_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attachment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_pump_opt_docs_pump_opt_apps_id_foreign` (`pump_opt_apps_id`),
  CONSTRAINT `far_pump_opt_docs_pump_opt_apps_id_foreign` FOREIGN KEY (`pump_opt_apps_id`) REFERENCES `far_pump_opt_apps` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_pump_opt_docs`
--

LOCK TABLES `far_pump_opt_docs` WRITE;
/*!40000 ALTER TABLE `far_pump_opt_docs` DISABLE KEYS */;
INSERT INTO `far_pump_opt_docs` VALUES (1,1,14,'ss','ss bn','1615886893.pdf','2021-03-16 09:28:13','2021-03-16 09:35:49'),(6,NULL,0,'ss','ss bn','1616056622.pdf','2021-03-18 08:37:02','2021-03-18 08:37:02'),(7,1,46,'s','ss bn','1616066668.pdf','2021-03-18 11:24:28','2021-03-18 11:24:29'),(8,4,219,'q','q','1616824593.pdf','2021-03-26 23:56:33','2021-03-27 00:00:29'),(9,7,225,'1','1','1616910504.pdf','2021-03-27 23:48:24','2021-03-27 23:49:22'),(10,26,248,'','',NULL,'2021-04-10 23:27:16','2021-04-10 23:28:29'),(14,NULL,12,'ss','ss','1618309936.jpg','2021-04-13 10:32:16','2021-04-13 10:32:16'),(15,NULL,12,'ddd','ddd','1618309947.jpg','2021-04-13 10:32:27','2021-04-13 10:32:27');
/*!40000 ALTER TABLE `far_pump_opt_docs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_pump_opt_rejects`
--

DROP TABLE IF EXISTS `far_pump_opt_rejects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_pump_opt_rejects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pump_opt_apps_id` bigint(20) unsigned NOT NULL,
  `reject_note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `reject_note_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attachment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_pump_opt_rejects_pump_opt_apps_id_foreign` (`pump_opt_apps_id`),
  CONSTRAINT `far_pump_opt_rejects_pump_opt_apps_id_foreign` FOREIGN KEY (`pump_opt_apps_id`) REFERENCES `far_pump_opt_apps` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_pump_opt_rejects`
--

LOCK TABLES `far_pump_opt_rejects` WRITE;
/*!40000 ALTER TABLE `far_pump_opt_rejects` DISABLE KEYS */;
INSERT INTO `far_pump_opt_rejects` VALUES (1,26,'Reject','Reject',NULL,'2021-04-11 03:00:34','2021-04-11 03:00:34'),(2,26,'rr','rr',NULL,'2021-04-11 03:15:11','2021-04-11 03:15:11'),(3,26,'dfd','dfd',NULL,'2021-04-11 03:21:45','2021-04-11 03:21:45'),(4,26,'gfdg','fdgfdg',NULL,'2021-04-11 03:25:11','2021-04-11 03:25:11');
/*!40000 ALTER TABLE `far_pump_opt_rejects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_pump_opt_reniews_reject`
--

DROP TABLE IF EXISTS `far_pump_opt_reniews_reject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_pump_opt_reniews_reject` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scheme_application_id` bigint(20) unsigned NOT NULL,
  `renew_id` bigint(20) unsigned NOT NULL,
  `reject_note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `reject_note_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attachment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_pump_opt_reniews_reject_scheme_application_id_foreign` (`scheme_application_id`),
  KEY `far_pump_opt_reniews_reject_renew_id_foreign` (`renew_id`),
  CONSTRAINT `far_pump_opt_reniews_reject_renew_id_foreign` FOREIGN KEY (`renew_id`) REFERENCES `far_pump_opt_app_reniews` (`id`),
  CONSTRAINT `far_pump_opt_reniews_reject_scheme_application_id_foreign` FOREIGN KEY (`scheme_application_id`) REFERENCES `far_scheme_application` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_pump_opt_reniews_reject`
--

LOCK TABLES `far_pump_opt_reniews_reject` WRITE;
/*!40000 ALTER TABLE `far_pump_opt_reniews_reject` DISABLE KEYS */;
/*!40000 ALTER TABLE `far_pump_opt_reniews_reject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_ratings`
--

DROP TABLE IF EXISTS `far_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_ratings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `feedback` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `feedback_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rating` int(11) NOT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `division_id` bigint(20) unsigned NOT NULL,
  `district_id` bigint(20) unsigned NOT NULL,
  `upazilla_id` bigint(20) unsigned NOT NULL,
  `farmer_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_ratings`
--

LOCK TABLES `far_ratings` WRITE;
/*!40000 ALTER TABLE `far_ratings` DISABLE KEYS */;
INSERT INTO `far_ratings` VALUES (1,'1','1',1,3,1,1,1,47,'2021-03-03 04:15:46','2021-03-03 04:15:46'),(2,'dfg','sdf',4,3,2,12,104,12,'2021-03-25 05:25:54','2021-03-25 05:25:54');
/*!40000 ALTER TABLE `far_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_requisition_approvals`
--

DROP TABLE IF EXISTS `far_requisition_approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_requisition_approvals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scheme_application_id` bigint(20) unsigned NOT NULL,
  `requisition_id` bigint(20) unsigned NOT NULL,
  `sender_id` bigint(20) unsigned NOT NULL,
  `receiver_id` bigint(20) unsigned NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1=pending, 2=approved',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_requisition_approvals_scheme_application_id_foreign` (`scheme_application_id`),
  KEY `far_requisition_approvals_requisition_id_foreign` (`requisition_id`),
  CONSTRAINT `far_requisition_approvals_requisition_id_foreign` FOREIGN KEY (`requisition_id`) REFERENCES `far_scheme_requisitions` (`id`),
  CONSTRAINT `far_requisition_approvals_scheme_application_id_foreign` FOREIGN KEY (`scheme_application_id`) REFERENCES `far_scheme_application` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_requisition_approvals`
--

LOCK TABLES `far_requisition_approvals` WRITE;
/*!40000 ALTER TABLE `far_requisition_approvals` DISABLE KEYS */;
/*!40000 ALTER TABLE `far_requisition_approvals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_resunks`
--

DROP TABLE IF EXISTS `far_resunks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_resunks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `complain_id` bigint(20) unsigned NOT NULL,
  `pump_informations_id` bigint(20) unsigned NOT NULL,
  `resunk_note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `resunk_note_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1=Pending, 2=Complete',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_resunks_complain_id_foreign` (`complain_id`),
  KEY `far_resunks_pump_informations_id_foreign` (`pump_informations_id`),
  CONSTRAINT `far_resunks_complain_id_foreign` FOREIGN KEY (`complain_id`) REFERENCES `far_complains` (`id`),
  CONSTRAINT `far_resunks_pump_informations_id_foreign` FOREIGN KEY (`pump_informations_id`) REFERENCES `pump_informations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_resunks`
--

LOCK TABLES `far_resunks` WRITE;
/*!40000 ALTER TABLE `far_resunks` DISABLE KEYS */;
INSERT INTO `far_resunks` VALUES (2,5,15,'fdxgfyy','dfhyfdsyryy',NULL,NULL,1,'2021-03-03 09:44:13','2021-03-03 09:44:13');
/*!40000 ALTER TABLE `far_resunks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_scheme_agreement`
--

DROP TABLE IF EXISTS `far_scheme_agreement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_scheme_agreement` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agreement_details` text COLLATE utf8_unicode_ci NOT NULL,
  `agreement_details_bn` text COLLATE utf8_unicode_ci NOT NULL,
  `scheme_application_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_scheme_agreement_scheme_application_id_foreign` (`scheme_application_id`),
  CONSTRAINT `far_scheme_agreement_scheme_application_id_foreign` FOREIGN KEY (`scheme_application_id`) REFERENCES `far_scheme_application` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_scheme_agreement`
--

LOCK TABLES `far_scheme_agreement` WRITE;
/*!40000 ALTER TABLE `far_scheme_agreement` DISABLE KEYS */;
INSERT INTO `far_scheme_agreement` VALUES (1,'<p>ssd</p>','<p>ssd</p>',3,1,1,'2021-03-23 04:03:04','2021-03-23 04:03:04'),(2,'<p>sfgd</p>','<p>dfgsg</p>',4,1,1,'2021-03-23 06:14:39','2021-03-23 06:14:39'),(3,'<p>afddasf</p>','<p>asdfsdf</p>',6,1,1,'2021-03-23 11:10:15','2021-03-23 11:10:15'),(4,'<p>444sdfgsd </p>','<p>sdgdf</p>',5,1,1,'2021-03-24 10:07:35','2021-03-24 10:07:35'),(5,'<p>ss</p>','<p>ss</p>',8,212,212,'2021-03-25 06:27:10','2021-03-25 06:27:10');
/*!40000 ALTER TABLE `far_scheme_agreement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_scheme_agreemt_doc`
--

DROP TABLE IF EXISTS `far_scheme_agreemt_doc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_scheme_agreemt_doc` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agreement_date` date NOT NULL,
  `attachment` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `scheme_application_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_scheme_agreemt_doc_scheme_application_id_foreign` (`scheme_application_id`),
  CONSTRAINT `far_scheme_agreemt_doc_scheme_application_id_foreign` FOREIGN KEY (`scheme_application_id`) REFERENCES `far_scheme_application` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_scheme_agreemt_doc`
--

LOCK TABLES `far_scheme_agreemt_doc` WRITE;
/*!40000 ALTER TABLE `far_scheme_agreemt_doc` DISABLE KEYS */;
INSERT INTO `far_scheme_agreemt_doc` VALUES (1,'2021-03-23','1616472192.jpg',3,1,1,'2021-03-23 04:03:12','2021-03-23 04:03:12'),(2,'2021-03-23','1616480094.pdf',4,1,1,'2021-03-23 06:14:54','2021-03-23 06:14:54'),(3,'2021-03-23','1616497831.docx',6,1,1,'2021-03-23 11:10:31','2021-03-23 11:10:31'),(4,'2021-03-17','1616580464.pdf',5,1,1,'2021-03-24 10:07:44','2021-03-24 10:07:44'),(5,'2021-03-25','1616653636.jpg',8,212,212,'2021-03-25 06:27:16','2021-03-25 06:27:16');
/*!40000 ALTER TABLE `far_scheme_agreemt_doc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_scheme_app_details`
--

DROP TABLE IF EXISTS `far_scheme_app_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_scheme_app_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `farmer_id` bigint(20) unsigned NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `scheme_application_id` bigint(20) unsigned NOT NULL,
  `sch_man_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sch_man_name_bn` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sch_man_father_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sch_man_father_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sch_man_mother_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sch_man_mother_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sch_man_division_id` bigint(20) unsigned NOT NULL,
  `sch_man_district_id` bigint(20) unsigned NOT NULL,
  `sch_man_upazilla_id` bigint(20) unsigned NOT NULL,
  `sch_man_union_id` bigint(20) unsigned NOT NULL,
  `sch_man_village` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sch_man_village_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sch_man_mobile_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sch_man_nid` bigint(20) unsigned NOT NULL,
  `pump_division_id` bigint(20) unsigned NOT NULL,
  `pump_district_id` bigint(20) unsigned NOT NULL,
  `pump_upazilla_id` bigint(20) unsigned NOT NULL,
  `pump_union_id` bigint(20) unsigned NOT NULL,
  `pump_mauza_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pump_mauza_no_bn` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pump_jl_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pump_jl_no_bn` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pump_plot_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pump_plot_no_bn` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `command_area_hector` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `general_minutes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `scheme_lands` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `scheme_map` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `affidavit_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_scheme_app_details_scheme_application_id_foreign` (`scheme_application_id`),
  CONSTRAINT `far_scheme_app_details_scheme_application_id_foreign` FOREIGN KEY (`scheme_application_id`) REFERENCES `far_scheme_application` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_scheme_app_details`
--

LOCK TABLES `far_scheme_app_details` WRITE;
/*!40000 ALTER TABLE `far_scheme_app_details` DISABLE KEYS */;
INSERT INTO `far_scheme_app_details` VALUES (1,19,'01730233031',1,'Md Mamunur Rashid','মোঃ মামুনুর রশিদ','Md Mijanur Rashman','মোঃ মিজানুর রহমান','Most Lucky Begum','লাকি বেগম',7,60,452,4155,'Debalaya','দেবালয়1','5343',73438483043,7,60,452,4155,'43','43','343','4343','4343','434343','10',NULL,NULL,NULL,0,'2021-03-15 06:52:53','2021-03-16 11:23:41'),(3,14,'01767778333',3,'Suman ','Suman bn','MD.Rafiqul Islam','মোঃ রফিকুল ইসলাম','Shahanara Begum','শাহানারা বেগম',1,1,1,1,'Sreemontapur','শ্রীমন্তপুর','01620506565',5641238745,1,1,1,1,'20','20','20','20','20','20','5','1616471710.jpg',NULL,NULL,0,'2021-03-23 03:55:10','2021-03-23 03:55:10'),(4,17,'',4,'Md Mamunur Rashid','মামুনুর রশিদ','Md Mijanur Rahman','মোঃ মামুনুর রশিদ','Most Lucky Begum','মোছাঃ লাকি বেগম',1,1,1,1,'Dabalay','দেবালয়','01635115613',37848394739,1,1,1,1,'11','11','11','11','1','11','1',NULL,NULL,NULL,0,'2021-03-23 04:32:35','2021-03-23 04:32:35'),(5,12,'01843867772',5,'Ruhul','রুহুল','Abdur Rahman','আব্দুর রহমান','Asiya Begum','আছিয়া বেগম',1,1,4,51,'Islabari','করোটা','01745336665',12121212121,1,1,4,51,'34','34','44','55','22','44','445',NULL,NULL,NULL,0,'2021-03-23 07:34:06','2021-03-23 07:34:06'),(6,202,'01730233032',6,'test Mamun','mama bn','fdfdf','dffdf','fddfdf','fdfdfd',1,1,1,1,'Debalaya','দেবালয়1','01730233032',4535,1,1,1,1,'43','43','343','4343','4343','434343','100',NULL,NULL,NULL,0,'2021-03-23 10:17:56','2021-03-23 10:17:56'),(7,12,'01843867772',7,'Ruhul','রুহুল','Abdur Rahman','আব্দুর রহমান','Asiya Begum','আছিয়া বেগম',1,1,4,51,'Islabari','করোটা','90545453453',12121212121,1,1,4,51,'Voluptas sit ea ull','In voluptatem minima','Iusto nobis culpa et','Laborum Reprehender','Est odit architecto ','Aut aut non ut dolor','Dolor nostrum asperi',NULL,NULL,NULL,0,'2021-03-24 10:49:35','2021-03-24 10:49:35'),(8,12,'01843867772',8,'Ruhul','রুহুল','Abdur Rahman','আব্দুর রহমান','Asiya Begum','আছিয়া বেগম',1,1,1,1,'Islabari','করোটা','01843867772',12121212121,1,1,1,1,'645','555','55','66','555','666','656',NULL,NULL,NULL,0,'2021-03-24 11:28:16','2021-03-24 11:28:16'),(9,220,'01531875147',9,'01531875147','01531875147','shamsuddin khan','shamsuddin khan','suriya begum','suriya begum',1,11,98,925,'12','dhaka','01531875147',12,4,35,266,2393,'1','111111111','22','2','12','1','12','1616827221.pdf','1616827221.pdf','1616827221.pdf',0,'2021-03-27 00:40:21','2021-03-27 00:40:51'),(10,225,'01531875147',10,'01531875147','01531875147','operator','operator','operator','operator',1,5,48,442,'12','1','01531875147',111,1,5,48,442,'1','3','2','3','3','2','12','1616910467.pdf','1616910467.pdf','1616910467.pdf',0,'2021-03-27 23:47:47','2021-03-27 23:47:47'),(11,248,'01754019430',11,'QA Test Farmer','QA Test Farmer(Bn)','QA Test Father Name','QA Test Father Name(Bn)','QA Test Mother Name','QA Test Mother Name',10,65,492,4541,'QA Test Village','QA Test Village(Bn)','01754019430',45634636,10,65,492,4541,'qwe','qwe bn','qwer','qwer bn','qwert','qwert bn','5','1618293887.pdf','1618293887.pdf','1618293887.pdf',0,'2021-04-13 00:04:47','2021-04-13 00:04:47');
/*!40000 ALTER TABLE `far_scheme_app_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_scheme_application`
--

DROP TABLE IF EXISTS `far_scheme_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_scheme_application` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `farmer_id` bigint(20) unsigned NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `application_id` bigint(20) unsigned NOT NULL,
  `application_type_id` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=New, 2=Resunk',
  `scheme_type_id` bigint(20) unsigned NOT NULL,
  `sub_scheme_type_id` int(11) DEFAULT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name_bn` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `father_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `father_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nid` bigint(20) unsigned NOT NULL,
  `far_division_id` bigint(20) unsigned NOT NULL,
  `far_district_id` bigint(20) unsigned NOT NULL,
  `far_upazilla_id` bigint(20) unsigned NOT NULL,
  `far_union_id` bigint(20) unsigned NOT NULL,
  `far_village` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `far_village_bn` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `far_mobile_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1=Pending, 2=processing, 3=Approved, 4=Review, 5=Reject, 6=current_status,7=verified,8=aggrement,9=requisition,10=supply,11=installation,12=Participation fee,13=Closed, 14=Installed',
  `payment_status` tinyint(4) NOT NULL DEFAULT '0',
  `is_license` tinyint(4) NOT NULL DEFAULT '0',
  `final_approve` tinyint(4) NOT NULL DEFAULT '0',
  `pump_id` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `total_farmer` int(11) DEFAULT NULL,
  `added_farmer` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `far_scheme_application_application_id_unique` (`application_id`),
  KEY `far_scheme_application_scheme_type_id_foreign` (`scheme_type_id`),
  KEY `far_scheme_application_name_index` (`name`),
  KEY `far_scheme_application_email_index` (`email`),
  KEY `far_scheme_application_far_district_id_index` (`far_district_id`),
  KEY `far_scheme_application_far_upazilla_id_index` (`far_upazilla_id`),
  KEY `far_scheme_application_far_union_id_index` (`far_union_id`),
  CONSTRAINT `far_scheme_application_scheme_type_id_foreign` FOREIGN KEY (`scheme_type_id`) REFERENCES `master_scheme_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_scheme_application`
--

LOCK TABLES `far_scheme_application` WRITE;
/*!40000 ALTER TABLE `far_scheme_application` DISABLE KEYS */;
INSERT INTO `far_scheme_application` VALUES (1,19,'01730233031',100000,1,1,1,3,'Test Rashid','মোঃ মামুনুর রশিদ','Md Mijanur Rashman','মোঃ মিজানুর রহমান','Most Lucky Begum','লাকি বেগম',73438483043,7,60,452,4155,'Debalaya','দেবালয়1','345465',1,1,0,0,NULL,'2021-03-15 06:52:53','2021-03-15 06:53:32',34,NULL),(3,14,'01767778333',100001,1,2,0,3,'Suman ','Suman bn','MD.Rafiqul Islam','মোঃ রফিকুল ইসলাম','Shahanara Begum','শাহানারা বেগম',5641238745,1,1,1,1,'Sreemontapur','শ্রীমন্তপুর','01620506565',14,1,0,0,'39','2021-03-23 03:55:10','2021-03-23 05:31:28',5,3),(4,17,'01916875375',100002,1,2,2,3,'Md Mamunur Rashid','মামুনুর রশিদ','Md Mijanur Rahman','মোঃ মামুনুর রশিদ','Most Lucky Begum','মোছাঃ লাকি বেগম',37848394739,1,1,1,1,'Dabalay','দেবালয়','01635115613',14,1,0,0,'41','2021-03-23 04:32:35','2021-03-27 04:34:41',5,1),(6,202,'01730233032',100004,1,2,0,3,'test Mamun','mama bn','fdfdf','dffdf','fddfdf','fdfdfd',4535,1,1,1,1,'Debalaya','দেবালয়1','01730233032',14,1,0,0,'40','2021-03-23 10:17:56','2021-03-23 11:24:35',3,2),(8,12,'01843867772',100005,1,1,1,15,'Ruhul','রুহুল','Abdur Rahman','আব্দুর রহমান','Asiya Begum','আছিয়া বেগম',12121212121,1,1,1,1,'Islabari','করোটা','01843867772',8,1,0,0,NULL,'2021-03-24 11:28:15','2021-03-25 06:27:15',5,1),(9,220,'01531875147',100006,1,2,0,3,'01531875147','01531875147','shamsuddin khan','shamsuddin khan','suriya begum','suriya begum',12,6,47,366,3284,'12','dhaka','01531875147',1,0,0,0,NULL,'2021-03-27 00:40:21','2021-03-27 00:41:22',2,NULL),(10,225,'01531875147',100007,1,2,0,3,'01531875147','01531875147','operator','operator','operator','operator',111,1,5,48,442,'12','1','01531875147',1,0,0,0,NULL,'2021-03-27 23:47:47','2021-03-27 23:47:47',4,NULL),(11,248,'01754019430',100008,1,9,5,3,'QA Test Farmer','QA Test Farmer(Bn)','QA Test Father Name','QA Test Father Name(Bn)','QA Test Mother Name','QA Test Mother Name',45634636,10,65,492,4541,'QA Test Village','QA Test Village(Bn)','01754019430',4,1,0,0,NULL,'2021-04-13 00:04:46','2021-04-13 04:31:10',3,3);
/*!40000 ALTER TABLE `far_scheme_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_scheme_license`
--

DROP TABLE IF EXISTS `far_scheme_license`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_scheme_license` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scheme_application_id` bigint(20) unsigned NOT NULL,
  `license_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `issue_date` date NOT NULL,
  `attachment` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_verified` tinyint(4) NOT NULL DEFAULT '0',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_scheme_license_scheme_application_id_foreign` (`scheme_application_id`),
  CONSTRAINT `far_scheme_license_scheme_application_id_foreign` FOREIGN KEY (`scheme_application_id`) REFERENCES `far_scheme_application` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_scheme_license`
--

LOCK TABLES `far_scheme_license` WRITE;
/*!40000 ALTER TABLE `far_scheme_license` DISABLE KEYS */;
INSERT INTO `far_scheme_license` VALUES (1,3,'234hfd','2021-03-23','1616472163.jpg',1,1,1,'2021-03-23 04:02:43','2021-03-23 04:02:49'),(2,4,'dsfg234453475','2021-03-23','1616479955.jpg',1,1,1,'2021-03-23 06:12:35','2021-03-23 06:12:39'),(3,6,'asdf32534','2021-03-23','1616497795.docx',1,1,1,'2021-03-23 11:09:55','2021-03-23 11:10:00'),(4,5,'12453','2021-03-24','1616580438.pdf',1,1,1,'2021-03-24 10:07:18','2021-03-24 10:07:22'),(5,8,'784536','2021-03-25','1616653595.jpg',1,212,212,'2021-03-25 06:26:35','2021-03-25 06:27:00');
/*!40000 ALTER TABLE `far_scheme_license` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_scheme_notes`
--

DROP TABLE IF EXISTS `far_scheme_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_scheme_notes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scheme_application_id` bigint(20) unsigned NOT NULL,
  `note` text COLLATE utf8_unicode_ci,
  `note_bn` text COLLATE utf8_unicode_ci,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_scheme_notes_scheme_application_id_foreign` (`scheme_application_id`),
  CONSTRAINT `far_scheme_notes_scheme_application_id_foreign` FOREIGN KEY (`scheme_application_id`) REFERENCES `far_scheme_application` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_scheme_notes`
--

LOCK TABLES `far_scheme_notes` WRITE;
/*!40000 ALTER TABLE `far_scheme_notes` DISABLE KEYS */;
INSERT INTO `far_scheme_notes` VALUES (1,3,'sdd ','sdff',1,1,0,'2021-03-23 04:01:05','2021-03-23 04:01:05'),(2,4,'sdf','sdf',1,1,0,'2021-03-23 06:10:16','2021-03-23 06:10:16'),(3,6,'asdf','asdf',1,1,0,'2021-03-23 11:08:17','2021-03-23 11:08:17'),(4,5,'asdf','asdf',1,1,0,'2021-03-24 10:06:35','2021-03-24 10:06:35');
/*!40000 ALTER TABLE `far_scheme_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_scheme_projects`
--

DROP TABLE IF EXISTS `far_scheme_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_scheme_projects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scheme_application_id` bigint(20) unsigned NOT NULL,
  `project_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_scheme_projects_scheme_application_id_foreign` (`scheme_application_id`),
  KEY `far_scheme_projects_project_id_foreign` (`project_id`),
  CONSTRAINT `far_scheme_projects_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `master_projects` (`id`),
  CONSTRAINT `far_scheme_projects_scheme_application_id_foreign` FOREIGN KEY (`scheme_application_id`) REFERENCES `far_scheme_application` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_scheme_projects`
--

LOCK TABLES `far_scheme_projects` WRITE;
/*!40000 ALTER TABLE `far_scheme_projects` DISABLE KEYS */;
INSERT INTO `far_scheme_projects` VALUES (15,3,1,1,1,0,'2021-03-23 04:00:25','2021-03-23 04:00:25'),(16,4,5,1,1,0,'2021-03-23 05:39:56','2021-03-23 06:09:40'),(17,6,2,1,1,0,'2021-03-23 11:06:33','2021-03-23 11:06:33'),(18,5,2,1,1,0,'2021-03-24 10:06:23','2021-03-24 10:06:23'),(19,1,3,1,1,0,'2021-03-24 14:13:12','2021-03-24 14:13:12'),(20,8,3,212,212,0,'2021-03-25 06:13:28','2021-03-25 06:13:28'),(21,11,14,1,1,0,'2021-04-13 04:27:55','2021-04-13 04:27:55');
/*!40000 ALTER TABLE `far_scheme_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_scheme_rejects`
--

DROP TABLE IF EXISTS `far_scheme_rejects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_scheme_rejects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scheme_application_id` bigint(20) unsigned NOT NULL,
  `reject_note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `reject_note_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_scheme_rejects_scheme_application_id_foreign` (`scheme_application_id`),
  CONSTRAINT `far_scheme_rejects_scheme_application_id_foreign` FOREIGN KEY (`scheme_application_id`) REFERENCES `far_scheme_application` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_scheme_rejects`
--

LOCK TABLES `far_scheme_rejects` WRITE;
/*!40000 ALTER TABLE `far_scheme_rejects` DISABLE KEYS */;
/*!40000 ALTER TABLE `far_scheme_rejects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_scheme_req_details`
--

DROP TABLE IF EXISTS `far_scheme_req_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_scheme_req_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `requisition_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `quantity` double(8,2) NOT NULL,
  `accepted_quantity` double(8,2) NOT NULL DEFAULT '0.00',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_scheme_req_details_requisition_id_foreign` (`requisition_id`),
  CONSTRAINT `far_scheme_req_details_requisition_id_foreign` FOREIGN KEY (`requisition_id`) REFERENCES `far_scheme_requisitions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_scheme_req_details`
--

LOCK TABLES `far_scheme_req_details` WRITE;
/*!40000 ALTER TABLE `far_scheme_req_details` DISABLE KEYS */;
INSERT INTO `far_scheme_req_details` VALUES (1,1,1,50.00,0.00,NULL,NULL,'2021-03-23 04:21:05','2021-03-23 04:21:05'),(2,2,1,10.00,0.00,NULL,NULL,'2021-03-23 06:16:48','2021-03-23 06:16:48'),(3,3,1,50.00,0.00,NULL,NULL,'2021-03-23 11:22:36','2021-03-23 11:22:36');
/*!40000 ALTER TABLE `far_scheme_req_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_scheme_requisitions`
--

DROP TABLE IF EXISTS `far_scheme_requisitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_scheme_requisitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `office_id` bigint(20) unsigned NOT NULL,
  `pump_type_id` bigint(20) unsigned NOT NULL,
  `requisition_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remarks` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remarks_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `requisition_date` date NOT NULL,
  `id_serial` bigint(20) unsigned NOT NULL,
  `scheme_application_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1=Pending, 2=Receive, 3=Approve, 4=Forward, 5=Allocate, 6=Quantity edit',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_scheme_requisitions_scheme_application_id_foreign` (`scheme_application_id`),
  KEY `far_scheme_requisitions_pump_type_id_foreign` (`pump_type_id`),
  CONSTRAINT `far_scheme_requisitions_pump_type_id_foreign` FOREIGN KEY (`pump_type_id`) REFERENCES `master_pump_types` (`id`),
  CONSTRAINT `far_scheme_requisitions_scheme_application_id_foreign` FOREIGN KEY (`scheme_application_id`) REFERENCES `far_scheme_application` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_scheme_requisitions`
--

LOCK TABLES `far_scheme_requisitions` WRITE;
/*!40000 ALTER TABLE `far_scheme_requisitions` DISABLE KEYS */;
INSERT INTO `far_scheme_requisitions` VALUES (1,3,1,1,'100001','test remark','test remark bn','2021-03-23',0,3,1,1,3,'2021-03-23 04:21:05','2021-03-23 05:17:23'),(2,3,1,1,'100002','test remark','test remark bn','2021-03-23',0,4,1,1,3,'2021-03-23 06:16:48','2021-03-23 06:17:08'),(3,3,1,1,'100003','trtr','trtrtr','2021-03-23',0,6,1,1,3,'2021-03-23 11:22:36','2021-03-23 11:22:44');
/*!40000 ALTER TABLE `far_scheme_requisitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_scheme_reviews`
--

DROP TABLE IF EXISTS `far_scheme_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_scheme_reviews` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scheme_application_id` bigint(20) unsigned NOT NULL,
  `review_note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `review_note_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_scheme_reviews_scheme_application_id_foreign` (`scheme_application_id`),
  CONSTRAINT `far_scheme_reviews_scheme_application_id_foreign` FOREIGN KEY (`scheme_application_id`) REFERENCES `far_scheme_application` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_scheme_reviews`
--

LOCK TABLES `far_scheme_reviews` WRITE;
/*!40000 ALTER TABLE `far_scheme_reviews` DISABLE KEYS */;
INSERT INTO `far_scheme_reviews` VALUES (1,4,'sdf','asdf',1,1,0,'2021-03-23 05:48:06','2021-03-23 05:48:06'),(2,11,'Reviewed by Admin','Reviewed by Admin Bn',1,1,0,'2021-04-13 04:31:10','2021-04-13 04:31:10');
/*!40000 ALTER TABLE `far_scheme_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_scheme_supply_equipments`
--

DROP TABLE IF EXISTS `far_scheme_supply_equipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_scheme_supply_equipments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `supply_note` text COLLATE utf8_unicode_ci NOT NULL,
  `supply_note_bn` text COLLATE utf8_unicode_ci,
  `supply_date` date NOT NULL,
  `requisition_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_scheme_supply_equipments_requisition_id_foreign` (`requisition_id`),
  CONSTRAINT `far_scheme_supply_equipments_requisition_id_foreign` FOREIGN KEY (`requisition_id`) REFERENCES `far_scheme_requisitions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_scheme_supply_equipments`
--

LOCK TABLES `far_scheme_supply_equipments` WRITE;
/*!40000 ALTER TABLE `far_scheme_supply_equipments` DISABLE KEYS */;
INSERT INTO `far_scheme_supply_equipments` VALUES (1,'sdf','sdf','2021-03-23',1,1,1,'2021-03-23 05:19:39','2021-03-23 05:19:39'),(2,'sadf','asdfsdaf','2021-03-23',2,1,1,'2021-03-23 06:25:31','2021-03-23 06:25:31'),(3,'f','f','2021-03-01',3,1,1,'2021-03-23 11:23:11','2021-03-23 11:23:11');
/*!40000 ALTER TABLE `far_scheme_supply_equipments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_scheme_surveys`
--

DROP TABLE IF EXISTS `far_scheme_surveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_scheme_surveys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scheme_application_id` bigint(20) unsigned NOT NULL,
  `survey_date` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `suggestion` text COLLATE utf8_unicode_ci,
  `suggestion_bn` text COLLATE utf8_unicode_ci,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_scheme_surveys_scheme_application_id_foreign` (`scheme_application_id`),
  CONSTRAINT `far_scheme_surveys_scheme_application_id_foreign` FOREIGN KEY (`scheme_application_id`) REFERENCES `far_scheme_application` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_scheme_surveys`
--

LOCK TABLES `far_scheme_surveys` WRITE;
/*!40000 ALTER TABLE `far_scheme_surveys` DISABLE KEYS */;
INSERT INTO `far_scheme_surveys` VALUES (2,5,'2021-03-02','test suggestion','test suggestion bn',1,1,0,'2021-03-02 12:09:11','2021-03-02 12:09:11'),(4,4,'2021-03-03','sfdgsdhs','dfhrhtrh',40,40,0,'2021-03-03 04:52:31','2021-03-03 04:52:31'),(18,7,'2021-03-03','test suggestion','test pump plot no bn',1,1,0,'2021-03-03 05:21:41','2021-03-03 05:21:41'),(19,8,'2021-03-03','test suggestion','test suggestion bn',1,1,0,'2021-03-03 05:31:57','2021-03-03 05:31:57'),(21,30,'2021-03-04','test suggestion','',1,1,0,'2021-03-04 05:38:26','2021-03-04 05:38:26'),(22,32,'2021-03-04','test','',1,1,0,'2021-03-04 06:30:35','2021-03-04 06:30:35'),(23,36,'2021-03-01','ok','',30,30,0,'2021-03-06 00:11:34','2021-03-06 00:11:34'),(24,38,'2021-03-07','sdf','asdf',1,1,0,'2021-03-07 09:47:32','2021-03-07 09:47:32'),(25,39,'2021-03-08','asdf','asdf',1,1,0,'2021-03-07 10:15:47','2021-03-07 10:15:47'),(26,3,'2021-03-23','ssd','sssd bn',1,1,0,'2021-03-23 04:01:05','2021-03-23 04:01:05'),(28,6,'2021-03-23','asdf','asdf',1,1,0,'2021-03-23 11:08:17','2021-03-23 11:08:17'),(29,5,'2021-03-24','asdf','asdf',1,1,0,'2021-03-24 10:06:35','2021-03-24 10:06:35');
/*!40000 ALTER TABLE `far_scheme_surveys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_smart_card_apps`
--

DROP TABLE IF EXISTS `far_smart_card_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_smart_card_apps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `farmer_id` bigint(20) unsigned NOT NULL,
  `id_serial` bigint(20) unsigned DEFAULT NULL,
  `application_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `father_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `father_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mother_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marital_status` tinyint(4) NOT NULL,
  `spouse_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `spouse_name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `no_of_child` tinyint(4) NOT NULL,
  `nid` bigint(20) unsigned NOT NULL,
  `mobile_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(4) NOT NULL,
  `far_division_id` bigint(20) unsigned NOT NULL,
  `far_district_id` bigint(20) unsigned NOT NULL,
  `far_upazilla_id` bigint(20) unsigned NOT NULL,
  `far_union_id` bigint(20) unsigned NOT NULL,
  `far_village` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `far_village_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ward_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `date_of_birth` date NOT NULL,
  `qualification` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attachment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `owned_land` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lease_land` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `barga_land` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_land` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `training_info` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `earnings` double DEFAULT NULL,
  `crop_plan` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `crop_plan_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Pending, 2=processing, 3 =approved ,4=generated, 5=issued , 6 =reject , 7 = reviewed',
  `reissue_status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=new application, 2=reissue application',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `approval_date` date DEFAULT NULL,
  `payment_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `far_smart_card_apps_name_index` (`name`),
  KEY `far_smart_card_apps_email_index` (`email`),
  KEY `far_smart_card_apps_mobile_no_index` (`mobile_no`),
  KEY `far_smart_card_apps_far_district_id_index` (`far_district_id`),
  KEY `far_smart_card_apps_far_upazilla_id_index` (`far_upazilla_id`),
  KEY `far_smart_card_apps_far_union_id_index` (`far_union_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_smart_card_apps`
--

LOCK TABLES `far_smart_card_apps` WRITE;
/*!40000 ALTER TABLE `far_smart_card_apps` DISABLE KEYS */;
INSERT INTO `far_smart_card_apps` VALUES (1,3,13,1000,'smtc#1000','farmer3@gmail.com','Test farmer name','Test farmer name bn','test father name','test father name bn','test mother name','test mother name bn',1,'test spouse name',' পত্নীর নাম',2,1425472454,'01723019011',1,1,1,1,1,'Test village ','Test village bn','20','1980-03-10','class 8','1616649556.jpg','20','5','10','35','test training info',30000,'test crop plan','শস্য পরিকল্পনা','2021-03-15 05:25:27','2021-03-31 05:43:31',4,1,NULL,NULL,1),(3,15,12,1001,'smtc#1001','ruhul@gmail.com','Ruhul','রুহুল','Abdur Rahman','আব্দুর রহমান','Asiya Begum','আছিয়া বেগম',2,NULL,NULL,0,12121212121,'79',1,5,1,13,41,'Islabari','করোটা','59','2021-03-18','In exercitationem il','1616649556.jpg','5','45','5','55','Iusto enim aliqua A',74,'Aliquam eum fugiat ','Voluptatem minim exp','2021-03-25 05:19:16','2021-03-25 05:19:16',1,1,NULL,NULL,0),(4,3,225,1002,'smtc#1002','01531875147@test.com','01531875147','01531875147','operator','operator','operator','operator',1,'3','3',3,111,'01531875147',1,1,1,9,102,'12','1','11','2021-03-10',NULL,'1616649556.jpg','1','1','1','3',NULL,NULL,NULL,NULL,'2021-03-27 23:50:44','2021-03-27 23:50:44',1,1,NULL,NULL,0),(5,3,225,1003,'smtc#1003','01531875147@test.com','01531875147','01531875147','operator','operator','operator','operator',1,'3','3',3,111,'01531875147',1,1,1,9,102,'12','1','11','2021-03-10',NULL,'1616649556.jpg','1','1','1','3',NULL,NULL,NULL,NULL,'2021-03-27 23:50:55','2021-03-27 23:50:55',1,1,NULL,NULL,0),(6,15,226,1004,'smtc#1004','tt@gmail.com','1','1','1','4','1','4',2,NULL,NULL,0,4,'01924496004',1,1,1,1,8,'4','4','64','2021-03-29',NULL,'1616649556.jpg','0','0','0','0',NULL,NULL,NULL,NULL,'2021-03-28 22:36:19','2021-03-28 22:36:19',1,1,NULL,NULL,0),(7,15,226,1005,'smtc#1005','tt@gmail.com','1','1','1','4','1','4',2,NULL,NULL,0,4,'01924496004',1,1,1,1,8,'4','4','64','2021-03-29',NULL,'1616649556.jpg','0','0','0','0',NULL,NULL,NULL,NULL,'2021-03-28 22:36:25','2021-03-28 22:39:06',4,1,NULL,NULL,1),(8,3,248,1006,'smtc#1006','fm_67959140@gmail.com','QA Test Farmer','QA Test Farmer(Bn)','QA Test Father Name','QA Test Father Name(Bn)','QA Test Mother Name','QA Test Mother Name',1,NULL,NULL,0,45634636,'01754019430',1,10,65,492,4541,'QA Test Village','QA Test Village(Bn)','123','2021-04-12','a','1618202691.jpg','2','2','2','6','s',2222,'s','ss','2021-04-11 22:44:51','2021-04-11 22:56:02',1,1,NULL,NULL,1),(9,3,248,1007,'smtc#1007','fm_67959140@gmail.com','QA Test Farmer','QA Test Farmer(Bn)','QA Test Father Name','QA Test Father Name(Bn)','QA Test Mother Name','QA Test Mother Name',1,'ss','ss',3,45634636,'01754019430',1,10,65,492,4541,'QA Test Village','QA Test Village(Bn)','123','2021-04-12','a','1618202721.jpg','2','2','2','6','s',2222,'s','ss','2021-04-11 22:45:21','2021-04-11 22:46:13',1,1,NULL,NULL,1);
/*!40000 ALTER TABLE `far_smart_card_apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_smart_card_rejects`
--

DROP TABLE IF EXISTS `far_smart_card_rejects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_smart_card_rejects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `far_smart_card_apps_id` bigint(20) unsigned NOT NULL,
  `reject_note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `reject_note_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_smart_card_rejects_far_smart_card_apps_id_foreign` (`far_smart_card_apps_id`),
  CONSTRAINT `far_smart_card_rejects_far_smart_card_apps_id_foreign` FOREIGN KEY (`far_smart_card_apps_id`) REFERENCES `far_smart_card_apps` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_smart_card_rejects`
--

LOCK TABLES `far_smart_card_rejects` WRITE;
/*!40000 ALTER TABLE `far_smart_card_rejects` DISABLE KEYS */;
/*!40000 ALTER TABLE `far_smart_card_rejects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_smart_card_review`
--

DROP TABLE IF EXISTS `far_smart_card_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_smart_card_review` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `far_smart_card_apps_id` bigint(20) unsigned NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_smart_card_review_far_smart_card_apps_id_foreign` (`far_smart_card_apps_id`),
  CONSTRAINT `far_smart_card_review_far_smart_card_apps_id_foreign` FOREIGN KEY (`far_smart_card_apps_id`) REFERENCES `far_smart_card_apps` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_smart_card_review`
--

LOCK TABLES `far_smart_card_review` WRITE;
/*!40000 ALTER TABLE `far_smart_card_review` DISABLE KEYS */;
/*!40000 ALTER TABLE `far_smart_card_review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_water_rejects`
--

DROP TABLE IF EXISTS `far_water_rejects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_water_rejects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `far_water_test_apps_id` bigint(20) unsigned NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_water_rejects_far_water_test_apps_id_foreign` (`far_water_test_apps_id`),
  CONSTRAINT `far_water_rejects_far_water_test_apps_id_foreign` FOREIGN KEY (`far_water_test_apps_id`) REFERENCES `far_water_test_apps` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_water_rejects`
--

LOCK TABLES `far_water_rejects` WRITE;
/*!40000 ALTER TABLE `far_water_rejects` DISABLE KEYS */;
INSERT INTO `far_water_rejects` VALUES (1,1,'test se','test ee','2021-03-18 05:19:20','2021-03-18 05:19:20');
/*!40000 ALTER TABLE `far_water_rejects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_water_samples`
--

DROP TABLE IF EXISTS `far_water_samples`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_water_samples` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `far_water_test_apps_id` bigint(20) unsigned NOT NULL,
  `laboratory_id` bigint(20) unsigned NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `note_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_water_samples_far_water_test_apps_id_foreign` (`far_water_test_apps_id`),
  KEY `far_water_samples_laboratory_id_foreign` (`laboratory_id`),
  CONSTRAINT `far_water_samples_far_water_test_apps_id_foreign` FOREIGN KEY (`far_water_test_apps_id`) REFERENCES `far_water_test_apps` (`id`),
  CONSTRAINT `far_water_samples_laboratory_id_foreign` FOREIGN KEY (`laboratory_id`) REFERENCES `master_laboratories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_water_samples`
--

LOCK TABLES `far_water_samples` WRITE;
/*!40000 ALTER TABLE `far_water_samples` DISABLE KEYS */;
INSERT INTO `far_water_samples` VALUES (1,6,1,NULL,NULL,'2021-03-24 08:44:59','2021-03-24 08:44:59'),(2,7,2,NULL,NULL,'2021-03-24 08:46:03','2021-03-24 08:46:03'),(3,8,18,NULL,NULL,'2021-03-24 09:06:09','2021-03-24 09:06:09'),(4,9,1,NULL,NULL,'2021-03-24 09:06:26','2021-03-24 09:06:26'),(5,10,19,NULL,NULL,'2021-03-24 12:32:39','2021-03-24 12:32:39'),(6,11,19,NULL,NULL,'2021-03-24 12:32:51','2021-03-24 12:32:51'),(7,12,1,NULL,NULL,'2021-03-25 09:18:24','2021-03-25 09:18:24'),(8,13,2,'efsd','fsdfsfdfsdfsdf','2021-03-25 09:22:45','2021-03-25 09:22:45');
/*!40000 ALTER TABLE `far_water_samples` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_water_test_apps`
--

DROP TABLE IF EXISTS `far_water_test_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_water_test_apps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `farmer_id` bigint(20) unsigned DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sample_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sample_serial` bigint(20) unsigned DEFAULT NULL,
  `name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `testing_type_id` tinyint(4) NOT NULL,
  `far_division_id` bigint(20) unsigned DEFAULT NULL,
  `far_district_id` bigint(20) unsigned DEFAULT NULL,
  `far_upazilla_id` bigint(20) unsigned DEFAULT NULL,
  `far_union_id` bigint(20) unsigned DEFAULT NULL,
  `far_village` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `far_village_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Pending, 2=processing, 3 =send lab ,4=report Collected, 5=Reported,6=rejected',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `application_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_serial` int(11) DEFAULT NULL,
  `water_testing_parameter_id` text COLLATE utf8_unicode_ci,
  `payment_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `far_water_test_apps_name_index` (`name`),
  KEY `far_water_test_apps_email_index` (`email`),
  KEY `far_water_test_apps_far_district_id_index` (`far_district_id`),
  KEY `far_water_test_apps_far_upazilla_id_index` (`far_upazilla_id`),
  KEY `far_water_test_apps_far_union_id_index` (`far_union_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_water_test_apps`
--

LOCK TABLES `far_water_test_apps` WRITE;
/*!40000 ALTER TABLE `far_water_test_apps` DISABLE KEYS */;
INSERT INTO `far_water_test_apps` VALUES (1,3,13,'01782599354','Test farmer name','31100001',10000,'Test farmer name bn',1,1,1,1,1,'Test village ','Test village bn','2021-03-15','2021-03-15',6,'2021-03-15 07:13:59','2021-03-18 05:19:20','wtappid#10000',NULL,NULL,1),(2,3,19,'01730233031','Md Mamunur Rashid','31100014',10001,'মোঃ মামুনুর রশিদ',1,4,30,230,2088,'Debalaya','দেবালয়1','2021-03-01','2021-03-10',1,'2021-03-18 09:23:39','2021-03-18 12:12:56','wtappid#10000',NULL,'[{\"value\":5,\"org_id\":3,\"testing_type_id\":1,\"text_en\":\"Suman\",\"text_bn\":\"Suman\",\"status\":0,\"text\":\"Suman\",\"amount\":0},{\"value\":6,\"org_id\":3,\"testing_type_id\":1,\"text_en\":\"Sumanrr\",\"text_bn\":\"Sumanrr\",\"status\":0,\"text\":\"Sumanrr\",\"amount\":0}]',0),(3,3,19,'01730233031','Md Mamunur Rashid','31100023',10002,'মোঃ মামুনুর রশিদ',1,7,60,452,4155,'Debalaya','দেবালয়1','2021-03-01','2021-03-01',1,'2021-03-18 11:05:25','2021-03-18 11:05:30','wtappid#10001',NULL,'[{\"value\":1,\"org_id\":3,\"testing_type_id\":1,\"text_en\":\"fdf dfdf fddd dddddf\",\"text_bn\":\"fdf dfdf fddd dddddf\",\"status\":0,\"text\":\"fdf dfdf fddd dddddf\",\"amount\":10},{\"value\":3,\"org_id\":3,\"testing_type_id\":1,\"text_en\":\"fffff fd d fffdf ffffffffffff \",\"text_bn\":\"fffff fd d fffdf ffffffffffff \",\"status\":1,\"text\":\"fffff fd d fffdf ffffffffffff \",\"amount\":30}]',1),(4,3,19,'01730233031','Md Mamunur Rashid','31100034',10003,'মোঃ মামুনুর রশিদ',1,7,60,452,4155,'Debalaya','দেবালয়1','2021-03-01','2021-03-22',1,'2021-03-18 12:19:34','2021-03-18 12:19:34','wtappid#10002',NULL,'[{\"value\":5,\"org_id\":3,\"testing_type_id\":1,\"text_en\":\"Suman\",\"text_bn\":\"Suman\",\"status\":0,\"text\":\"Suman\",\"amount\":0}]',0),(5,3,19,'01730233034','Md Mamunur Rashid','31100045',10004,'মোঃ মামুনুর রশিদ',1,7,60,452,4155,'Debalaya','দেবালয়1','2021-03-29','2021-03-23',1,'2021-03-23 06:50:48','2021-03-23 06:50:48','wtappid#10003',NULL,'[{\"value\":5,\"org_id\":3,\"testing_type_id\":1,\"text_en\":\"Drinking water 1\",\"text_bn\":\"Drinking water 1 Bn\",\"status\":0,\"text\":\"Drinking water 1\",\"amount\":1000},{\"value\":8,\"org_id\":3,\"testing_type_id\":1,\"text_en\":\"drinking 2\",\"text_bn\":\"drinking 2 Bn\",\"status\":0,\"text\":\"drinking 2\",\"amount\":0},{\"value\":9,\"org_id\":3,\"testing_type_id\":1,\"text_en\":\"Drinking 3\",\"text_bn\":\"Drinking 3 Bn\",\"status\":0,\"text\":\"Drinking 3\",\"amount\":0}]',0),(6,3,NULL,NULL,NULL,'31100056',10005,NULL,1,0,0,0,0,NULL,NULL,'2021-03-01','2021-03-02',4,'2021-03-24 08:44:59','2021-03-24 08:47:08','wtappid#10004',NULL,NULL,0),(7,15,NULL,NULL,NULL,'152100063',10006,NULL,2,0,0,0,0,NULL,NULL,'2021-03-01','2021-03-03',4,'2021-03-24 08:46:03','2021-03-24 08:48:29','wtappid#10005',NULL,NULL,0),(8,3,NULL,NULL,NULL,'33100073',10007,NULL,3,0,0,0,0,NULL,NULL,'2021-03-01','2021-03-05',4,'2021-03-24 09:06:09','2021-03-24 09:08:56','wtappid#10006',NULL,NULL,0),(9,3,NULL,NULL,NULL,'32100083',10008,NULL,2,0,0,0,0,NULL,NULL,'2021-03-07','2021-03-12',4,'2021-03-24 09:06:26','2021-03-24 09:08:36','wtappid#10007',NULL,NULL,0),(10,15,NULL,NULL,NULL,'152100092',10009,NULL,2,0,0,0,0,NULL,NULL,'2021-03-01','2021-03-05',5,'2021-03-24 12:32:39','2021-04-13 03:19:10','wtappid#10008',NULL,NULL,0),(11,15,NULL,NULL,NULL,'153100103',10010,NULL,3,0,0,0,0,NULL,NULL,'2021-03-14','2021-03-18',5,'2021-03-24 12:32:51','2021-03-28 05:53:59','wtappid#10009',NULL,NULL,0),(12,3,NULL,NULL,NULL,'31100117',10011,NULL,1,0,0,0,0,NULL,NULL,'2021-03-21','2021-03-22',3,'2021-03-25 09:18:24','2021-03-25 09:18:24','wtappid#10010',NULL,NULL,0),(13,3,225,'01531875147','01531875147','31100128',10012,'01531875147',1,1,1,1,14,'12','1','2021-03-02','2021-03-09',1,'2021-03-27 23:51:39','2021-03-27 23:51:39','wtappid#10011',NULL,'[{\"value\":8,\"org_id\":3,\"testing_type_id\":1,\"text_en\":\"drinking 2\",\"text_bn\":\"drinking 2 Bn\",\"status\":0,\"text\":\"drinking 2 Bn\",\"amount\":0}]',0),(14,3,248,'01754019430','QA Test Farmer','311001310',10013,'QA Test Farmer(Bn)',1,10,65,492,4541,'QA Test Village','QA Test Village(Bn)','2021-04-11','2021-04-22',1,'2021-04-11 01:23:02','2021-04-11 01:23:48','wtappid#10012',NULL,'[{\"value\":5,\"org_id\":3,\"testing_type_id\":1,\"text_en\":\"Drinking water 1\",\"text_bn\":\"Drinking water 1 Bn\",\"status\":0,\"text\":\"Drinking water 1\",\"amount\":1000}]',0);
/*!40000 ALTER TABLE `far_water_test_apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `far_water_test_reports`
--

DROP TABLE IF EXISTS `far_water_test_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `far_water_test_reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `far_water_test_apps_id` bigint(20) unsigned NOT NULL,
  `memo_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `attachment` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `far_water_test_reports_far_water_test_apps_id_foreign` (`far_water_test_apps_id`),
  CONSTRAINT `far_water_test_reports_far_water_test_apps_id_foreign` FOREIGN KEY (`far_water_test_apps_id`) REFERENCES `far_water_test_apps` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `far_water_test_reports`
--

LOCK TABLES `far_water_test_reports` WRITE;
/*!40000 ALTER TABLE `far_water_test_reports` DISABLE KEYS */;
INSERT INTO `far_water_test_reports` VALUES (1,6,'4545454','1616575628.pdf','2021-03-24 08:47:08','2021-03-24 08:47:08'),(2,7,'rwwerwer','1616575709.pdf','2021-03-24 08:48:29','2021-03-24 08:48:29'),(3,9,'458765','1616576916.pdf','2021-03-24 09:08:36','2021-03-24 09:08:36'),(4,8,'876766','1616576936.pdf','2021-03-24 09:08:56','2021-03-24 09:08:56'),(5,10,'4545869798','1616589194.pdf','2021-03-24 12:33:14','2021-03-24 12:33:14'),(6,11,'78787878','1616589210.pdf','2021-03-24 12:33:30','2021-03-24 12:33:30'),(7,13,'sfdsfdsfdsf','1616664243.pdf','2021-03-25 09:24:03','2021-03-25 09:24:03');
/*!40000 ALTER TABLE `far_water_test_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `farmer_land_details`
--

DROP TABLE IF EXISTS `farmer_land_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `farmer_land_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `application_id` bigint(20) unsigned NOT NULL,
  `application_type` tinyint(3) unsigned NOT NULL COMMENT '1=scheme,2=pump_info',
  `far_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `far_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `far_father_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `far_father_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `far_mother_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `far_mother_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `far_division_id` bigint(20) unsigned NOT NULL,
  `far_district_id` bigint(20) unsigned NOT NULL,
  `far_upazilla_id` bigint(20) unsigned NOT NULL,
  `far_union_id` bigint(20) unsigned DEFAULT NULL,
  `far_village` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `far_village_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `far_nid` bigint(20) unsigned DEFAULT NULL,
  `far_mobile_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `own_land_amount` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `borga_land_amount` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lease_land_amount` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_land_amount` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `aus_crop_land` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amon_crop_land` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `boro_crop_land` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `other_crop_land` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remarks` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=active,2=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `farmer_land_details`
--

LOCK TABLES `farmer_land_details` WRITE;
/*!40000 ALTER TABLE `farmer_land_details` DISABLE KEYS */;
INSERT INTO `farmer_land_details` VALUES (5,16,2,'Brennan Evans','Jeremy Berg','Mufutau Price','Arden Barry','Dakota Howe','Logan Guzman',4,33,253,2288,'Iusto velit fugit ','Sed sit corrupti do',453534564,'0174526565656','56','56','4','116','45','456456','456456','4564565','45',1,'2021-03-03 12:31:03','2021-03-03 12:31:03'),(6,16,2,'Tobias Wiggins','Len Carr','Rachel Short','Nina Chan','Peter William','Emmanuel Wise',2,13,116,1058,'Autem repudiandae vo','Cillum nesciunt vol',88,'Labore dolorem corpo','35','56','546','637','Enim quis id nemo a','Iusto assumenda iure','Natus minim aliquip ','Impedit sit dolores','Odio officia assumen',1,'2021-03-03 12:56:33','2021-03-03 12:56:33'),(7,16,2,'gdfgdf','dfgdf','ghfhhfg','hfghfghg','fhfghfgh','fghfgh',5,38,296,2649,'fghfgh','fghfgh',345345,'3453454','3456','456','456','4368','fgfhf','fghfgh','fghfg','hfghffgh','gfhfghg',1,'2021-03-03 12:57:17','2021-03-03 12:57:17'),(8,4,1,'Brennan Evans','Jeremy Berg','Mufutau Price','Xenos Morse','Dakota Howe','Sierra Terry',3,21,181,1623,'Est doloremque faci','Quasi debitis ipsa ',32235656,'0218545454654','654','65','65','784','fgfghgfh','gfhfghfg','fghfgh','fgh','fghfgh',1,'2021-03-03 13:08:48','2021-03-03 13:08:48'),(10,35,1,'dd','33','rr','rr','444','44',2,14,129,1166,'44','44',3,'22','44','44','44','132',NULL,'4','44','44','rrffg',1,'2021-03-04 11:54:10','2021-03-04 11:54:10'),(11,35,1,'fff','ff','444','444','444','444',4,32,243,2202,'444','444',444,'444','44','44','444','532','44','44','44','444','444',1,'2021-03-04 11:54:36','2021-03-04 11:54:36'),(12,35,1,'4444','444','444','44','444','44',1,9,81,836,'44','44',444,'444','44','44','44','132','44','44','44','44','444',1,'2021-03-04 11:55:14','2021-03-04 11:55:14'),(13,32,1,'Reed Kline','Rhonda Doyle','Cullen Michael','Nayda Mccarty','Lunea Sweet','Steven Gaines',1,1,1,1,'Dolor sed quibusdam ','Impedit nisi eius e',69,'Sint porro quia mod','8','5','5','18','Perferendis quia cup','Dolorum non deserunt','Nisi nulla dolor ips','Quia ipsum nisi id u','Irure unde reprehend',1,'2021-03-06 04:25:42','2021-03-06 04:25:42'),(14,26,2,'Germaine Oneal','Florence Lloyd','Inga Strickland','Hamilton Baxter','Patrick Sawyer','Mark Franco',1,1,1,1,'Deleniti assumenda d','Ut ad ut voluptatem',15,'Sint est quas mole','1','1','1','3','Officia repellendus','Quos aliquam dolores','Perspiciatis nostru','Fugiat adipisicing ','Veritatis quia possi',1,'2021-03-06 08:51:18','2021-03-06 08:51:18'),(15,38,1,'ss','ss','s','s','s','s',1,1,1,1,'s','s',2974865,'01620506565','4','4','4','12','sdf','d','d','d','d',1,'2021-03-07 08:19:45','2021-03-07 08:19:45'),(16,32,1,'Deacon Dillard','Griffin Rodgers','Tanisha Benjamin','Luke Clark','Hu Cannon','Amery Brooks',1,1,1,1,'Natus quod provident','In hic reprehenderit',61,'Lorem sit dignissim','14','5','2','21','Esse est dolor corp','Minima inventore occ','Et tempore dolorem ','Et dolor quis soluta','Rerum esse eaque et',1,'2021-03-08 05:14:53','2021-03-08 05:14:53'),(17,32,1,'TEST NAME','TEST NAME BN','Leila Horn','Levi Barron','Kaitlin Turner','Kaden Dominguez',1,1,1,1,'Delectus numquam es','Itaque et quis nesci',75545454545454,'017554454545','15','2','5','22','Asperiores rem dolor','Voluptatum odio nisi','Aute molestiae reici','In eveniet deleniti','Dolor omnis dolore a',1,'2021-03-08 05:16:54','2021-03-08 05:16:54'),(18,3,1,'Aladdin Dorsey','Declan Meyers','Jesse Harper','Griffin Haynes','Armando Jarvis','Iona Holden',1,1,3,34,'Veniam omnis nemo m','Cumque nostrud odit ',63,'67','5','34','45','84.00','Reprehenderit est a','Laudantium excepteu','Voluptatem quis elig','Nihil aut suscipit q','Voluptatem sapiente ',1,'2021-03-23 09:11:02','2021-03-23 09:11:02'),(19,3,1,'fgvhfg','ghgh','gfhfgh','fghfgh','gfhfg','fghfgh',5,36,276,2476,'fghgfh','fghfg',45645665645,'546456456','5445','45','45','5535.00','ghhg','fghfgh','fghfgh','fghfhf','gfghfgfg',1,'2021-03-23 10:13:19','2021-03-23 10:13:19'),(21,3,1,'Nevada Bolton','Castor Rosario','Francesca Cummings','Rebekah Alvarado','Medge Tanner','Cassandra Beard',1,2,18,194,'Neque id eum volupta','Veniam consequat S',29,'33','444','444','555','1443.00','Est exercitation ac','Omnis eius dolore mo','Sapiente non anim pr','Duis aliquip odit co','Sequi consequatur c',1,'2021-03-23 10:15:35','2021-03-23 10:15:35'),(22,6,1,'Yuli Shannon','Emerson Delgado','Britanni Cohen','Rae Gallegos','Christine Berger','Asher Pollard',1,1,1,1,'Consequatur ad amet','Alias ut aspernatur ',20,'15','Dolorem aut perspici','Occaecat eiusmod a i','Sequi lorem iure cum','0.00','Quis earum officia c','Expedita ut quis lab','Recusandae Quia lab','Sunt molestiae dolor','Amet nobis enim qui',1,'2021-03-23 10:18:29','2021-03-23 10:18:29'),(23,5,1,'Herrod Whitehead','Wallace Mitchell','Russell Jenkins','Davis Reyes','Vladimir James','Ramona Ferrell',1,2,19,199,'Molestiae voluptate ','Minima voluptas fuga',48,'73','45','7','55','107.00','Id voluptatem lorem ','Delectus delectus ','Sequi labore a simil','Omnis quae aut quia ','Dolore amet odio il',1,'2021-03-23 10:20:52','2021-03-23 10:20:52'),(24,6,1,'Ahmed Green','Darrel Gomez','Maryam Larsen','Venus Burgess','Adrian Parsons','Uriah Shepard',8,62,467,4301,'Ipsum quo quam labo','Consequuntur eaque a',90,'55','Adipisci consequatur','Elit minima velit ','Laboris qui saepe al','0.00','Quam harum aut nulla','Placeat porro nisi ','Consequatur ut offi','Aut et consequatur ','Vel aut aliqua Comm',1,'2021-03-23 11:25:09','2021-03-23 11:25:09'),(25,13,2,'Iris Fowler','Aurora Byrd','Isabelle Wiley','Uriel Coleman','Lacy Barton','Mollie Terry',1,11,97,923,'Voluptatem Fugiat ','Sit eius nemo non a',32,'Sunt voluptas eum vo','5','5','5','15','Adipisci est eaque s','Sequi qui laboris au','Ipsum quisquam moles','Rerum voluptate maio','Velit voluptatem et',1,'2021-03-24 09:56:20','2021-03-24 09:56:20'),(26,42,2,'Emery Beach','Orson Kerr','Maris Chen','Macon Beasley','Arthur Newton','Adria Green',6,49,379,3431,'Et nisi temporibus i','Sed et architecto co',23,'Ut vel cillum porro ','1','1','1','3','Quia minima nostrum ','Earum sit pariatur ','Voluptate officia ne','Amet non esse pari','Adipisicing ex sit ',1,'2021-04-10 23:41:58','2021-04-10 23:41:58'),(27,42,2,'Janna Good','Jessica Perry','Iona Rose','Ivan Santana','Carly Riddle','Justine Compton',2,13,114,1048,'Eveniet at accusamu','Enim ut esse sequi ',8,'Unde est sint et of','2','2','2','6','Nulla eiusmod Nam il','Cumque in aperiam ni','Sint corrupti Nam ','Fuga Tempora ut lab','Nulla culpa aut duc',1,'2021-04-10 23:42:51','2021-04-10 23:42:51'),(28,42,2,'Yuli Velazquez','Akeem Bolton','Hanae Pittman','Rama Finch','Ann Patterson','Leandra Savage',4,33,253,2288,'Hic debitis quia mol','Atque amet est poss',9,'Tempore doloremque ','2','4','3','9','Fugiat elit suscipi','Quas ex exercitation','Voluptatum commodi a','Eos dolor nostrum v','Eum vitae veniam fu',1,'2021-04-10 23:43:33','2021-04-10 23:43:33'),(29,8,1,'rtyuy','ytuty','grfyrty','rtyrt','rtyrty','rtyrty',4,33,253,2287,'rtyrty','rtyrt',45645645,'45645645','67','675','67','809.00','utyu','tyutyu','tyuty','tyutyu','tyutyutyut',1,'2021-04-11 08:46:54','2021-04-11 08:46:54'),(30,11,1,'vcb','vb','ghfgh','fghf','ghf','fgh',8,63,481,4450,'hf','fgh',56,'6546','6','6','6','18.00','6','6','6','6','rhfghfg',1,'2021-04-13 04:09:47','2021-04-13 04:09:47'),(31,11,1,'ytr','try','hfg','hf','fgh','fgh',8,64,489,4516,'fgh','gh',66,'55','5','5','6','16.00','h','h','h','h','hh',1,'2021-04-13 04:10:30','2021-04-13 04:10:30'),(32,11,1,'hgjh','jgh','ry','rty','ry','rty',2,13,114,1048,'ty','ry',7657,'677','4','4','4','12.00','4','4','4','4','4trter',1,'2021-04-13 04:11:39','2021-04-13 04:11:39');
/*!40000 ALTER TABLE `farmer_land_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `irri_scheme_payments`
--

DROP TABLE IF EXISTS `irri_scheme_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `irri_scheme_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `master_payment_id` bigint(20) unsigned DEFAULT NULL,
  `org_id` bigint(20) unsigned DEFAULT NULL,
  `farmer_id` bigint(20) unsigned DEFAULT NULL,
  `scheme_application_id` bigint(20) unsigned NOT NULL,
  `payment_type_id` int(11) DEFAULT NULL,
  `scheme_type_id` int(11) DEFAULT NULL,
  `scheme_participation_fee_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `scheme_security_money_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `circle_area_id` bigint(20) unsigned DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `trnx_currency` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mac_addr` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `transaction_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=not redirect, 2=redirct',
  `pay_status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `irri_scheme_payments`
--

LOCK TABLES `irri_scheme_payments` WRITE;
/*!40000 ALTER TABLE `irri_scheme_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `irri_scheme_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `irrigation_payments`
--

DROP TABLE IF EXISTS `irrigation_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `irrigation_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `master_payment_id` bigint(20) unsigned DEFAULT NULL,
  `org_id` bigint(20) unsigned DEFAULT NULL,
  `farmer_id` bigint(20) unsigned DEFAULT NULL,
  `far_application_id` bigint(20) unsigned NOT NULL,
  `application_type` int(11) NOT NULL COMMENT '1=Scheme, 2=Pump Operation, 3=Smart Card, 4=Water Testing',
  `payment_type_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `present_balance` double DEFAULT NULL,
  `trnx_currency` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mac_addr` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `transaction_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=not redirect, 2=redirect',
  `pay_status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `scheme_type_id` int(11) DEFAULT NULL,
  `scheme_participation_fee_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `scheme_security_money_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `circle_area_id` bigint(20) unsigned DEFAULT NULL,
  `gender` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `irrigation_payments`
--

LOCK TABLES `irrigation_payments` WRITE;
/*!40000 ALTER TABLE `irrigation_payments` DISABLE KEYS */;
INSERT INTO `irrigation_payments` VALUES (1,0,3,13,1,3,1,1000.00,NULL,'BDT',NULL,'604EEFCE314B3',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-03-15 05:25:27','2021-03-15 05:25:34'),(2,154,3,13,1,4,1,100.00,NULL,'BDT','E4-54-E8-A5-1E-A3','604F094458D35',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-03-15 07:14:06','2021-03-15 07:14:12'),(3,153,3,14,1,2,1,300.00,NULL,'BDT',NULL,'60507BFE41A61',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-03-16 09:35:58','2021-03-16 09:35:58'),(4,0,3,14,2,3,1,500.00,NULL,'BDT',NULL,'6052D9DB16B99',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-18 04:40:59','2021-03-18 04:40:59'),(5,0,3,19,2,4,1,0.00,NULL,'BDT','00-FF-B6-87-5B-47','60531C1C03F95',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-18 09:23:41','2021-03-18 12:12:56'),(6,0,3,19,3,4,1,40.00,NULL,'BDT','00-FF-B6-87-5B-47','605333FAAA0B4',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-03-18 11:05:26','2021-03-18 11:05:30'),(7,0,3,19,4,4,1,0.00,NULL,'BDT','00-FF-B6-87-5B-47','60534556E600A',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-18 12:19:37','2021-03-18 12:19:37'),(8,3,3,14,3,1,1,1000.00,NULL,'BDT','8C-EC-4B-BC-CC-AF','6059671EBF770',2,'success',2,NULL,NULL,NULL,NULL,'2021-03-23 03:57:19','2021-03-23 03:57:19'),(9,NULL,3,14,3,1,2,1700.00,NULL,'BDT','8C-EC-4B-BC-CC-AF','60596C34F08D1',2,'success',NULL,'[{\"id\":9},{\"id\":10}]',NULL,NULL,NULL,'2021-03-23 04:19:01','2021-03-23 04:19:01'),(10,3,3,17,4,1,1,1000.00,NULL,'BDT','8C-EC-4B-BC-D0-35','60596F6D3C277',2,'success',2,NULL,NULL,NULL,NULL,'2021-03-23 04:32:45','2021-03-23 04:32:45'),(11,0,3,19,5,4,1,1000.00,NULL,'BDT','00-FF-B6-87-5B-47','60598FC8B1A48',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-23 06:50:51','2021-03-23 06:50:51'),(12,3,3,202,6,1,1,1000.00,NULL,'BDT','00-FF-B6-87-5B-47','6059C16578750',2,'success',2,NULL,NULL,NULL,NULL,'2021-03-23 10:22:32','2021-03-23 10:22:32'),(13,7,3,202,3,2,1,100.00,NULL,'BDT',NULL,'6059C4E496613',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-03-23 10:37:24','2021-03-23 10:37:24'),(14,NULL,3,202,6,1,2,500.00,NULL,'BDT','00-FF-B6-87-5B-47','6059CCCE3F06D',2,'success',NULL,'[{\"id\":12}]',NULL,NULL,NULL,'2021-03-23 11:11:10','2021-03-23 11:11:10'),(15,NULL,3,202,6,1,3,0.00,NULL,'BDT','00-FF-B6-87-5B-47','6059CCD2101CF',2,'success',NULL,NULL,'[]',NULL,NULL,'2021-03-23 11:11:14','2021-03-23 11:11:14'),(16,11,15,12,5,1,1,10000.00,NULL,'BDT','8C-EC-4B-BC-CC-AF','605B0F0EDC6BA',2,'success',1,NULL,NULL,NULL,NULL,'2021-03-24 10:06:07','2021-03-24 10:06:07'),(17,13,15,12,2,3,1,250.00,NULL,'BDT',NULL,'605C1CD508841',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-25 05:17:09','2021-03-25 05:17:09'),(18,13,15,12,3,3,1,250.00,NULL,'BDT',NULL,'605C1D542E88A',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-25 05:19:16','2021-03-25 05:19:16'),(19,0,15,12,13,4,1,5000.00,NULL,'BDT','8C-EC-4B-BC-CD-5F','605C5622E10FD',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-03-25 09:21:32','2021-03-25 09:21:39'),(20,NULL,3,14,3,1,3,0.00,NULL,'BDT','8C-EC-4B-BC-CC-AF','605C5C31D6390',2,'success',NULL,NULL,'[]',NULL,NULL,'2021-03-25 09:47:30','2021-03-25 09:47:30'),(21,NULL,3,202,6,1,3,0.00,NULL,'BDT','00-FF-B6-87-5B-47','605C67D73D4AE',1,'pending',NULL,NULL,'[]',NULL,NULL,'2021-03-25 10:37:12','2021-03-25 10:37:12'),(22,0,3,219,14,4,1,0.00,NULL,'BDT','E4-54-E8-A5-1E-A9','605ECBEA9A1F2',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-27 00:08:43','2021-03-27 00:08:43'),(23,0,3,219,15,4,1,0.00,NULL,'BDT','E4-54-E8-A5-1E-A9','605ECCC40321C',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-27 00:12:20','2021-03-27 00:16:40'),(24,0,3,219,16,4,1,0.00,NULL,'BDT','E4-54-E8-A5-1E-A9','605ECCD2D1679',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-27 00:12:35','2021-03-27 00:12:35'),(25,0,3,219,17,4,1,0.00,NULL,'BDT','E4-54-E8-A5-1E-A9','605ECDF5121A7',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-27 00:17:25','2021-03-27 00:17:25'),(26,0,3,219,18,4,1,0.00,NULL,'BDT','E4-54-E8-A5-1E-A9','605ECE1F56A5F',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-27 00:18:07','2021-03-27 00:18:07'),(27,0,3,219,19,4,1,0.00,NULL,'BDT','E4-54-E8-A5-1E-A9','605ECE6EDD332',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-27 00:19:27','2021-03-27 00:19:27'),(28,0,3,219,20,4,1,0.00,NULL,'BDT','E4-54-E8-A5-1E-A9','605ECEB8998A9',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-27 00:20:40','2021-03-27 00:25:34'),(29,0,3,219,21,4,1,0.00,NULL,'BDT','E4-54-E8-A5-1E-A9','605ECFF49B196',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-27 00:25:56','2021-03-27 00:26:58'),(30,0,15,219,22,4,1,0.00,NULL,'BDT','E4-54-E8-A5-1E-A9','605ED04D857A8',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-27 00:27:25','2021-03-27 00:27:25'),(31,0,3,219,23,4,1,0.00,NULL,'BDT','E4-54-E8-A5-1E-A9','605ED0EF38A29',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-27 00:30:07','2021-03-27 00:30:07'),(32,0,3,219,24,4,1,0.00,NULL,'BDT','E4-54-E8-A5-1E-A9','605ED109639CB',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-27 00:30:33','2021-03-27 00:30:33'),(33,0,3,225,4,3,1,0.00,NULL,'BDT',NULL,'606019346B072',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-27 23:50:44','2021-03-27 23:50:44'),(34,0,3,225,5,3,1,0.00,NULL,'BDT',NULL,'6060193F57CE5',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-27 23:50:55','2021-03-27 23:50:55'),(35,0,3,225,13,4,1,0.00,NULL,'BDT','E4-54-E8-A5-1E-A9','6060196B2ADBB',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-27 23:51:39','2021-03-27 23:51:39'),(36,15,15,202,3,2,3,100.00,NULL,'BDT',NULL,'60604CA4370E8',2,'success',NULL,NULL,NULL,NULL,1,'2021-03-28 09:30:12','2021-03-28 09:30:12'),(37,16,15,202,19,2,2,3000.00,NULL,'BDT',NULL,'60606F74BAC9C',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-03-28 11:58:44','2021-03-28 11:58:45'),(38,16,15,202,20,2,2,3000.00,NULL,'BDT',NULL,'606074B6281C8',1,'success',NULL,NULL,NULL,NULL,NULL,'2021-03-28 12:21:10','2021-03-28 12:21:10'),(39,16,15,202,20,2,2,3000.00,NULL,'BDT',NULL,'606074BE94638',1,'success',NULL,NULL,NULL,NULL,NULL,'2021-03-28 12:21:18','2021-03-28 12:21:18'),(40,16,15,202,20,2,2,3000.00,NULL,'BDT',NULL,'606075B1A02F2',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-03-28 12:25:21','2021-03-28 12:25:21'),(41,17,15,112,21,2,1,20.00,NULL,'BDT',NULL,'60607737A58BD',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-03-28 12:31:51','2021-03-28 12:31:51'),(42,17,15,113,22,2,1,20.00,NULL,'BDT',NULL,'6061570A051B0',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-03-29 04:26:50','2021-03-29 04:26:50'),(43,16,15,113,23,2,2,3000.00,NULL,'BDT',NULL,'6061585D0350C',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-03-29 04:32:29','2021-03-29 04:32:29'),(44,13,15,226,6,3,1,250.00,NULL,'BDT',NULL,'60615943E8738',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-03-28 22:36:19','2021-03-28 22:36:19'),(45,13,15,226,7,3,1,250.00,NULL,'BDT',NULL,'606159E998F23',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-03-28 22:36:25','2021-03-28 22:39:06'),(46,17,15,114,24,2,1,20.00,NULL,'BDT',NULL,'60615A8F114AF',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-03-29 04:41:51','2021-03-29 04:41:51'),(47,15,15,114,24,2,3,100.00,NULL,'BDT',NULL,'6061600ADE33A',2,'success',NULL,NULL,NULL,NULL,1,'2021-03-29 05:05:14','2021-03-29 05:05:15'),(48,16,15,114,25,2,2,3000.00,NULL,'BDT',NULL,'606160639D165',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-03-29 05:06:43','2021-03-29 05:06:43'),(49,7,3,248,26,2,1,100.00,NULL,'BDT',NULL,'607289F61D738',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-04-10 23:32:38','2021-04-10 23:32:38'),(50,0,3,248,14,4,1,1000.00,NULL,'BDT','E4-54-E8-A5-22-6F','6072A3D70C1B5',1,'pending',NULL,NULL,NULL,NULL,NULL,'2021-04-11 01:23:04','2021-04-11 01:23:48'),(51,7,3,248,26,2,1,100.00,NULL,'BDT',NULL,'6072BB77122E8',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-04-11 03:03:51','2021-04-11 03:03:51'),(52,7,3,248,26,2,1,100.00,NULL,'BDT',NULL,'6072BE7B02C77',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-04-11 03:16:43','2021-04-11 03:16:43'),(53,7,3,248,26,2,1,100.00,NULL,'BDT',NULL,'6072BFD446D89',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-04-11 03:22:28','2021-04-11 03:22:28'),(54,7,3,248,26,2,1,100.00,NULL,'BDT',NULL,'6072C0B74C657',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-04-11 03:26:15','2021-04-11 03:26:15'),(55,9,3,248,26,2,3,150.00,NULL,'BDT',NULL,'6072C6FE5C1C9',2,'success',NULL,NULL,NULL,NULL,1,'2021-04-11 03:53:02','2021-04-11 03:53:02'),(56,0,3,248,8,3,1,0.00,NULL,'BDT',NULL,'6073D2E1E8722',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-04-11 22:44:51','2021-04-11 22:56:02'),(57,0,3,248,9,3,1,0.00,NULL,'BDT',NULL,'6073D094E4E6A',2,'success',NULL,NULL,NULL,NULL,NULL,'2021-04-11 22:45:21','2021-04-11 22:46:13'),(58,3,3,248,11,1,1,1000.00,NULL,'BDT','E4-54-E8-A5-22-6F','60755FC162DF5',2,'success',9,NULL,NULL,NULL,NULL,'2021-04-13 03:09:22','2021-04-13 03:09:22');
/*!40000 ALTER TABLE `irrigation_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_circle_areas`
--

DROP TABLE IF EXISTS `master_circle_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_circle_areas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `division_id` bigint(20) unsigned NOT NULL,
  `district_id` bigint(20) unsigned NOT NULL,
  `circle_area_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `circle_area_name_bn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_circle_areas`
--

LOCK TABLES `master_circle_areas` WRITE;
/*!40000 ALTER TABLE `master_circle_areas` DISABLE KEYS */;
INSERT INTO `master_circle_areas` VALUES (1,15,2,15,'Test Circle Area','Test Circle Area Bn',1,1,0,'2021-02-24 03:20:17','2021-04-12 01:05:10'),(2,15,1,1,'Test Circle Area 2','Test Circle Area 2 Bn',1,1,0,'2021-03-02 12:47:51','2021-03-03 06:18:42'),(3,15,6,47,'Another Circle Area','Another Circle Area Bn',1,1,0,'2021-03-03 05:06:19','2021-03-03 05:06:19'),(4,3,1,1,'circle xl','circle xl bn',NULL,74,1,'2021-03-06 09:46:31','2021-04-12 02:48:02'),(5,3,1,1,'Test circle area name ','Test circle area name bn',1,1,0,'2021-03-10 06:23:31','2021-04-12 01:03:39'),(6,3,1,1,'Test circle area name','Test circle area name bn',1,1,0,'2021-03-10 06:23:49','2021-03-10 06:23:49');
/*!40000 ALTER TABLE `master_circle_areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_contractors`
--

DROP TABLE IF EXISTS `master_contractors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_contractors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `contractor_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contractor_name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_no` int(11) DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_contractors`
--

LOCK TABLES `master_contractors` WRITE;
/*!40000 ALTER TABLE `master_contractors` DISABLE KEYS */;
INSERT INTO `master_contractors` VALUES (1,'KM Bhuyiya Ltd.','KM Bhuyiya Ltd. bn',1191829430,'Dhaka','Dhaka',3,1,1,0,'2021-02-24 03:03:59','2021-04-12 02:49:51'),(2,'KM Bhuyiya Ltd.','KM Bhuyiya Ltd. bn',1735555555,'Test Address','পরীক্ষার ঠিকানা',15,1,1,0,'2021-03-02 12:33:17','2021-03-02 12:33:17'),(3,'Test Contractor Name for badc','Test Contractor Name for badc bn',1735555555,'Test Address','Test Address bn',3,1,1,0,'2021-03-04 06:15:31','2021-03-04 06:15:31'),(4,'ghghfg','gfhfghfgd',1765848689,'hgfhfdghfg','dfgsfsgdg',3,NULL,NULL,0,'2021-03-06 09:44:34','2021-04-12 02:50:48'),(5,'ghghfg','gfhfghfgd',1765848689,'hgfhfdghfg','dfgsfsgdg',3,NULL,NULL,0,'2021-03-06 09:51:37','2021-03-06 09:51:37'),(6,'Test Contractor Name for BADC 2','Test Contractor Name for BADC BN',1735555555,'Test Address ','Test Address BN',3,1,1,0,'2021-03-10 06:06:57','2021-03-10 06:06:57'),(7,'Test Contractor Name for BADC 2','Test Contractor Name for BADC 2 BN',1735555555,'Test Address','Test Address BN',2,1,1,0,'2021-03-10 06:07:35','2021-03-10 06:07:35'),(8,'Test Contractor Name for BADC 3','Test Contractor Name for BADC 3 BN',1735555555,'Test Address','Test Address BN',3,1,1,0,'2021-03-10 06:08:21','2021-03-10 06:12:02');
/*!40000 ALTER TABLE `master_contractors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_equipment_types`
--

DROP TABLE IF EXISTS `master_equipment_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_equipment_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `eq_type_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `eq_type_name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_equipment_types`
--

LOCK TABLES `master_equipment_types` WRITE;
/*!40000 ALTER TABLE `master_equipment_types` DISABLE KEYS */;
INSERT INTO `master_equipment_types` VALUES (1,'Irrigation Equipment','Irrigation Equipment',3,1,1,0,'2021-02-24 03:04:29','2021-02-24 03:04:29'),(2,'Irrigation Equipment','Irrigation Equipment bn',15,1,1,0,'2021-03-02 13:03:18','2021-03-02 13:03:18'),(3,'Test Equipment Name','Test Equipment Name bn',3,1,1,0,'2021-03-10 07:53:13','2021-03-10 07:53:13'),(4,'Test Equipment Name 2','Test Equipment Name bn',3,1,1,0,'2021-03-10 07:53:34','2021-03-10 07:53:34'),(5,'Test Equipment Name','Test Equipment Name bn',15,1,1,0,'2021-03-10 07:53:56','2021-03-10 07:53:56');
/*!40000 ALTER TABLE `master_equipment_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_horse_powers`
--

DROP TABLE IF EXISTS `master_horse_powers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_horse_powers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `horse_power` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `horse_power_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pump_type_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `master_horse_powers_pump_type_id_foreign` (`pump_type_id`),
  CONSTRAINT `master_horse_powers_pump_type_id_foreign` FOREIGN KEY (`pump_type_id`) REFERENCES `master_pump_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_horse_powers`
--

LOCK TABLES `master_horse_powers` WRITE;
/*!40000 ALTER TABLE `master_horse_powers` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_horse_powers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_item_categories`
--

DROP TABLE IF EXISTS `master_item_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_item_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `category_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category_name_bn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_item_categories`
--

LOCK TABLES `master_item_categories` WRITE;
/*!40000 ALTER TABLE `master_item_categories` DISABLE KEYS */;
INSERT INTO `master_item_categories` VALUES (1,3,'Pipe','পাইপ ',1,1,0,'2021-02-24 03:06:23','2021-04-12 02:58:58'),(2,3,'category xl ','category xl bn',NULL,1,0,'2021-03-06 12:20:49','2021-03-24 23:06:36'),(3,15,'category xl','category xl Bn',NULL,1,0,'2021-03-06 12:20:49','2021-04-12 02:57:56'),(4,3,'BADC Category','BADC Category',1,1,0,'2021-03-10 07:17:09','2021-03-10 07:17:09'),(5,15,'BMDA Category','BMDA Category',1,1,0,'2021-03-10 07:17:34','2021-03-10 07:17:34'),(6,3,'QA Test Item Category','QA Test Item Category(Bn)',1,1,0,'2021-04-12 02:59:49','2021-04-12 02:59:49');
/*!40000 ALTER TABLE `master_item_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_item_sub_categories`
--

DROP TABLE IF EXISTS `master_item_sub_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_item_sub_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `sub_category_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sub_category_name_bn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `master_item_sub_categories_category_id_foreign` (`category_id`),
  CONSTRAINT `master_item_sub_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `master_item_categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_item_sub_categories`
--

LOCK TABLES `master_item_sub_categories` WRITE;
/*!40000 ALTER TABLE `master_item_sub_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_item_sub_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_items`
--

DROP TABLE IF EXISTS `master_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `sub_category_id` bigint(20) unsigned DEFAULT NULL,
  `measurement_unit_id` bigint(20) unsigned NOT NULL,
  `item_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `item_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `specification` text COLLATE utf8_unicode_ci,
  `specification_bn` text COLLATE utf8_unicode_ci,
  `item_code` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `master_items_category_id_foreign` (`category_id`),
  KEY `master_items_measurement_unit_id_foreign` (`measurement_unit_id`),
  CONSTRAINT `master_items_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `master_item_categories` (`id`),
  CONSTRAINT `master_items_measurement_unit_id_foreign` FOREIGN KEY (`measurement_unit_id`) REFERENCES `master_measurement_units` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_items`
--

LOCK TABLES `master_items` WRITE;
/*!40000 ALTER TABLE `master_items` DISABLE KEYS */;
INSERT INTO `master_items` VALUES (1,3,1,0,1,'Irrigation Pipe','সেচ পাইপ ','Long Pipe','Long Pipe Bn','01',1,1,0,'2021-02-24 03:08:37','2021-04-12 03:01:50'),(2,15,1,0,1,'adfdf','Pipe 2','','','dfdf',1,1,0,'2021-03-06 08:54:47','2021-03-23 03:34:48'),(3,15,2,0,1,'Myra Williams','Gabriel Norman','','','Nostrud facilis corr',1,1,0,'2021-03-09 04:50:23','2021-03-09 04:50:23'),(4,3,5,0,3,'test item name badc ','test item name badc  bn','Test specification','Test specification bn','test item code badc',1,1,0,'2021-03-10 07:35:07','2021-03-10 07:35:07'),(5,15,5,0,3,'test item name badc ','test item name badc  bn','Test specification','Test specification bn','test item code badc',1,1,0,'2021-03-10 07:36:07','2021-03-10 07:36:07'),(6,3,2,0,1,'1','1','1','1','1',74,74,0,'2021-03-24 01:55:53','2021-03-24 01:55:53'),(7,3,1,0,1,'fdfdf','dffd','dfdf','fdfdf','45343',1,1,0,'2021-03-24 11:16:47','2021-03-24 11:16:47'),(8,3,1,0,1,'vvcdfdf','dfdfdf','dfdf','dfdfd','4343',1,1,0,'2021-03-24 11:23:00','2021-03-24 11:23:00'),(9,3,1,0,1,'vvcdfdf','dfdfdf','dfdf','dfdfd','4343',1,1,0,'2021-03-24 11:23:00','2021-03-24 11:23:00'),(10,3,5,0,1,'mmm','mmm','mmm','mmm','mmm',1,1,0,'2021-03-24 11:27:51','2021-03-24 11:27:51'),(11,3,1,0,2,'ttt','tttt','tt','tt','65',1,1,0,'2021-03-25 11:56:19','2021-03-25 11:56:19');
/*!40000 ALTER TABLE `master_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_laboratories`
--

DROP TABLE IF EXISTS `master_laboratories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_laboratories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `laboratory_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `laboratory_name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_laboratories`
--

LOCK TABLES `master_laboratories` WRITE;
/*!40000 ALTER TABLE `master_laboratories` DISABLE KEYS */;
INSERT INTO `master_laboratories` VALUES (1,'BADC Laboratory','BADC Laboratory','Sech Bhaban','সেচ  ভবন ',3,1,1,0,'2021-02-24 03:11:04','2021-02-24 03:11:04'),(2,'BADC Laboratory','BADC Laboratory bn','Test Address','পরীক্ষার ঠিকানা',15,1,1,0,'2021-03-02 12:59:26','2021-03-02 12:59:26'),(18,'Test laboratory Name','Test laboratory Name bn','Test laboratory address','Test laboratory address bn',3,1,1,0,'2021-03-10 07:50:05','2021-03-10 07:50:05'),(19,'Test laboratory Name','Test laboratory Name bn','Test laboratory address','Test laboratory address bn',15,1,1,0,'2021-03-10 07:51:05','2021-03-10 07:51:05'),(20,'1234','1234','1234','1234',15,212,1,1,'2021-03-24 03:52:31','2021-04-12 03:25:44'),(21,'QA Test Laboratory','QA Test Laboratory Bn','QA Test Address','QA Test Address Bn',3,1,1,0,'2021-04-12 03:23:59','2021-04-12 03:26:16');
/*!40000 ALTER TABLE `master_laboratories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_measurement_units`
--

DROP TABLE IF EXISTS `master_measurement_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_measurement_units` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `unit_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `unit_name_bn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_measurement_units`
--

LOCK TABLES `master_measurement_units` WRITE;
/*!40000 ALTER TABLE `master_measurement_units` DISABLE KEYS */;
INSERT INTO `master_measurement_units` VALUES (1,3,'Feet','ফিট ',1,1,0,'2021-02-24 03:07:59','2021-02-24 03:07:59'),(2,3,'Test Unit Name','Test Unit Name bn',1,1,0,'2021-03-10 07:18:22','2021-03-10 07:18:22'),(3,15,'Test Unit Name','Test Unit Name bn',1,1,0,'2021-03-10 07:18:38','2021-03-10 07:18:38');
/*!40000 ALTER TABLE `master_measurement_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_payment_types`
--

DROP TABLE IF EXISTS `master_payment_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_payment_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` tinyint(4) NOT NULL,
  `type_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type_name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` double(8,2) NOT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_payment_types`
--

LOCK TABLES `master_payment_types` WRITE;
/*!40000 ALTER TABLE `master_payment_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_payment_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_payments`
--

DROP TABLE IF EXISTS `master_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `application_type_id` tinyint(4) NOT NULL,
  `payment_type_id` tinyint(4) NOT NULL,
  `scheme_type_id` bigint(20) unsigned DEFAULT NULL,
  `participation_category_id` tinyint(4) DEFAULT NULL,
  `pump_type_id` bigint(20) unsigned DEFAULT NULL,
  `discharge_cusec` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `circle_area_id` bigint(20) unsigned DEFAULT NULL,
  `testing_parameter_id` int(11) DEFAULT NULL,
  `gender` tinyint(4) DEFAULT NULL,
  `amount` double(8,2) NOT NULL,
  `effective_from` date NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_payments`
--

LOCK TABLES `master_payments` WRITE;
/*!40000 ALTER TABLE `master_payments` DISABLE KEYS */;
INSERT INTO `master_payments` VALUES (1,3,4,1,0,0,0,'',0,5,0,1000.00,'2021-03-23',1,1,1,'2021-03-23 03:39:04','2021-04-11 01:14:23'),(2,3,1,1,3,0,0,'',0,0,0,1000.00,'2021-03-23',1,1,0,'2021-03-23 03:55:45','2021-03-23 03:55:45'),(3,3,1,1,9,0,0,'',0,0,0,1000.00,'2021-03-23',1,1,0,'2021-03-23 03:56:17','2021-04-13 03:08:00'),(4,3,1,2,0,1,0,'10',0,0,0,500.00,'2021-03-23',1,1,0,'2021-03-23 04:08:00','2021-03-23 04:08:00'),(5,3,1,2,0,2,0,'10',0,0,0,1200.00,'2021-03-23',1,1,0,'2021-03-23 04:08:14','2021-03-23 04:08:14'),(6,3,4,3,0,0,0,'',0,7,0,1000.00,'2021-03-23',1,1,0,'2021-03-23 07:25:21','2021-03-23 07:25:21'),(7,3,2,1,0,0,0,'',0,0,0,100.00,'2021-03-01',1,1,0,'2021-03-23 10:36:10','2021-03-23 10:36:10'),(8,3,2,2,0,0,0,'',0,0,0,300.00,'2021-03-01',1,1,0,'2021-03-23 10:36:20','2021-03-23 10:36:20'),(9,3,2,3,0,0,0,'',0,0,1,150.00,'2021-03-01',1,1,0,'2021-03-23 10:36:47','2021-03-23 11:02:05'),(10,15,1,1,7,0,0,'',0,0,0,400.00,'2021-03-24',212,212,0,'2021-03-24 04:03:10','2021-03-24 04:03:10'),(11,15,1,1,1,0,0,'',0,0,0,10000.00,'2021-03-24',1,1,0,'2021-03-24 10:05:59','2021-03-24 10:05:59'),(12,15,1,2,0,0,0,'',1,0,0,500.00,'2021-03-24',1,1,0,'2021-03-24 10:09:13','2021-03-24 10:09:13'),(13,15,3,1,0,0,0,'',0,0,0,250.00,'2021-03-23',1,1,0,'2021-03-24 12:16:26','2021-03-24 12:16:26'),(14,15,4,1,0,0,0,'',0,17,0,5000.00,'2021-03-25',1,1,0,'2021-03-25 09:15:53','2021-03-25 09:15:53'),(15,15,2,3,0,0,0,'',0,0,1,100.00,'2021-03-01',1,1,0,'2021-03-28 09:23:02','2021-03-28 09:23:02'),(16,15,2,2,0,0,0,'',0,0,0,3000.00,'2021-03-01',1,1,0,'2021-03-28 11:56:12','2021-03-28 11:56:12'),(17,15,2,1,0,0,0,'',0,0,0,20.00,'2021-03-01',1,1,0,'2021-03-28 12:31:15','2021-03-28 12:31:15'),(18,3,4,1,0,0,0,'',0,5,0,300.00,'2021-04-09',1,1,0,'2021-04-11 01:11:36','2021-04-11 01:13:27');
/*!40000 ALTER TABLE `master_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_projects`
--

DROP TABLE IF EXISTS `master_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_projects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `project_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `project_name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_projects`
--

LOCK TABLES `master_projects` WRITE;
/*!40000 ALTER TABLE `master_projects` DISABLE KEYS */;
INSERT INTO `master_projects` VALUES (1,'Irrigation Project','Irrigation Project',3,1,1,0,'2021-02-24 03:02:53','2021-03-24 02:16:39'),(2,'Test Project Name badc','Test Project Name badc bn',3,1,1,0,'2021-03-02 10:02:11','2021-03-02 10:02:11'),(3,'Irrigation Project','Irrigation Project',15,1,1,0,'2021-03-02 12:30:55','2021-03-02 12:30:55'),(4,'DAE project','ডিএই প্রোজেকট',2,1,1,0,'2021-03-04 04:34:36','2021-03-04 04:34:36'),(5,'fgsdfg','fgfdgfd bn',4,NULL,NULL,0,'2021-03-06 08:49:14','2021-03-06 08:49:14'),(6,'Koika','কৈকা',15,1,1,0,'2021-03-10 05:32:39','2021-03-10 05:32:39'),(7,'APP Development','এ্যাপ উন্নয়ন',15,1,1,0,'2021-03-10 05:33:02','2021-03-10 05:33:02'),(8,'Road Map','রোড ম্যাপ',15,1,1,0,'2021-03-10 05:33:21','2021-03-10 05:33:21'),(9,'Digging','খনন',15,1,1,0,'2021-03-10 05:34:38','2021-03-10 05:34:38'),(10,'Digitalization','আধুনিকায়ন',15,1,1,0,'2021-03-10 05:35:37','2021-03-10 05:35:37'),(11,'Handicrafts','হস্তশিল্প',15,1,1,0,'2021-03-10 05:36:13','2021-03-10 05:36:13'),(12,'1','1',3,74,74,0,'2021-03-24 02:17:03','2021-03-24 02:17:03'),(13,'loop','loop bn',15,212,212,0,'2021-03-24 03:12:03','2021-03-24 03:12:03'),(14,'QA Test Project','QA Test Project Bn',3,1,1,0,'2021-04-11 23:37:32','2021-04-11 23:38:02');
/*!40000 ALTER TABLE `master_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_pump_progress_types`
--

DROP TABLE IF EXISTS `master_pump_progress_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_pump_progress_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `pump_type_id` bigint(20) unsigned NOT NULL,
  `application_type_id` int(11) NOT NULL DEFAULT '1' COMMENT '1=New,2=Resunk',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `master_pump_progress_types_pump_type_id_foreign` (`pump_type_id`),
  CONSTRAINT `master_pump_progress_types_pump_type_id_foreign` FOREIGN KEY (`pump_type_id`) REFERENCES `master_pump_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_pump_progress_types`
--

LOCK TABLES `master_pump_progress_types` WRITE;
/*!40000 ALTER TABLE `master_pump_progress_types` DISABLE KEYS */;
INSERT INTO `master_pump_progress_types` VALUES (3,15,2,1,1,1,0,'2021-03-06 07:16:15','2021-04-12 03:19:27'),(4,3,1,1,1,1,0,'2021-03-08 11:17:37','2021-03-08 11:17:37'),(5,3,3,1,1,1,0,'2021-03-10 07:40:48','2021-03-10 07:40:48'),(6,15,4,1,1,1,0,'2021-03-10 07:41:31','2021-03-10 07:41:31'),(7,15,4,1,1,1,0,'2021-03-10 07:42:47','2021-03-10 07:42:47'),(8,3,3,1,1,1,0,'2021-03-10 07:49:04','2021-03-10 07:49:04'),(9,3,1,2,1,1,0,'2021-03-24 10:53:20','2021-03-24 10:53:20'),(10,3,3,2,1,1,0,'2021-03-24 10:53:39','2021-03-24 10:53:39'),(11,15,2,2,1,1,0,'2021-03-28 07:19:09','2021-03-28 07:19:09'),(12,3,5,1,1,1,0,'2021-04-12 03:10:14','2021-04-12 03:10:14');
/*!40000 ALTER TABLE `master_pump_progress_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_pump_types`
--

DROP TABLE IF EXISTS `master_pump_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_pump_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `pump_type_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pump_type_name_bn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_pump_types`
--

LOCK TABLES `master_pump_types` WRITE;
/*!40000 ALTER TABLE `master_pump_types` DISABLE KEYS */;
INSERT INTO `master_pump_types` VALUES (1,3,'Solar Pump','সৌর চালিত পাম্প ',1,1,0,'2021-02-24 03:09:33','2021-03-02 12:55:24'),(2,15,'Electric Pump','বিদ্যুৎ চালিত পাম্প',1,1,0,'2021-03-06 07:15:02','2021-03-06 07:15:12'),(3,3,'Test Pump Type','টেস্ট পাম্প প্রকার',1,1,0,'2021-03-10 07:36:36','2021-03-10 07:36:36'),(4,15,'Test Pump Type','টেস্ট পাম্প প্রকার',1,1,0,'2021-03-10 07:36:51','2021-03-10 07:36:51'),(5,3,'QA Test Pump Type','QA Test Pump Type Bn',1,1,0,'2021-04-12 03:07:01','2021-04-12 03:07:01');
/*!40000 ALTER TABLE `master_pump_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_report_headers`
--

DROP TABLE IF EXISTS `master_report_headers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_report_headers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `heading` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `heading_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `left_logo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `right_logo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_report_headers`
--

LOCK TABLES `master_report_headers` WRITE;
/*!40000 ALTER TABLE `master_report_headers` DISABLE KEYS */;
INSERT INTO `master_report_headers` VALUES (2,'Test Scheme type Heading',' পরীক্ষা প্রকল্পের শিরোনাম','1614885008.png','1614885008.png','Khamarbari Rd, Dhaka 1215','খামারবাড়ি আরডি -1215',2,1,1,0,'2021-03-04 11:24:41','2021-03-04 13:10:08'),(3,'Bangladesh agricultural development corporation heading','বাংলাদেশ কৃষি উন্নয়ন কর্পোরেশন শিরোনাম','1617177290.png','1617177290.jpg','22 Manik Mia Ave, Dhaka 1215','22 মানিক মিয়া আভে, Dhaka 1215',3,1,1,0,'2021-03-04 11:51:07','2021-03-31 07:54:50'),(4,'Voluptas nemo mollit','Harum fugit natus i','1617177370.png','1617177370.jpg','','',2,1,1,1,'2021-03-09 04:53:35','2021-03-31 07:56:10'),(5,'Heading One','Heading One Bn','1615353370.jpg','1615353370.jpg','BMDA','BMDA',15,1,1,0,'2021-03-10 05:16:10','2021-03-10 05:16:10'),(6,'Test Heading','Test Heading bn','1617177446.png','1617177446.svg','Test Address','Test Address bn',3,1,1,0,'2021-03-10 07:52:24','2021-03-31 07:57:26'),(7,'yahoo','yahoo','1617177471.png','1617177471.svg','yahoo','yahoo',3,1,1,0,'2021-03-24 23:00:09','2021-03-31 07:57:51');
/*!40000 ALTER TABLE `master_report_headers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_scheme_affidavits`
--

DROP TABLE IF EXISTS `master_scheme_affidavits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_scheme_affidavits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title_bn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `affidavit` text COLLATE utf8_unicode_ci NOT NULL,
  `affidavit_bn` text COLLATE utf8_unicode_ci NOT NULL,
  `scheme_type_id` bigint(20) unsigned NOT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `master_scheme_affidavits_scheme_type_id_foreign` (`scheme_type_id`),
  CONSTRAINT `master_scheme_affidavits_scheme_type_id_foreign` FOREIGN KEY (`scheme_type_id`) REFERENCES `master_scheme_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_scheme_affidavits`
--

LOCK TABLES `master_scheme_affidavits` WRITE;
/*!40000 ALTER TABLE `master_scheme_affidavits` DISABLE KEYS */;
INSERT INTO `master_scheme_affidavits` VALUES (1,'','','<p><strong style=\"color: rgb(0, 0, 0);\">Lorem Ipsum</strong><span style=\"color: rgb(0, 0, 0);\">&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</span></p>','<p><span style=\"color: rgb(85, 85, 85);\">আমার বাংলা নিয়ে প্রথম কাজ করবার সুযোগ তৈরি হয়েছি</span><a href=\"http://www.omicronlab.com/avro-keyboard.html\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"color: rgb(54, 153, 220); background-color: rgb(255, 255, 255);\">অভ্র^</a><span style=\"color: rgb(85, 85, 85);\">&nbsp;নামক এক যুগান্তকারী বাংলা সফ্‌টওয়্যার হাতে পাবার মধ্য দিয়ে। এর পর একে একে বাংলা উইকিপিডিয়া, ওয়ার্ডপ্রেস বাংলা কোডেক্সসহ বিভিন্ন বাংলা অনলাইন পত্রিকা তৈরির কাজ করতে করতে বাংলার সাথে নিজেকে বেঁধে নিয়েছি আষ্টেপৃষ্ঠে। বিশেষ করে অনলাইন পত্রিকা তৈরি করতে ডিযাইন করার সময়, সেই ডিযাইনকে কোডে রূপান্তর করবার সময় বারবার অনুভব করেছি কিছু নমুনা লেখার।ল&nbsp;</span></p>',8,15,1,1,1,'2021-03-02 12:26:47','2021-04-12 02:52:12'),(2,'','','<p><strong style=\"color: rgb(0, 0, 0);\">Lorem Ipsum</strong><span style=\"color: rgb(0, 0, 0);\">&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five</span></p>','<p><span style=\"color: rgb(85, 85, 85);\">আমার বাংলা নিয়ে প্রথম কাজ করবার সুযোগ তৈরি হয়েছি</span><a href=\"http://www.omicronlab.com/avro-keyboard.html\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"color: rgb(54, 153, 220); background-color: rgb(255, 255, 255);\">অভ্র^</a><span style=\"color: rgb(85, 85, 85);\">&nbsp;নামক এক যুগান্তকারী বাংলা সফ্‌টওয়্যার হাতে পাবার মধ্য দিয়ে। এর পর একে একে বাংলা উইকিপিডিয়া, ওয়ার্ডপ্রেস বাংলা কোডেক্সসহ বিভিন্ন বাংলা অনলাইন পত্রিকা তৈরির কাজ করতে করতে বাংলার সাথে নিজেকে বেঁধে নিয়েছি আষ্টেপৃষ্ঠে। বিশেষ করে অনলাইন পত্রিকা তৈরি করতে ডিযাইন করার সময়, সেই ডিযাইনকে কোডে রূপান্তর করবার সময় বারবার অনুভব করেছি কিছু নমুনা লেখার।ল&nbsp;</span></p>',4,15,1,1,0,'2021-03-02 12:27:42','2021-04-12 01:13:45'),(3,'Test Scheme Type',' পরীক্ষার শিরোনাম','<p>test affidavit</p>','<p>test affidavit bn</p>',6,15,1,1,1,'2021-03-02 12:43:49','2021-04-12 01:14:03'),(11,'','','<p>test test test test test test test test test test test test test test test test test test test test test test test test test </p>','<p>test bn test bn test bn test bn test bn test bn test bn test bn test bn test bn test bn test bn test bn test bn test bn test bn test bn </p>',2,3,1,1,0,'2021-03-07 03:22:51','2021-04-12 01:15:20'),(12,'','','<p>12</p>','<p>22</p>',7,15,1,1,0,'2021-03-07 03:28:26','2021-04-12 01:16:49'),(13,'','','<p>test affidavit</p>','<p>test affidavit bn</p>',1,15,1,1,0,'2021-03-10 07:24:45','2021-03-10 07:24:45'),(14,'','','<p>QA Test Affidavit QA Test Affidavit QA Test Affidavit QA Test Affidavit QA Test Affidavit QA Test Affidavit QA Test Affidavit QA Test Affidavit QA Test Affidavit QA Test Affidavit QA Test Affidavit QA Test Affidavit QA Test Affidavit </p>','<p>QA Test Affidavit Bn QA Test Affidavit Bn QA Test Affidavit Bn QA Test Affidavit Bn QA Test Affidavit Bn QA Test Affidavit Bn QA Test Affidavit Bn QA Test Affidavit Bn QA Test Affidavit Bn QA Test Affidavit Bn QA Test Affidavit Bn QA Test Affidavit Bn QA Test Affidavit Bn </p>',9,3,1,1,0,'2021-04-12 01:08:34','2021-04-12 01:08:34');
/*!40000 ALTER TABLE `master_scheme_affidavits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_scheme_types`
--

DROP TABLE IF EXISTS `master_scheme_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_scheme_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scheme_type_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `scheme_type_name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_scheme_types`
--

LOCK TABLES `master_scheme_types` WRITE;
/*!40000 ALTER TABLE `master_scheme_types` DISABLE KEYS */;
INSERT INTO `master_scheme_types` VALUES (1,'LLP','এল এল পি ',15,1,212,0,'2021-02-24 03:05:43','2021-03-24 03:09:35'),(2,'Test Scheme Type','Test Scheme Type bn',3,1,1,0,'2021-03-02 05:08:04','2021-03-10 06:12:41'),(3,'test scheme xl','test scheme xl bn',3,NULL,NULL,0,'2021-03-06 09:46:02','2021-03-06 09:46:02'),(4,'yahoo','yahoo',15,212,212,0,'2021-03-24 03:06:34','2021-03-24 03:06:34'),(5,'take','take',15,212,212,0,'2021-03-24 03:07:25','2021-03-24 03:07:25'),(6,'tuna mas1','tuna mas1',15,212,212,0,'2021-03-24 03:08:39','2021-03-24 03:08:46'),(7,'sunny test','sunny test bn',15,212,212,0,'2021-03-24 03:34:25','2021-03-24 03:34:25'),(8,'Scheme Type (En) ','Scheme Type (Bn) ',15,212,212,0,'2021-03-24 23:23:37','2021-03-24 23:23:37'),(9,'QA Test Scheme Type','QA Test Scheme Type(Bn)',3,1,1,0,'2021-04-10 22:59:31','2021-04-10 22:59:31');
/*!40000 ALTER TABLE `master_scheme_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2020_12_21_133006_create_master_projects_table',1),(2,'2020_12_21_140501_create_master_contractors_table',1),(3,'2020_12_21_140859_create_master_scheme_types_table',1),(4,'2020_12_21_141203_create_master_scheme_affidavits_table',1),(5,'2020_12_21_142016_create_master_equipment_types_table',1),(6,'2020_12_21_152425_create_master_laboratories_table',1),(7,'2020_12_21_152724_create_master_payment_types_table',1),(8,'2020_12_21_153812_create_master_report_headers_table',1),(9,'2020_12_27_070424_create_user_logs_table',1),(10,'2020_12_29_151403_create_far_scheme_application_table',1),(11,'2020_12_29_155206_create_far_scheme_app_details_table',1),(12,'2020_12_31_114719_create_far_scheme_projects_table',1),(13,'2020_12_31_115042_create_far_scheme_reviews_table',1),(14,'2020_12_31_115448_create_far_scheme_rejects_table',1),(15,'2020_12_31_115711_create_far_scheme_surveys_table',1),(16,'2020_12_31_120709_create_far_scheme_notes_table',1),(17,'2020_12_31_121413_create_master_pump_types_table',1),(18,'2020_12_31_121846_create_master_pump_progress_types_table',1),(19,'2021_01_03_105424_create_master_item_categories_table',1),(20,'2021_01_03_105926_create_master_item_sub_categories_table',1),(21,'2021_01_03_111107_create_master_measurement_units_table',1),(22,'2021_01_03_111313_create_master_items_table',1),(23,'2021_01_05_130831_create_master_horse_powers_table',1),(24,'2021_01_05_155136_create_pump_stock_in_infos_table',1),(25,'2021_01_05_160006_create_pump_stock_in_details_table',1),(26,'2021_01_05_161548_create_pump_current_stocks_table',1),(27,'2021_01_05_162317_create_pump_stock_out_infos_table',1),(28,'2021_01_05_164025_create_pump_stock_out_details_table',1),(29,'2021_01_06_103309_create_far_scheme_license_table',1),(30,'2021_01_06_104305_create_far_scheme_agreement_table',1),(31,'2021_01_06_105121_create_far_scheme_agreemt_doc_table',1),(32,'2021_01_06_105324_create_far_scheme_requisitions_table',1),(33,'2021_01_06_105851_create_far_scheme_req_details_table',1),(34,'2021_01_06_110405_create_far_scheme_supply_equipments_table',1),(35,'2021_01_06_122502_create_task_assign_tasks_table',1),(36,'2021_01_06_123838_create_task_task_reports_table',1),(37,'2021_01_06_125024_create_task_review_notes_table',1),(38,'2021_01_11_110920_create_far_pump_opt_apps_table',1),(39,'2021_01_11_112316_create_far_pump_opt_docs_table',1),(40,'2021_01_11_113051_create_far_pump_opt_rejects_table',1),(41,'2021_01_11_113354_create_far_pump_opt_app_reniews_table',1),(42,'2021_01_11_113718_create_far_pump_opt_reniews_reject_table',1),(43,'2021_01_11_145842_create_far_pump_install_table',1),(44,'2021_01_11_152247_create_pump_informations_table',1),(45,'2021_01_11_154018_create_pump_operators_table',1),(46,'2021_01_11_155511_create_pump_schedulers_table',1),(47,'2021_01_14_102546_create_master_circle_areas_table',1),(48,'2021_01_14_103826_create_master_payments_table',1),(49,'2021_01_14_115623_create_far_water_test_apps_table',1),(50,'2021_01_17_104645_create_far_water_samples_table',1),(51,'2021_01_17_105121_create_far_water_rejects_table',1),(52,'2021_01_17_105318_create_far_water_test_reports_table',1),(53,'2021_01_18_113209_create_far_smart_card_apps_table',1),(54,'2021_01_19_131935_add_field_to_far_pump_opt_apps_table',1),(55,'2021_01_19_132147_add_field_to_far_water_test_apps_table',1),(56,'2021_01_20_110351_create_far_smart_card_review_table',1),(57,'2021_01_20_110629_create_far_smart_card_rejects_table',1),(58,'2021_01_25_044930_create_pump_directories_table',1),(59,'2021_01_25_051933_create_pump_directory_equipments_table',1),(60,'2021_01_25_105121_create_far_basic_infos_table',1),(61,'2021_01_26_103938_create_far_complains_table',1),(62,'2021_01_26_110835_create_pump_progress_type_steps_table',1),(63,'2021_01_26_121157_create_far_complain_reviews_table',1),(64,'2021_01_26_121540_create_far_complain_resolves_table',1),(65,'2021_01_31_140735_create_far_requisition_approvals_table',1),(66,'2021_01_31_142007_create_far_complain_tro_equipments_table',1),(67,'2021_01_31_142625_create_far_complain_tro_equipment_details_table',1),(68,'2021_01_31_142956_create_far_complain_progress_reports_table',1),(69,'2021_02_01_161944_create_pump_opt_suspensions_table',1),(70,'2021_02_08_150019_create_far_complain_requisitions_table',1),(71,'2021_02_08_150044_create_far_complain_req_details_table',1),(72,'2021_02_08_150112_create_far_complain_approvals_table',1),(73,'2021_02_08_150128_create_far_complain_supply_equipments_table',1),(74,'2021_02_09_145019_create_far_resunks_table',1),(75,'2021_02_09_152319_add_field_to_pump_operators_table',1),(76,'2021_02_09_164105_create_irrigation_payments_table',1),(77,'2021_02_11_111943_add_field_to_pump_current_stocks_table',1),(78,'2021_02_11_134535_add_approval_date_to_far_smart_card_apps_table',1),(79,'2021_02_15_125333_create_scheme_farmers_land_details_table',1),(80,'2021_02_15_142745_create_scheme_participation_fees_table',1),(81,'2021_02_15_143016_create_scheme_security_money_table',1),(82,'2021_02_16_130937_create_irri_scheme_payments',1),(83,'2021_02_18_094627_add_circle_id_scheme_participation_fees_table',1),(84,'2021_02_22_072531_closed_comment_status_add_far_scheme_application_table',1),(85,'2021_02_22_164338_crate_table_far_app_payment_refunds_deducts_table',1),(86,'2021_02_24_111439_add_total_farmer_added_farmer_to_far_scheme_application__table',2),(87,'2021_02_25_115649_create_far_ratings_table',3),(88,'2021_03_03_105208_create_my_assign_tasks_table',4),(89,'2021_03_03_172028_create_pum_opt_apps_approvals_table',5),(90,'2021_03_03_155640_create_farmer_land_details_table',6),(91,'2021_03_04_115441_create_deep_tubewell_yearly_final_report_table',7),(92,'2021_03_09_125255_create_pump_opt_apps_surveys',8),(93,'2021_03_09_155252_create_pump_drilling_log_table',9),(94,'2021_03_09_155512_create_pump_construction_details_table',10),(108,'2021_03_11_171153_create_sub_scheme_types_table',11),(109,'2021_03_14_135055_create_notifications_table',12),(110,'2021_03_15_133513_create_water_testing_parameters_table',12);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_assign_tasks`
--

DROP TABLE IF EXISTS `my_assign_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_assign_tasks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(10) unsigned DEFAULT NULL,
  `farmer_user_id` bigint(20) unsigned NOT NULL,
  `meter_reading_before` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meter_reading_after` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pump_running_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `irrigation_area` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `working_date` date DEFAULT NULL,
  `task_date` date DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) DEFAULT '0' COMMENT '0=active, 1=inactive',
  `task_status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1=pending,2=submitted',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_assign_tasks`
--

LOCK TABLES `my_assign_tasks` WRITE;
/*!40000 ALTER TABLE `my_assign_tasks` DISABLE KEYS */;
INSERT INTO `my_assign_tasks` VALUES (8,3,12,'55','91','96','18','2021-03-17','2021-03-16',12,12,0,2,'2021-03-16 11:38:26','2021-03-16 11:57:38'),(12,1,12,'12','78','38','3','2021-03-18','2021-03-18',12,12,0,2,'2021-03-01 05:14:15','2021-03-18 05:14:23'),(13,3,14,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,'2021-03-18 09:58:39','2021-03-18 09:58:39'),(14,2,19,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,'2021-03-22 10:23:34','2021-03-22 10:23:34'),(15,3,14,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,'2021-03-25 11:44:01','2021-03-25 11:44:01');
/*!40000 ALTER TABLE `my_assign_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `notification_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notification_id` bigint(20) unsigned NOT NULL,
  `body` text COLLATE utf8_unicode_ci,
  `posted_by` bigint(20) unsigned NOT NULL,
  `posted_for` bigint(20) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `seen` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=unseen,1=seen',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notification_type_notification_id_index` (`notification_type`,`notification_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,'App\\Models\\TaskManagement\\TaskAssignTasks',9,'{\"description\":\"Task has not been reported yet.\",\"task_name\":\"Test task name\",\"task_name_bn\":\"Test task name bn\",\"assign_username\":\"admin\",\"id\":9}',1,1,1,0,NULL,NULL),(2,'App\\Models\\TaskManagement\\TaskAssignTasks',10,'{\"description\":\"Task has not been reported yet.\",\"task_name\":\"testinggg\",\"task_name_bn\":\"Bangla testinggg\",\"assign_username\":\"01843867772\",\"id\":10}',1,1,1,0,NULL,NULL);
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pum_opt_apps_approvals`
--

DROP TABLE IF EXISTS `pum_opt_apps_approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pum_opt_apps_approvals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pump_opt_apps_id` bigint(20) unsigned NOT NULL,
  `sender_id` bigint(20) unsigned NOT NULL,
  `receiver_id` bigint(20) unsigned NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `for` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Check, 2=Survey',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1=Pending, 2=Approved',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pum_opt_apps_approvals_pump_opt_apps_id_foreign` (`pump_opt_apps_id`),
  CONSTRAINT `pum_opt_apps_approvals_pump_opt_apps_id_foreign` FOREIGN KEY (`pump_opt_apps_id`) REFERENCES `far_pump_opt_apps` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pum_opt_apps_approvals`
--

LOCK TABLES `pum_opt_apps_approvals` WRITE;
/*!40000 ALTER TABLE `pum_opt_apps_approvals` DISABLE KEYS */;
INSERT INTO `pum_opt_apps_approvals` VALUES (6,1,1,74,'asdf','asdf',1,2,'2021-03-21 11:00:29','2021-03-22 05:21:12'),(7,1,74,1,'sdfs','sdf ',1,2,'2021-03-22 05:21:12','2021-03-23 06:38:36'),(8,1,74,1,'send survey','send survey',2,2,'2021-03-22 07:25:05','2021-03-22 07:27:16'),(9,2,1,74,'send to suman admin','send to suman admin',1,2,'2021-03-23 08:12:41','2021-03-23 08:39:02'),(10,2,1,74,'asdf','asdf',2,2,'2021-03-23 08:13:49','2021-03-23 08:43:33'),(11,1,74,1,'send to admin from sumanadmin','send to admin from sumanadmin',1,2,'2021-03-23 08:39:02','2021-03-24 10:54:33'),(12,3,1,74,'test Mamun','test Mamun bn ',2,2,'2021-03-23 10:38:40','2021-03-23 10:44:12'),(13,3,1,74,'sdd','sdf',1,2,'2021-03-25 08:42:17','2021-03-27 06:47:22'),(19,3,74,1,'wqerwe','afsdf',1,2,'2021-03-27 06:47:22','2021-03-28 08:55:17'),(20,3,1,74,'sdfs','sdfsdf',2,2,'2021-03-27 06:51:18','2021-03-27 07:03:36'),(21,21,1,1,'fdfd','fdfdf',2,2,'2021-03-28 12:34:25','2021-03-29 04:30:40'),(22,22,1,1,'sdf','sdf',2,2,'2021-03-29 04:30:27','2021-03-29 04:31:17'),(23,24,1,1,'ok','ok bn',2,2,'2021-03-29 04:43:07','2021-03-29 04:43:42'),(24,26,1,54,'Sent to Sunny for review','Sent to Sunny for review(Bn)',2,2,'2021-04-11 00:33:19','2021-04-11 03:30:28'),(25,26,1,54,'Sent for survey','Sent for survey(Bn)',2,1,'2021-04-11 03:05:39','2021-04-11 03:05:39'),(26,26,1,61,'qwe','qwe',2,1,'2021-04-11 03:17:04','2021-04-11 03:17:04'),(27,26,1,61,'dfd','dfd',2,1,'2021-04-11 03:22:55','2021-04-11 03:22:55'),(28,26,1,1,'fgfdg','fgfgfdg',2,2,'2021-04-11 03:26:37','2021-04-11 03:28:48');
/*!40000 ALTER TABLE `pum_opt_apps_approvals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pump_construction_details`
--

DROP TABLE IF EXISTS `pump_construction_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pump_construction_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) unsigned NOT NULL,
  `division_id` bigint(20) unsigned NOT NULL,
  `district_id` bigint(20) unsigned NOT NULL,
  `upazilla_id` bigint(20) unsigned NOT NULL,
  `union_id` bigint(20) unsigned DEFAULT NULL,
  `pump_id` bigint(20) unsigned NOT NULL,
  `mouza_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mouza_no_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jl_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jl_no_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plot_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plot_no_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `org_id` bigint(20) unsigned DEFAULT NULL,
  `well_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `well_no_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `engineer_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `engineer_name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `drilling_contractor_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `drilling_contractor_name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `drilling_start_date` date DEFAULT NULL,
  `drilling_start_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `drilling_complete_date` date DEFAULT NULL,
  `drilling_complete_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `casing_start_date` date DEFAULT NULL,
  `casing_start_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `casing_complete_date` date DEFAULT NULL,
  `casing_complete_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravel_placing_start_date` date DEFAULT NULL,
  `gravel_placing_start_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravel_placing_complete_date` date DEFAULT NULL,
  `gravel_placing_complete_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `drilling_diameter` double DEFAULT NULL COMMENT '14=14 inch, 22=22 inch, 24=24 inch,44=44 inch',
  `housing_pipe` double DEFAULT NULL COMMENT '8=8 inch, 12=12 inch, 14=14 inch',
  `uwc_above_gl` double DEFAULT NULL COMMENT 'value in ft',
  `uwc_below_gl` double DEFAULT NULL COMMENT 'value in ft',
  `uwc_total_gl` double DEFAULT NULL COMMENT 'value in ft',
  `lwc_dia` double DEFAULT NULL COMMENT 'value in inch',
  `lwc_from_gl` double DEFAULT NULL COMMENT 'value in ft',
  `lwc_to_gl` double DEFAULT NULL COMMENT 'value in ft',
  `lwc_total_gl` double DEFAULT NULL COMMENT 'value in ft',
  `screen_dia` double DEFAULT NULL COMMENT 'value in inch',
  `screen_from_gl` double DEFAULT NULL COMMENT 'value in ft',
  `screen_to_gl` double DEFAULT NULL COMMENT 'value in ft',
  `screen_total_gl` double DEFAULT NULL COMMENT 'value in ft',
  `bail_plug_dia` double DEFAULT NULL COMMENT 'value in inch',
  `bail_plug_from_gl` double DEFAULT NULL COMMENT 'value in ft',
  `bail_plug_to_gl` double DEFAULT NULL COMMENT 'value in ft',
  `bail_plug_total_gl` double DEFAULT NULL COMMENT 'value in ft',
  `centralize_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `centralize_total` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravel_quantity` double DEFAULT NULL COMMENT 'value in ft',
  `gravel_depth_form` double DEFAULT NULL COMMENT 'value in ft',
  `gravel_depth_to` double DEFAULT NULL COMMENT 'value in ft',
  `fixture_length` double DEFAULT NULL COMMENT 'value in ft',
  `max_deviation` double DEFAULT NULL COMMENT 'value in Inch',
  `max_depth` double DEFAULT NULL COMMENT 'value in Inch',
  `date` date NOT NULL,
  `cross_section_of_well` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ordered_depth` double DEFAULT NULL COMMENT 'value in ft',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pump_construction_details`
--

LOCK TABLES `pump_construction_details` WRITE;
/*!40000 ALTER TABLE `pump_construction_details` DISABLE KEYS */;
INSERT INTO `pump_construction_details` VALUES (1,7,2,16,143,1292,24,'3',NULL,'10',NULL,'5',NULL,15,'Reiciendis vitae dol',NULL,'Elijah Mason','MacKenzie Trujillo','Shaine Scott','Roth Nolan','0000-00-00','01:47','0000-00-00','00:24','0000-00-00','04:24','0000-00-00','09:23','0000-00-00','16:12','0000-00-00','11:55',24,0,36,20,6,0,13,34,85,0,2,77,64,0,43,59,0,'Dolor rerum tempore','977',0,65,43,57,12,86,'2021-03-01','Rerum deleniti qui c',45,0,1,NULL,'2021-03-11 08:38:56','2021-03-15 06:22:40'),(2,3,2,16,143,1294,25,'10',NULL,'12',NULL,'60',NULL,15,'Sit quae quibusdam q',NULL,'Maia Dickerson','Gabriel Mcmillan','Emerald Santos','Colton Campos','0000-00-00','21:39','0000-00-00','06:59','0000-00-00','04:15','0000-00-00','12:22','0000-00-00','18:47','0000-00-00','00:54',22,0,17,2,6,0,60,35,38,0,30,9,62,0,19,89,0,'Exercitation quasi e','654',0,84,39,15,54,74,'2021-03-03','Ipsum dolor aut est',21,1,1,NULL,'2021-03-11 08:40:20','2021-03-15 06:16:51'),(3,10,1,1,1,1,13,'123',NULL,'12',NULL,'4',NULL,15,'Et molestiae eum con',NULL,'Dieter Fitzgerald','Lesley Clark','Natalie Holland','Lacey Bennett','0000-00-00','11:16','0000-00-00','05:28','0000-00-00','22:36','0000-00-00','19:39','0000-00-00','07:57','0000-00-00','05:01',14,0,68,73,71,0,90,17,28,0,19,35,22,0,86,24,0,'Eum sapiente eum fug','145',0,41,8,35,7,44,'2021-03-04','Et cum corrupti et ',55,1,1,1,'2021-03-11 02:41:52','2021-03-15 06:22:44');
/*!40000 ALTER TABLE `pump_construction_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pump_current_stocks`
--

DROP TABLE IF EXISTS `pump_current_stocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pump_current_stocks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `office_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `quantity` double(8,2) NOT NULL DEFAULT '0.00',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `division_id` bigint(20) unsigned NOT NULL,
  `district_id` bigint(20) unsigned NOT NULL,
  `upazilla_id` bigint(20) unsigned NOT NULL,
  `union_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pump_current_stocks_item_id_foreign` (`item_id`),
  CONSTRAINT `pump_current_stocks_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `master_items` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pump_current_stocks`
--

LOCK TABLES `pump_current_stocks` WRITE;
/*!40000 ALTER TABLE `pump_current_stocks` DISABLE KEYS */;
INSERT INTO `pump_current_stocks` VALUES (3,3,1,1,252.00,1,1,'2021-03-23 11:19:57','2021-04-11 22:13:16',1,1,1,1),(4,3,1,6,2.00,1,1,'2021-04-11 22:14:29','2021-04-11 22:14:29',1,1,1,1);
/*!40000 ALTER TABLE `pump_current_stocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pump_directories`
--

DROP TABLE IF EXISTS `pump_directories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pump_directories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL COMMENT '1=dealar, 2=shop, 3=machine',
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name_bn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `village_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `village_name_bn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address_bn` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `latitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attachment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `document_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `document_name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `division_id` int(11) NOT NULL,
  `district_id` int(11) NOT NULL,
  `upazila_id` int(11) NOT NULL,
  `union_id` int(11) NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pump_directories`
--

LOCK TABLES `pump_directories` WRITE;
/*!40000 ALTER TABLE `pump_directories` DISABLE KEYS */;
INSERT INTO `pump_directories` VALUES (1,1,'Armando Vance','Aimee Mills','Alvin Morales','Victoria Spence','Excepturi tempor est','Eaque perferendis eu','23.772682','90.4099791','Laborum Veritatis q','jysy@mailinator.com','1617013454.pdf','Ralph Dorsey','Armando Weeks',1,1,1,1,1,1,0,'2021-03-03 11:34:57','2021-03-29 10:24:14'),(2,2,'test','test name bn','test village','test village name bn','Test Address','Labore alias magna a','10.14','10.002146','545442124124','test@gmail.com','1614771386.jpg','test document name','Kylee Velez',1,1,1,1,1,NULL,0,'2021-03-03 11:36:26','2021-03-03 11:36:26'),(3,1,'test','test name bn','test village','test village name bn','Test Address','Labore alias magna a','','','54445445445','','','','',1,1,1,1,1,NULL,0,'2021-03-06 05:40:04','2021-03-06 05:40:04'),(4,1,'ee','erer','eer','rerere','ere','erere','23453243','3434343','1730233032','mamun@gmail.com',NULL,NULL,NULL,1,1,1,1,1,1,0,'2021-03-09 06:39:37','2021-03-09 06:39:37'),(5,1,'ee','erer','eer','rerere','ere','erere','23453243','3434343','1730233032','mamun@gmail.com',NULL,NULL,NULL,1,1,1,1,1,1,0,'2021-03-09 07:14:54','2021-03-09 07:14:54'),(6,2,'ee','erer','eer','rerere','ere','erere','23453243','3434343','1730233032','mamun@gmail.com',NULL,NULL,NULL,1,1,1,1,1,1,0,'2021-03-09 08:13:50','2021-03-09 08:13:50'),(7,3,'ee','erer','eer','rerere','ere','erere','23453243','3434343','1730233032','mamun@gmail.com',NULL,NULL,NULL,1,1,1,1,1,1,0,'2021-03-09 08:14:09','2021-03-09 08:14:09');
/*!40000 ALTER TABLE `pump_directories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pump_directory_equipments`
--

DROP TABLE IF EXISTS `pump_directory_equipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pump_directory_equipments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pump_directory_id` bigint(20) unsigned NOT NULL,
  `master_equipment_type_id` bigint(20) unsigned NOT NULL,
  `details` text COLLATE utf8_unicode_ci NOT NULL,
  `details_bn` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pump_directory_equipments_pump_directory_id_foreign` (`pump_directory_id`),
  CONSTRAINT `pump_directory_equipments_pump_directory_id_foreign` FOREIGN KEY (`pump_directory_id`) REFERENCES `pump_directories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pump_directory_equipments`
--

LOCK TABLES `pump_directory_equipments` WRITE;
/*!40000 ALTER TABLE `pump_directory_equipments` DISABLE KEYS */;
INSERT INTO `pump_directory_equipments` VALUES (2,2,1,'Voluptatem quasi pla','Ut sed velit sint d','2021-03-03 11:36:26','2021-03-03 11:36:26'),(3,3,1,'test details','test details','2021-03-06 05:40:04','2021-03-06 05:40:04'),(8,4,1,'Mamun Test','মামুন টেস্ট','2021-03-09 06:39:37','2021-03-09 06:39:37'),(9,4,1,'Mamun Test 1','মামুন টেস্ট 2','2021-03-09 06:39:37','2021-03-09 06:39:37'),(10,4,1,'Mamun Test 1','মামুন টেস্ট 2','2021-03-09 06:39:37','2021-03-09 06:39:37'),(11,5,1,'Mamun Test','মামুন টেস্ট','2021-03-09 07:14:54','2021-03-09 07:14:54'),(12,5,1,'Mamun Test 1','মামুন টেস্ট 2','2021-03-09 07:14:54','2021-03-09 07:14:54'),(13,5,1,'Mamun Test 1','মামুন টেস্ট 2','2021-03-09 07:14:55','2021-03-09 07:14:55'),(14,6,1,'Mamun Test','মামুন টেস্ট','2021-03-09 08:13:50','2021-03-09 08:13:50'),(15,6,1,'Mamun Test 1','মামুন টেস্ট 2','2021-03-09 08:13:50','2021-03-09 08:13:50'),(16,6,1,'Mamun Test 1','মামুন টেস্ট 2','2021-03-09 08:13:50','2021-03-09 08:13:50'),(17,7,1,'Mamun Test','মামুন টেস্ট','2021-03-09 08:14:09','2021-03-09 08:14:09'),(18,7,1,'Mamun Test 1','মামুন টেস্ট 2','2021-03-09 08:14:09','2021-03-09 08:14:09'),(19,7,1,'Mamun Test 1','মামুন টেস্ট 2','2021-03-09 08:14:09','2021-03-09 08:14:09'),(20,1,1,'Vitae velit consequ','Doloribus aspernatur','2021-03-29 10:24:14','2021-03-29 10:24:14'),(21,1,2,'Test Step 2','Test Step 2 bn','2021-03-29 10:24:14','2021-03-29 10:24:14');
/*!40000 ALTER TABLE `pump_directory_equipments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pump_drilling_log`
--

DROP TABLE IF EXISTS `pump_drilling_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pump_drilling_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `division_id` bigint(20) unsigned NOT NULL,
  `district_id` bigint(20) unsigned NOT NULL,
  `upazilla_id` bigint(20) unsigned NOT NULL,
  `union_id` bigint(20) unsigned NOT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `pump_id` bigint(20) unsigned NOT NULL,
  `mouza_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mouza_no_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jl_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jl_no_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plot_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plot_no_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `well_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `well_no_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `engineer_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `engineer_name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `drilling_contractor_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `drilling_contractor_name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `drilling_start_date` date DEFAULT NULL,
  `drilling_start_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `drilling_complete_date` date DEFAULT NULL,
  `drilling_complete_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logged_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rod_length` double DEFAULT NULL,
  `rod` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rod_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rod_from` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rod_to` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thickness` double DEFAULT NULL,
  `thickness_from` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thickness_to` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pump_drilling_log`
--

LOCK TABLES `pump_drilling_log` WRITE;
/*!40000 ALTER TABLE `pump_drilling_log` DISABLE KEYS */;
INSERT INTO `pump_drilling_log` VALUES (1,2,16,143,1292,15,24,'3',NULL,'10',NULL,'5',NULL,8,'Non voluptatem aute',NULL,'Randall Mcmahon','Brynn Frederick','Giacomo Sims','Nigel Jordan','2021-03-01','17:49','2021-03-03','13:19','',20,'Totam dicta eligendi','Minim ipsam qui accu','Enim sapiente enim o','At distinctio Ipsum',0,'Rerum inventore labo','Et eveniet voluptat','Adipisci in nihil es','Et consequatur irur',0,1,NULL,'2021-03-10 07:13:11','2021-03-15 06:20:43'),(2,2,16,143,1294,15,25,'10',NULL,'12',NULL,'60',NULL,3,'Est illum non duis',NULL,'Kylynn Kirkland','Hakeem Norman','Clark Fox','Clinton Montgomery','2021-03-10','18:08','2021-03-11','01:22','',20,'Sint pariatur Aute','Quos illo mollit des','Excepturi sed rem nu','Esse fugit debitis ',0,'Impedit eveniet qu','Tempor dicta anim fu','Ut esse at quasi nos','Consequuntur necessi',0,1,NULL,'2021-03-10 07:14:36','2021-03-15 06:20:47'),(3,2,16,143,1292,15,24,'3',NULL,'10',NULL,'5',NULL,9,'Temporibus Nam sapie',NULL,'Alfreda Strickland','Hunter Sears','Dalton Russell','Hilda Hinton','2021-03-01','18:15','2021-03-10','14:49','',49,'At voluptas quae cup','Totam et dolor sequi','Consectetur dicta ne','Non in iste atque do',0,'Consequat Deserunt ','Atque ut exercitatio','Occaecat dignissimos','Enim tempor iusto re',1,1,NULL,'2021-03-10 07:16:29','2021-03-15 06:17:03'),(4,2,16,143,1292,15,24,'3',NULL,'10',NULL,'5',NULL,7,'Sit autem ut delenit',NULL,'Brent Douglas','Sydnee Olson','Alexis Rivera','Ora Key','2021-03-14','20:16','2021-03-16','15:56','',63,'Est quia id fuga Cu','Cillum ducimus omni','Veritatis sit nemo r','Amet porro ut lorem',0,'Aut laboriosam comm','Laborum aut unde odi','Magna et dolore quas','Omnis consectetur o',0,1,NULL,'2021-03-10 07:17:29','2021-03-15 05:18:57'),(5,1,1,1,1,15,36,'Debalay 100/2',NULL,' 100/2',NULL,' 100/2',NULL,10,'Provident suscipit ',NULL,'Josiah James','Charde Meyers','Breanna Bird','Channing Nielsen','2021-03-01','12:17','2021-03-09','04:01','',89,'Sunt quos possimus ','Quaerat vero adipisc','Impedit expedita au','Incidunt pariatur ',23,'Magna et tempore et','Minus magna minima r','Sunt dolores molesti','In amet debitis dol',1,1,1,'2021-03-09 08:56:10','2021-03-14 17:22:24');
/*!40000 ALTER TABLE `pump_drilling_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pump_informations`
--

DROP TABLE IF EXISTS `pump_informations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pump_informations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `pump_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `division_id` bigint(20) unsigned NOT NULL,
  `district_id` bigint(20) unsigned NOT NULL,
  `upazilla_id` bigint(20) unsigned NOT NULL,
  `union_id` bigint(20) unsigned NOT NULL,
  `mouza_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jl_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plot_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `water_group_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `total_farmer` int(11) DEFAULT NULL,
  `added_farmer` int(11) DEFAULT NULL,
  `latitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `id_serial` int(11) DEFAULT NULL,
  `type_id` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=old Data, 1=new',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pump_informations`
--

LOCK TABLES `pump_informations` WRITE;
/*!40000 ALTER TABLE `pump_informations` DISABLE KEYS */;
INSERT INTO `pump_informations` VALUES (13,3,'1234',1,1,1,1,1,'123','12','4','2',10,1,'23.7837559','90.3934603',1,1,0,NULL,0,'2021-03-02 22:28:49','2021-03-27 06:23:08'),(14,3,'2000000',2,4,30,230,2087,'2','3','1','2',60,NULL,'3','2',1,1,1,NULL,0,'2021-03-02 22:29:01','2021-03-15 05:19:42'),(15,3,'2000001',1,6,47,365,3271,'1234','123','12345','1',NULL,NULL,'0','0',40,40,0,NULL,1,'2021-03-03 05:25:51','2021-03-03 05:25:51'),(16,3,'554',0,3,20,171,1516,'54','54','54','Quo mollit ut corpor',5,3,'45.667','456.66',1,1,0,NULL,0,'2021-03-03 09:14:39','2021-03-03 09:14:39'),(17,3,'244',2,5,38,294,2629,'10','10','10','3',50,NULL,'15','36',1,1,0,NULL,0,'2021-03-03 12:34:24','2021-03-06 07:35:02'),(18,3,'130',2,2,13,113,1034,'14','12','15','1',14,NULL,'15','26',1,1,0,NULL,0,'2021-03-03 12:36:52','2021-03-06 07:39:40'),(19,3,'131',1,7,54,404,3692,'121','14','36','1',150,NULL,'15','14',1,1,0,NULL,1,'2021-03-04 06:11:34','2021-03-06 07:35:34'),(20,3,'9000',1,3,22,186,1683,'123','123','1','123',150,NULL,'1','1',54,1,0,NULL,0,'2021-03-04 00:46:57','2021-03-06 07:38:18'),(21,3,'9001',1,5,38,293,2621,'35','36','37','1',1115,NULL,'28','21',1,1,0,NULL,1,'2021-03-04 06:47:16','2021-03-06 07:38:42'),(22,3,'22222222222222222',1,6,40,315,2813,'11111111111','222','2222222222222222','2222222222222222',200,NULL,'2222222222222222','2222222222222',54,1,0,NULL,0,'2021-03-04 00:47:24','2021-03-06 07:36:05'),(23,3,'897',2,1,1,1,1,'5','5','5','1',4,NULL,'','',1,1,0,NULL,0,'2021-03-06 06:28:37','2021-03-06 06:28:37'),(24,15,'2',3,2,16,143,1292,'3','10','5','1',100,NULL,'24.4366058','89.007411',1,1,0,NULL,0,'2021-03-06 07:19:44','2021-03-06 07:19:44'),(25,2,'10',4,2,16,143,1294,'10','12','60','5',100,NULL,'24.4033249','88.9811944',1,1,0,NULL,0,'2021-03-06 07:23:50','2021-03-06 07:23:50'),(26,3,'6324',2,1,1,1,1,'','','','1',6,1,'','',1,1,0,NULL,0,'2021-03-06 08:40:13','2021-03-06 08:40:13'),(36,3,'6325',1,1,1,1,1,'Debalay 100/2',' 100/2',' 100/2','1',NULL,NULL,'0','0',1,1,0,NULL,1,'2021-03-08 13:04:21','2021-03-08 13:04:21'),(37,15,'6326',1,1,1,1,1,'20','20','20','1',NULL,NULL,'0','0',1,1,0,NULL,1,'2021-03-08 14:44:55','2021-03-08 14:44:55'),(38,3,'6327',1,1,1,1,1,'test pump mouza no','test pump jl no','test pump plot no','1',NULL,NULL,'0','0',1,1,0,NULL,1,'2021-03-08 14:47:06','2021-03-08 14:47:06'),(39,3,'6328',1,1,1,1,1,'20','20','20','1',NULL,NULL,'0','0',1,1,0,NULL,1,'2021-03-23 05:31:28','2021-03-23 05:31:28'),(40,3,'6329',1,1,1,1,1,'43','343','4343','1',NULL,NULL,'0','0',1,1,0,NULL,1,'2021-03-23 11:24:35','2021-03-23 11:24:35'),(41,3,'6330',1,1,1,1,1,'11','11','1','1',NULL,NULL,'0','0',1,1,0,NULL,1,'2021-03-27 04:34:40','2021-03-27 04:34:40'),(42,3,'123',2,10,65,492,4541,'123','123','123','test',2,3,'qwe','ewq',1,1,0,NULL,0,'2021-04-10 23:24:59','2021-04-10 23:40:52');
/*!40000 ALTER TABLE `pump_informations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pump_operators`
--

DROP TABLE IF EXISTS `pump_operators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pump_operators` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `pump_id` bigint(20) unsigned NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Male,2=Female',
  `father_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `father_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nid` bigint(20) unsigned NOT NULL,
  `village_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `village_name_bn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `daily_task_entry_required` tinyint(4) DEFAULT NULL COMMENT '1=required,0=not required',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `pump_operator_user_id` bigint(20) unsigned NOT NULL,
  `pump_operator_username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pump_operator_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pump_operators_pump_id_foreign` (`pump_id`),
  CONSTRAINT `pump_operators_pump_id_foreign` FOREIGN KEY (`pump_id`) REFERENCES `pump_informations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pump_operators`
--

LOCK TABLES `pump_operators` WRITE;
/*!40000 ALTER TABLE `pump_operators` DISABLE KEYS */;
INSERT INTO `pump_operators` VALUES (11,3,13,'2222222','',1,'shamsuddin khan','','','',122222222222,'','','1234','','','',NULL,1,1,1,'2021-03-02 22:33:25','2021-03-15 05:22:03',41,'1234','fm_1234@gmail.com'),(12,3,14,'123','123',1,'','','','',444,'','','12345556678','','','',1,1,1,1,'2021-03-02 22:40:53','2021-03-16 07:47:20',43,'123455566','fm_123455566@gmail.com'),(16,3,15,'d','d',1,'d','d','d','d',3333444,'d','d','0188888888','d@gmail.com','3333','3333',1,1,1,0,'2021-03-03 10:01:40','2021-03-16 07:29:38',48,'0188888888','d@gmail.com'),(19,3,18,'test op','test op bn',1,'test father name','test father name bn','test mother name','test mother name bn',6521245421,'test village','test village name bn','011111111111','test@gmail.com','10.14','10.002146',NULL,1,1,1,'2021-03-03 12:38:04','2021-03-15 05:20:04',27,'011111111111','test@gmail.com'),(20,3,17,'Elijah Burch','Sierra Neal',1,'Amaya Garza','Penelope Gibson','Emerson Gay','Mona Hampton',33,'Megan Snyder','Anjolie Knapp','67','bypemufid@mailinator.com','Voluptatem et et do','Doloremque eos sit a',NULL,1,1,0,'2021-03-04 05:12:35','2021-03-04 05:12:35',51,'67','bypemufid@mailinator.com'),(22,3,13,'BADC User','BADC User bn',2,'Badc Father','Badc Father bn','Badc Mother','Badc Mother bn',45748540584,'Badc village','Badc village bn','01620506565','01846673958',NULL,NULL,NULL,1,1,1,'2021-03-06 04:37:14','2021-03-06 04:37:14',46,'01620506565','01846673958'),(25,3,23,'1234','1234',1,'shamsuddin khan','shamsuddin khan','suriya begum','suriya begum',12345,'011111111111','011111111111','12345','test@gmail.com','','',NULL,1,1,1,'2021-03-06 23:39:02','2021-03-06 23:39:02',27,'011111111111','test@gmail.com'),(26,3,13,'Md BMDA','এমডি বিএমডিএ',2,'Md Father','বিএমডিএ','Most Mother','Md BMDA',4574859495,'এমডি বিএমডিএ','বিএমডিএ','01730233032','01730233032',NULL,NULL,NULL,1,1,0,'2021-03-07 10:17:14','2021-03-07 10:17:14',52,'01730233032','01730233032'),(27,3,38,'sd','sd',1,'sd','sd','sd','sd',8154695,'sd','sd','01620656565','','','',NULL,1,1,0,'2021-03-09 11:15:07','2021-03-09 11:15:07',132,'01620656565','fm_01620656565@gmail.com'),(45,1,36,'Md Mamun Test','Md Mamun test bn',1,'Mamuns Fathers','Mamuns Fathers Bn','Mamun Mothers',' Mamun Mother bn',23434343,' vill name','vill name bn','1990181993','mamrr3rrrun@gmail.com','3434389473','3479384',NULL,NULL,NULL,0,'2021-03-10 06:51:13','2021-03-10 06:51:13',1,'1990181993','mamrr3rrrun@gmail.com'),(46,1,36,'Md Mamun Test','Md Mamun test bn',1,'Mamuns Fathers','Mamuns Fathers Bn','Mamun Mothers',' Mamun Mother bn',23434343,' vill name','vill name bn','1990181993','mamrr3rrrun@gmail.com','3434389473','3479384',NULL,NULL,NULL,0,'2021-03-10 06:54:58','2021-03-10 06:54:58',1,'1990181993','mamrr3rrrun@gmail.com'),(48,1,36,'Md Mamun bbbTest','Md Mambbbun test bn',1,'Mamuns Fathers','Mamuns Fathers Bn','Mamun Mothers',' Mamun Mother bn',40549,' vill name','vill name bn','01990185993','mamrrvvvccvv3rrrun@gmail.com','3434389473','3479384',NULL,NULL,NULL,0,'2021-03-10 07:16:50','2021-03-10 07:16:50',184,'01990185993','mamrrvvvccvv3rrrun@gmail.com'),(49,1,36,'Md Mamun bbbTest','Md Mambbbun test bn',1,'Mamuns Fathers','Mamuns Fathers Bn','Mamun Mothers',' Mamun Mother bn',40549,' vill name','vill name bn','01792938447','maymuna@gmail.com','3434389473','3479384',NULL,1,1,0,'2021-03-10 07:19:07','2021-03-10 07:19:07',185,'01792938447','maymuna@gmail.com'),(50,1,36,'Md Mamun bbbTest','Md Mambbbun test bn',1,'Mamuns Fathers','Mamuns Fathers Bn','Mamun Mothers',' Mamun Mother bn',40549,' vill name','vill name bn','01792938497','maymutna@gmail.com','3434389473','3479384',NULL,1,1,0,'2021-03-10 07:23:22','2021-03-10 07:23:22',186,'01792938497','maymutna@gmail.com'),(51,3,36,'Suman ','Suman bn',1,'MD.Rafiqul Islam','মোঃ রফিকুল ইসলাম','Shahanara Begum','শাহানারা বেগম',5641238745,'Sreemontapur','শ্রীমন্তপুর','01620506565','01767778333',NULL,NULL,NULL,1,1,0,'2021-03-10 08:44:03','2021-03-10 08:44:03',14,'01620506565','01767778333'),(52,3,36,'Suman ','Suman bn',1,'MD.Rafiqul Islam','মোঃ রফিকুল ইসলাম','Shahanara Begum','শাহানারা বেগম',5641238745,'Sreemontapur','শ্রীমন্তপুর','01620506565','01767778333',NULL,NULL,NULL,1,1,0,'2021-03-11 06:18:26','2021-03-11 06:18:26',14,'01620506565','01767778333'),(53,3,23,'Test farmer name','Test farmer name bn',1,'test father name','test father name bn','test mother name','test mother name bn',1425472454,'Test village ','Test village bn','05452121545','01782599354',NULL,NULL,NULL,1,1,0,'2021-03-11 10:24:24','2021-03-11 10:24:24',13,'05452121545','01782599354'),(54,3,23,'Test farmer name','Test farmer name bn',1,'test father name','test father name bn','test mother name','test mother name bn',1425472454,'Test village ','Test village bn','05452121545','01782599354',NULL,NULL,NULL,1,1,0,'2021-03-14 08:02:26','2021-03-14 08:02:26',13,'05452121545','01782599354'),(55,3,13,'test Mamun','mama bn',1,'fdfdf','dffdf','fddfdf','fdfdfd',4535,'Debalaya','দেবালয়1','01730233032','01730233032',NULL,NULL,NULL,1,1,0,'2021-03-23 10:50:23','2021-03-23 10:50:23',202,'01730233032','01730233032'),(56,3,13,'test Mamun','mama bn',1,'fdfdf','dffdf','fddfdf','fdfdfd',4535,'Debalaya','দেবালয়1','01730233032','01730233032',NULL,NULL,NULL,1,1,0,'2021-03-24 11:10:20','2021-03-24 11:10:20',202,'01730233032','01730233032'),(57,3,39,'Md Mamunur Rashid','মোঃ মামুনুর রশিদ',1,'fdfdf','dffdf','fddfdf','লাকি বেগম',4545454,'fgfg','gfgf','017302330377','mm@gmail.com','3434343','4343434',1,1,1,0,'2021-03-24 11:43:55','2021-03-24 11:43:55',214,'017302330377','mm@gmail.com'),(58,3,26,'Md Mamunur Rashid','মোঃ মামুনুর রশিদ',1,'fdfdf','dffdf','fddfdf','fdfdfd',454545445,'fgfg','gfgf','01730233039','mm@gmail.com','3434343','4343434',1,1,1,0,'2021-03-24 12:18:29','2021-03-24 12:18:29',216,'01730233039','mm@gmail.com'),(59,15,13,'test Mamun','mama bn',1,'fdfdf','dffdf','fddfdf','fdfdfd',4535,'Debalaya','দেবালয়1','01730233032','01730233032',NULL,NULL,NULL,1,1,0,'2021-03-28 08:55:17','2021-03-28 08:55:17',202,'01730233032','01730233032'),(60,15,41,'Admin21','অ্যাডমিন21',1,'ss','ss','ss','ss',784528888,'ss','ss','01733322221','01733322221',NULL,NULL,NULL,1,1,0,'2021-03-29 04:31:16','2021-03-29 04:31:16',113,'01733322221','01733322221'),(61,15,38,'Admin22','অ্যাডমিন22',1,'MD.Rafiqul Islam','মোঃ রফিকুল ইসলাম','Shahanara Begum','শাহানারা বেগম',23156456,'Sreemontapur','শ্রীমন্তপুর','01733322222','01733322222',NULL,NULL,NULL,1,1,0,'2021-03-29 05:04:33','2021-03-29 05:04:33',114,'01733322222','01733322222'),(62,3,42,'QA Test Farmer','QA Test Farmer(Bn)',1,'QA Test Father Name','QA Test Father Name(Bn)','QA Test Mother Name','QA Test Mother Name',45634636,'QA Test Village','QA Test Village(Bn)','01754019431','01754019430',NULL,NULL,NULL,1,1,0,'2021-04-11 03:30:28','2021-04-11 03:30:28',248,'01754019431','01754019430');
/*!40000 ALTER TABLE `pump_operators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pump_opt_apps_surveys`
--

DROP TABLE IF EXISTS `pump_opt_apps_surveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pump_opt_apps_surveys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pump_opt_apps_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `survey_date` date NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pump_opt_apps_surveys_pump_opt_apps_id_foreign` (`pump_opt_apps_id`),
  CONSTRAINT `pump_opt_apps_surveys_pump_opt_apps_id_foreign` FOREIGN KEY (`pump_opt_apps_id`) REFERENCES `far_pump_opt_apps` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pump_opt_apps_surveys`
--

LOCK TABLES `pump_opt_apps_surveys` WRITE;
/*!40000 ALTER TABLE `pump_opt_apps_surveys` DISABLE KEYS */;
INSERT INTO `pump_opt_apps_surveys` VALUES (1,3,74,'2021-03-27','sadfsd','asdfsdf','2021-03-27 07:03:37','2021-03-27 07:03:37'),(2,22,1,'2021-03-29','test','test','2021-03-29 04:30:40','2021-03-29 04:30:40'),(3,24,1,'2021-03-29','ok','ok bn','2021-03-29 04:43:42','2021-03-29 04:43:42'),(4,26,1,'2021-04-11','Surveyed','Surveyed(Bn)','2021-04-11 03:28:48','2021-04-11 03:28:48');
/*!40000 ALTER TABLE `pump_opt_apps_surveys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pump_opt_suspensions`
--

DROP TABLE IF EXISTS `pump_opt_suspensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pump_opt_suspensions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `pump_id` bigint(20) unsigned NOT NULL,
  `operator_id` bigint(20) unsigned NOT NULL,
  `reason` text COLLATE utf8_unicode_ci NOT NULL,
  `reason_bn` text COLLATE utf8_unicode_ci,
  `message` text COLLATE utf8_unicode_ci,
  `message_bn` text COLLATE utf8_unicode_ci,
  `suspend_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pump_opt_suspensions_pump_id_foreign` (`pump_id`),
  KEY `pump_opt_suspensions_operator_id_foreign` (`operator_id`),
  CONSTRAINT `pump_opt_suspensions_operator_id_foreign` FOREIGN KEY (`operator_id`) REFERENCES `pump_operators` (`id`),
  CONSTRAINT `pump_opt_suspensions_pump_id_foreign` FOREIGN KEY (`pump_id`) REFERENCES `pump_informations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pump_opt_suspensions`
--

LOCK TABLES `pump_opt_suspensions` WRITE;
/*!40000 ALTER TABLE `pump_opt_suspensions` DISABLE KEYS */;
INSERT INTO `pump_opt_suspensions` VALUES (6,3,13,11,'111111111111','11111','1','1111111111111111111111111','2021-03-03','2021-03-02 22:54:41','2021-03-02 22:54:41'),(7,3,14,12,'22','2','2','22','2021-03-03','2021-03-02 22:55:09','2021-03-02 22:55:09'),(8,3,13,22,'test','test','test','test','2021-03-06','2021-03-06 08:36:33','2021-03-06 08:36:33'),(9,3,23,23,'test','test','test','test','2021-03-06','2021-03-06 08:38:58','2021-03-06 08:38:58'),(10,3,26,24,'test','test','test','test','2021-03-06','2021-03-06 08:43:15','2021-03-06 08:43:15'),(11,3,23,25,'ok','ok','ok','ok','2021-03-07','2021-03-06 23:39:48','2021-03-06 23:39:48');
/*!40000 ALTER TABLE `pump_opt_suspensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pump_progress_type_steps`
--

DROP TABLE IF EXISTS `pump_progress_type_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pump_progress_type_steps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pump_progress_type_id` bigint(20) unsigned NOT NULL,
  `step_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `step_name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pump_progress_type_steps_pump_progress_type_id_foreign` (`pump_progress_type_id`),
  CONSTRAINT `pump_progress_type_steps_pump_progress_type_id_foreign` FOREIGN KEY (`pump_progress_type_id`) REFERENCES `master_pump_progress_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pump_progress_type_steps`
--

LOCK TABLES `pump_progress_type_steps` WRITE;
/*!40000 ALTER TABLE `pump_progress_type_steps` DISABLE KEYS */;
INSERT INTO `pump_progress_type_steps` VALUES (6,4,'step 1','STEP 1 bn',1,1,0,'2021-03-08 11:17:37','2021-03-08 11:17:37'),(7,4,'step 2','step 2 bn',1,1,0,'2021-03-08 11:17:38','2021-03-08 11:17:38'),(8,5,'Test step Name 1','Test step Name 1 bn',1,1,0,'2021-03-10 07:40:48','2021-03-10 07:40:48'),(9,5,'Test step Name 2','Test step Name 2 bn',1,1,0,'2021-03-10 07:40:48','2021-03-10 07:40:48'),(10,6,'Test step Name 1','Test step Name 1 bn',1,1,0,'2021-03-10 07:41:31','2021-03-10 07:41:31'),(11,7,'Test step Name 1','Test step Name 1 bn',1,1,0,'2021-03-10 07:42:47','2021-03-10 07:42:47'),(12,8,'Test step Name 1','Test step Name 1 bn',1,1,0,'2021-03-10 07:49:04','2021-03-10 07:49:04'),(13,8,'Test step Name 2','Test step Name 2 bn',1,1,0,'2021-03-10 07:49:04','2021-03-10 07:49:04'),(14,9,'fdgsfg','dfg',1,1,0,'2021-03-24 10:53:20','2021-03-24 10:53:20'),(15,10,'sdgds','sgds',1,1,0,'2021-03-24 10:53:39','2021-03-24 10:53:39'),(22,11,'one ','one ',NULL,1,0,'2021-03-28 07:19:21','2021-03-28 07:19:21'),(23,11,'step 2','step 2',NULL,1,0,'2021-03-28 07:19:21','2021-03-28 07:19:21'),(25,12,'QA Test Step','QA Test Step BN',NULL,1,0,'2021-04-12 03:11:16','2021-04-12 03:11:16'),(26,12,'QA Test Step 1','QA Test Step 1 Bn',NULL,1,0,'2021-04-12 03:11:16','2021-04-12 03:11:16'),(27,3,'Step 1','স্টেপ ১',NULL,1,0,'2021-04-12 03:14:25','2021-04-12 03:14:25'),(28,3,'step 2','step 2',NULL,1,0,'2021-04-12 03:14:25','2021-04-12 03:14:25'),(29,3,'step 3','step 3',NULL,1,0,'2021-04-12 03:14:25','2021-04-12 03:14:25');
/*!40000 ALTER TABLE `pump_progress_type_steps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pump_schedulers`
--

DROP TABLE IF EXISTS `pump_schedulers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pump_schedulers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `pump_id` bigint(20) unsigned NOT NULL,
  `ontime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `offtime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pump_schedulers`
--

LOCK TABLES `pump_schedulers` WRITE;
/*!40000 ALTER TABLE `pump_schedulers` DISABLE KEYS */;
INSERT INTO `pump_schedulers` VALUES (1,3,1,'12:22','14:02',1,1,0,'2021-02-24 03:32:11','2021-03-15 11:11:18'),(2,3,202020,'10:00','11:00',1,1,0,'2021-03-01 23:05:43','2021-03-15 06:28:43'),(3,3,1234,'00:11','23:11',1,1,1,'2021-03-02 10:19:24','2021-03-15 06:28:55'),(4,3,155,'17:00','19:00',1,1,0,'2021-03-02 11:00:32','2021-03-02 11:00:32'),(5,3,6324,'14:59','02:59',1,1,1,'2021-03-06 08:59:39','2021-03-15 06:28:48');
/*!40000 ALTER TABLE `pump_schedulers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pump_stock_in_details`
--

DROP TABLE IF EXISTS `pump_stock_in_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pump_stock_in_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `stock_in_infos_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `quantity` double(8,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pump_stock_in_details_stock_in_infos_id_foreign` (`stock_in_infos_id`),
  KEY `pump_stock_in_details_item_id_foreign` (`item_id`),
  CONSTRAINT `pump_stock_in_details_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `master_items` (`id`),
  CONSTRAINT `pump_stock_in_details_stock_in_infos_id_foreign` FOREIGN KEY (`stock_in_infos_id`) REFERENCES `pump_stock_in_infos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pump_stock_in_details`
--

LOCK TABLES `pump_stock_in_details` WRITE;
/*!40000 ALTER TABLE `pump_stock_in_details` DISABLE KEYS */;
INSERT INTO `pump_stock_in_details` VALUES (6,6,1,500.00,'2021-03-23 11:19:57','2021-03-23 11:19:57'),(7,7,1,2.00,'2021-04-11 22:13:16','2021-04-11 22:13:16'),(8,8,6,2.00,'2021-04-11 22:14:29','2021-04-11 22:14:29');
/*!40000 ALTER TABLE `pump_stock_in_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pump_stock_in_infos`
--

DROP TABLE IF EXISTS `pump_stock_in_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pump_stock_in_infos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `stock_in_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `office_id` bigint(20) unsigned NOT NULL,
  `id_serial` bigint(20) unsigned DEFAULT NULL,
  `stock_date` date NOT NULL,
  `status` int(11) DEFAULT '0' COMMENT '0=Active, 1= Inactive',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pump_stock_in_infos`
--

LOCK TABLES `pump_stock_in_infos` WRITE;
/*!40000 ALTER TABLE `pump_stock_in_infos` DISABLE KEYS */;
INSERT INTO `pump_stock_in_infos` VALUES (6,'STO100000',3,1,100000,'2021-03-01',0,1,1,'2021-03-23 11:19:57','2021-04-11 23:23:01'),(7,'STO100001',3,1,100001,'2021-04-12',0,1,1,'2021-04-11 22:13:16','2021-04-11 22:13:16'),(8,'STO100002',3,1,100002,'2021-04-01',0,1,1,'2021-04-11 22:14:29','2021-04-11 22:14:29');
/*!40000 ALTER TABLE `pump_stock_in_infos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pump_stock_out_details`
--

DROP TABLE IF EXISTS `pump_stock_out_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pump_stock_out_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `stock_out_infos_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `quantity` double(8,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pump_stock_out_details_stock_out_infos_id_foreign` (`stock_out_infos_id`),
  KEY `pump_stock_out_details_item_id_foreign` (`item_id`),
  CONSTRAINT `pump_stock_out_details_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `master_items` (`id`),
  CONSTRAINT `pump_stock_out_details_stock_out_infos_id_foreign` FOREIGN KEY (`stock_out_infos_id`) REFERENCES `pump_stock_out_infos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pump_stock_out_details`
--

LOCK TABLES `pump_stock_out_details` WRITE;
/*!40000 ALTER TABLE `pump_stock_out_details` DISABLE KEYS */;
INSERT INTO `pump_stock_out_details` VALUES (9,9,1,100.00,'2021-03-23 11:20:42','2021-03-23 11:20:42'),(10,10,1,50.00,'2021-03-23 11:38:54','2021-03-23 11:38:54'),(11,11,1,50.00,'2021-03-23 11:42:49','2021-03-23 11:42:49'),(12,12,1,50.00,'2021-03-23 11:55:12','2021-03-23 11:55:12'),(13,13,6,3.00,'2021-04-11 22:37:46','2021-04-11 22:37:46');
/*!40000 ALTER TABLE `pump_stock_out_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pump_stock_out_infos`
--

DROP TABLE IF EXISTS `pump_stock_out_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pump_stock_out_infos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `stock_out_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `office_id` bigint(20) unsigned NOT NULL,
  `id_serial` bigint(20) unsigned DEFAULT NULL,
  `stock_out_date` date NOT NULL,
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reason_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `purpose` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `purpose_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remarks` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remarks_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=pending, 1=approved',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pump_stock_out_infos`
--

LOCK TABLES `pump_stock_out_infos` WRITE;
/*!40000 ALTER TABLE `pump_stock_out_infos` DISABLE KEYS */;
INSERT INTO `pump_stock_out_infos` VALUES (9,'STOCKOUT100000',3,1,100000,'2021-03-23','','','','','','',1,1,1,'2021-03-23 11:20:42','2021-03-23 11:20:49'),(10,'STOCKOUT100001',3,1,100001,'2021-03-23','','','','','','',1,1,1,'2021-03-23 11:38:54','2021-03-23 11:39:17'),(11,'STOCKOUT100002',3,1,100002,'2021-03-23','','','','','','',1,1,1,'2021-03-23 11:42:49','2021-03-23 11:47:18'),(12,'STOCKOUT100003',3,1,100003,'2021-03-23','','','','','','',1,1,1,'2021-03-23 11:55:12','2021-03-23 11:55:21'),(13,'STOCKOUT100004',3,1,100004,'2021-04-12','s','s','s','s','s','s',1,1,0,'2021-04-11 22:37:46','2021-04-11 22:37:46');
/*!40000 ALTER TABLE `pump_stock_out_infos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheme_participation_fees`
--

DROP TABLE IF EXISTS `scheme_participation_fees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scheme_participation_fees` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scheme_application_id` bigint(20) unsigned NOT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `participation_category_id` int(11) DEFAULT NULL COMMENT '1=Deep Tubewell, 2=Irrigation Drain, 3=Electrification, 4=Solar',
  `discharge_cusec` double DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `tnxid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Unpaid, 2=Paid',
  `payment_type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Advanced, 2=Due',
  `payment_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `circle_area_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scheme_participation_fees_scheme_application_id_foreign` (`scheme_application_id`),
  CONSTRAINT `scheme_participation_fees_scheme_application_id_foreign` FOREIGN KEY (`scheme_application_id`) REFERENCES `far_scheme_application` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheme_participation_fees`
--

LOCK TABLES `scheme_participation_fees` WRITE;
/*!40000 ALTER TABLE `scheme_participation_fees` DISABLE KEYS */;
INSERT INTO `scheme_participation_fees` VALUES (9,3,3,2,10,1200,NULL,2,1,'2021-03-23','2021-03-23 04:18:09','2021-03-23 04:19:02',NULL),(10,3,3,1,10,500,NULL,2,2,'2021-03-23','2021-03-23 04:18:09','2021-03-23 04:19:05',NULL),(11,4,3,1,10,500,NULL,1,1,NULL,'2021-03-23 06:15:17','2021-03-23 06:15:17',NULL),(12,6,3,1,10,500,NULL,2,1,'2021-03-23','2021-03-23 11:10:50','2021-03-23 11:11:11',NULL),(13,5,15,NULL,NULL,500,NULL,1,1,NULL,'2021-03-24 10:09:30','2021-03-24 10:09:30',1),(14,8,15,NULL,NULL,500,NULL,2,1,'2021-03-24','2021-03-25 06:28:39','2021-03-25 06:28:39',1);
/*!40000 ALTER TABLE `scheme_participation_fees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheme_security_money`
--

DROP TABLE IF EXISTS `scheme_security_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scheme_security_money` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scheme_application_id` bigint(20) unsigned NOT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `pump_type_id` bigint(20) unsigned NOT NULL,
  `discharge_cusec` double(8,2) NOT NULL,
  `amount` double(8,2) NOT NULL,
  `tnxid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Unpaid, 2=Paid',
  `payment_type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Advanced, 2=Due',
  `payment_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scheme_security_money_scheme_application_id_foreign` (`scheme_application_id`),
  KEY `scheme_security_money_pump_type_id_foreign` (`pump_type_id`),
  CONSTRAINT `scheme_security_money_pump_type_id_foreign` FOREIGN KEY (`pump_type_id`) REFERENCES `master_pump_types` (`id`),
  CONSTRAINT `scheme_security_money_scheme_application_id_foreign` FOREIGN KEY (`scheme_application_id`) REFERENCES `far_scheme_application` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheme_security_money`
--

LOCK TABLES `scheme_security_money` WRITE;
/*!40000 ALTER TABLE `scheme_security_money` DISABLE KEYS */;
/*!40000 ALTER TABLE `scheme_security_money` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_scheme_types`
--

DROP TABLE IF EXISTS `sub_scheme_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_scheme_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sub_scheme_type_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sub_scheme_type_name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `master_scheme_type_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_scheme_types`
--

LOCK TABLES `sub_scheme_types` WRITE;
/*!40000 ALTER TABLE `sub_scheme_types` DISABLE KEYS */;
INSERT INTO `sub_scheme_types` VALUES (1,'fdfd bn','fdfd en',15,1,1,1,0,'2021-03-15 06:28:05','2021-03-15 06:28:05'),(2,'fdfd en','fdfd en',3,1,1,1,0,'2021-03-15 06:29:33','2021-03-18 11:42:51'),(3,'erer','eerere',3,1,1,1,0,'2021-03-18 11:43:01','2021-03-18 11:43:01'),(4,'erer','rttttttttt',3,1,1,1,0,'2021-03-18 11:43:16','2021-03-18 11:43:16'),(5,'QA Test Sub Scheme Type','QA Test Sub Scheme Type(Bn)',3,9,1,1,0,'2021-04-10 23:00:26','2021-04-10 23:00:26'),(6,'Lorem mollitia beata','Lorem enim qui aut t',15,1,1,1,0,'2021-04-12 03:47:06','2021-04-12 03:47:06'),(7,'Officia tempore qui','Sit reiciendis velit',15,4,1,1,0,'2021-04-12 03:47:30','2021-04-12 03:47:30'),(8,'Perferendis labore b','Qui nesciunt ipsum ',15,7,1,1,0,'2021-04-12 03:47:38','2021-04-12 03:47:38'),(9,'Qui odio velit cum v','Aliquid fuga Neque ',3,2,1,1,0,'2021-04-12 03:47:46','2021-04-12 03:47:46'),(10,'Eius aliqua Volupta','Ea voluptatum ducimu',15,4,1,1,0,'2021-04-12 03:48:48','2021-04-12 03:48:48'),(11,'Voluptates et dolor ','Deleniti nulla fugia',15,4,1,1,0,'2021-04-12 03:48:59','2021-04-12 03:48:59');
/*!40000 ALTER TABLE `sub_scheme_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_assign_tasks`
--

DROP TABLE IF EXISTS `task_assign_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_assign_tasks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) unsigned NOT NULL,
  `task_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `task_name_bn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `task_type_id` tinyint(4) NOT NULL,
  `is_verified` tinyint(4) NOT NULL DEFAULT '0',
  `assign_user_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `assign_username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note_bn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `attachment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `task_to` date DEFAULT NULL,
  `task_from` date DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_assign_tasks`
--

LOCK TABLES `task_assign_tasks` WRITE;
/*!40000 ALTER TABLE `task_assign_tasks` DISABLE KEYS */;
INSERT INTO `task_assign_tasks` VALUES (6,3,'Go To Office','Bangla Go To Office',1,0,'12','01843867772','your task is this your task is this your task is this your task is this your task is this your task is this your task is this your task is this your task','bangla task bangla task bangla task bangla task bangla task bangla task bangla task bangla task bangla task bangla task bangla task','1615018997.PNG',NULL,NULL,1,1,0,'2021-03-06 08:23:17','2021-03-06 08:23:17'),(7,3,'Dane Owen','Maggie Hewitt',2,0,'1','admin','y','y',NULL,NULL,NULL,1,1,0,'2021-03-09 05:20:19','2021-03-09 05:20:19'),(8,3,'Test it','Test it',2,0,'64','test_user6','1','2',NULL,NULL,NULL,1,1,0,'2021-03-09 01:00:23','2021-03-09 01:00:23'),(9,3,'Test task name','Test task name bn',2,1,'1','admin','test task note ','test task note bn',NULL,NULL,NULL,1,1,0,'2021-03-02 18:00:00','2021-03-14 06:01:36'),(10,3,'testinggg','Bangla testinggg',1,0,'12','01843867772','testinggg testinggg testinggg testinggg testinggg ','testinggg testinggg testinggg testinggg testinggg ','1615018997.PNG',NULL,NULL,1,1,0,'2021-03-04 08:23:17','2021-03-06 08:23:17'),(11,15,'Alexander Miranda','Sacha Ross',2,0,'1','admin','Magni ea aute possim','Vel sit sed sint it',NULL,NULL,NULL,1,1,0,'2021-03-15 07:09:27','2021-03-15 07:09:27'),(13,15,'dfsdfsd','fsdfsdfsdf',1,0,'10','12345678090','dfsdf','sdfsdfsd',NULL,'2021-03-25','2021-03-09',1,1,0,'2021-03-24 12:54:43','2021-03-24 12:54:43'),(14,3,'Brenda Bolton','Penelope Shannon',2,0,'74','sumanadmin','Quibusdam alias ut d','Et nisi accusantium ',NULL,'2021-03-25','2021-03-15',74,74,0,'2021-03-25 08:10:37','2021-03-25 08:10:37'),(15,3,'Skyler Dillard','Warren Cochran',2,0,'93','xyz','Saepe commodi nostru','Dolorem ut aliquam q',NULL,'2021-03-31','2021-03-29',74,74,0,'2021-03-25 08:11:55','2021-03-25 08:11:55'),(16,3,'Emily Erickson','Isabella Wilkins',1,1,'132','01620656565','Voluptas ad in tempo','Vel illum qui labor',NULL,'2021-04-02','2021-03-31',74,74,0,'2021-03-25 08:14:30','2021-03-25 10:56:20'),(17,3,'asd','asd',1,1,'1','1990181993','sdf','asdf',NULL,'2021-03-26','2021-03-25',1,1,0,'2021-03-25 10:51:26','2021-03-25 10:55:12'),(18,3,'myyyyyy','yrrrrrr',2,0,'74','sumanadmin','gggggg','hhhhhhh',NULL,'2021-03-31','2021-03-23',74,74,0,'2021-03-25 11:03:34','2021-03-25 11:03:34'),(19,3,'QA Test Task','QA Test Task Bn',1,1,'46','01620506565','No Task','No Task Bn','1618136659.pdf','2021-04-17','2021-04-11',1,1,0,'2021-04-11 04:24:19','2021-04-11 04:28:29'),(20,3,'QA Test Task1','QA Test Task BN',1,1,'52','01730233032','gdfgd bfg','ghgd gfds','1618137036.pdf','2021-04-17','2021-04-11',1,1,0,'2021-04-11 04:30:36','2021-04-11 04:32:17'),(21,3,'QA Test Task123','QA Test Task1234',1,1,'132','01620656565','ggfhgfh','hgfhgfh','1618137406.pdf','2021-04-14','2021-04-11',1,1,0,'2021-04-11 04:36:46','2021-04-11 22:21:32');
/*!40000 ALTER TABLE `task_assign_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_review_notes`
--

DROP TABLE IF EXISTS `task_review_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_review_notes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` bigint(20) unsigned NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note_bn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_review_notes_task_id_foreign` (`task_id`),
  CONSTRAINT `task_review_notes_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `task_assign_tasks` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_review_notes`
--

LOCK TABLES `task_review_notes` WRITE;
/*!40000 ALTER TABLE `task_review_notes` DISABLE KEYS */;
INSERT INTO `task_review_notes` VALUES (4,6,'fhgfhfgh','fhfghfghfg',1,1,0,'2021-03-06 09:34:56','2021-03-06 09:34:56'),(5,9,'I\'m testing review feature','I\'m testing review feature in bangla',74,74,0,'2021-03-25 10:21:40','2021-03-25 10:21:40'),(6,20,'review','dfsdfg',1,1,0,'2021-04-11 04:31:56','2021-04-11 04:31:56'),(7,21,'rr','rr',1,1,0,'2021-04-11 22:19:36','2021-04-11 22:19:36');
/*!40000 ALTER TABLE `task_review_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_task_reports`
--

DROP TABLE IF EXISTS `task_task_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_task_reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` bigint(20) unsigned NOT NULL,
  `complete_type_id` tinyint(4) NOT NULL,
  `attachment` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note_bn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `task_date` date NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_task_reports_task_id_foreign` (`task_id`),
  CONSTRAINT `task_task_reports_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `task_assign_tasks` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_task_reports`
--

LOCK TABLES `task_task_reports` WRITE;
/*!40000 ALTER TABLE `task_task_reports` DISABLE KEYS */;
INSERT INTO `task_task_reports` VALUES (4,6,1,'1615020448.PNG','sdfdsfdsf sdf sdfsd sdf sdsdf sdfsddsf sdfsd fsdfsdf sdfssdf sfsdfsdfs','dsfsdfdsfsddsfd sdfsdfsd sdf sd sdf sfs sdf sfsd fsdfdf sdfsdf sdfsdf sdf','2021-03-10',12,12,0,'2021-03-05 08:47:28','2021-03-06 08:47:28'),(5,9,1,'1615701590.txt','test task note','test task note bn','2021-03-14',1,1,0,'2021-03-12 18:00:00','2021-03-14 05:59:50'),(6,14,1,'1616665514.png','dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg dfgdg ','feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt feerrt ','2021-03-30',74,74,0,'2021-03-25 09:45:14','2021-03-25 09:45:14'),(7,18,2,'1616670251.png','fgfgdf','dfffff','2021-03-25',74,74,0,'2021-03-25 11:04:11','2021-03-25 11:04:11'),(8,21,2,'1618138412.pdf','fgfdg','ghfh','2021-04-12',132,132,0,'2021-04-11 04:53:32','2021-04-11 04:53:32'),(9,16,1,'1618139348.pdf','ghg','gh','2021-04-11',132,132,0,'2021-04-11 05:09:08','2021-04-11 05:09:08');
/*!40000 ALTER TABLE `task_task_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_logs`
--

DROP TABLE IF EXISTS `user_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `menu_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `table_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `data_id` bigint(20) unsigned NOT NULL,
  `ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `execution_type` int(11) NOT NULL COMMENT '0=insert, 1=update,2=delete',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `username_index` (`username`),
  KEY `uid_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2243 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_logs`
--

LOCK TABLES `user_logs` WRITE;
/*!40000 ALTER TABLE `user_logs` DISABLE KEYS */;
INSERT INTO `user_logs` VALUES (1,145,'farmer_123aaa','http://localhost:8080/my-profile-form','far_basic_infos',1,'',1,'2021-02-24 07:34:40','2021-02-24 07:34:40'),(2,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',1,'',0,'2021-02-24 03:02:06','2021-02-24 03:02:06'),(3,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/project-entry-list','master_projects',1,'',0,'2021-02-24 03:02:53','2021-02-24 03:02:53'),(4,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/contractor-list','master_contractors',1,'',0,'2021-02-24 03:03:59','2021-02-24 03:03:59'),(5,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/equipment-type-list','master_equipment_types',1,'',0,'2021-02-24 03:04:29','2021-02-24 03:04:29'),(6,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/scheme-type-list','master_scheme_types',1,'',0,'2021-02-24 03:05:43','2021-02-24 03:05:43'),(7,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/item-category-list','master_item_categories',1,'',0,'2021-02-24 03:06:24','2021-02-24 03:06:24'),(8,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/measurement-unit-list','master_measurement_units',1,'',0,'2021-02-24 03:07:59','2021-02-24 03:07:59'),(9,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/store-item-list','master_items',1,'',0,'2021-02-24 03:08:37','2021-02-24 03:08:37'),(10,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/pump-type-list','master_pump_types',1,'',0,'2021-02-24 03:09:33','2021-02-24 03:09:33'),(11,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/pump-installation-progress-type-list','master_pump_progress_types',1,'',0,'2021-02-24 03:10:11','2021-02-24 03:10:11'),(12,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/laboratory-list','master_laboratories',1,'',0,'2021-02-24 03:11:04','2021-02-24 03:11:04'),(13,9,'01533894967','http://103.199.168.69/my-profile-form','far_basic_infos',2,'',1,'2021-02-24 03:17:55','2021-02-24 03:17:55'),(14,9,'01533894967','http://103.199.168.69/my-profile-form','far_basic_infos',2,'',1,'2021-02-24 03:18:14','2021-02-24 03:18:14'),(15,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',1,'',0,'2021-02-24 03:20:17','2021-02-24 03:20:17'),(16,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/payment','master_payments',1,'',0,'2021-02-24 03:20:52','2021-02-24 03:20:52'),(17,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/payment','master_payments',2,'',0,'2021-02-24 03:21:18','2021-02-24 03:21:18'),(18,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/payment','master_payments',3,'',0,'2021-02-24 03:21:40','2021-02-24 03:21:40'),(19,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/payment','master_payments',4,'',0,'2021-02-24 03:23:27','2021-02-24 03:23:27'),(20,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/payment','master_payments',5,'',0,'2021-02-24 03:23:45','2021-02-24 03:23:45'),(21,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/payment','master_payments',6,'',0,'2021-02-24 03:24:06','2021-02-24 03:24:06'),(22,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/payment','master_payments',7,'',0,'2021-02-24 03:24:23','2021-02-24 03:24:23'),(23,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/payment','master_payments',8,'',0,'2021-02-24 03:24:48','2021-02-24 03:24:48'),(24,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/payment','master_payments',9,'',0,'2021-02-24 03:25:03','2021-02-24 03:25:03'),(25,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/payment','master_payments',10,'',0,'2021-02-24 03:25:24','2021-02-24 03:25:24'),(26,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/payment','master_payments',11,'',0,'2021-02-24 03:25:35','2021-02-24 03:25:35'),(27,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/payment','master_payments',12,'',0,'2021-02-24 03:25:48','2021-02-24 03:25:48'),(28,1,'admin','http://103.199.168.69/irrigation/pump-information/pump-information-list','pump_informations',1,'',0,'2021-02-24 03:29:05','2021-02-24 03:29:05'),(29,1,'admin','http://103.199.168.69/irrigation/pump-information/pump-operator-list','pump_operators',1,'',0,'2021-02-24 03:30:34','2021-02-24 03:30:34'),(30,1,'admin','http://103.199.168.69/irrigation/pump-information/pump-scheduler-list','pump_schedulers',1,'',0,'2021-02-24 03:32:11','2021-02-24 03:32:11'),(31,11,'01793143870','http://103.199.168.69/my-profile-form','far_basic_infos',3,'',1,'2021-02-25 14:24:52','2021-02-25 14:24:52'),(32,11,'01793143870','http://103.199.168.69/my-profile-form','far_basic_infos',3,'',1,'2021-02-25 14:25:02','2021-02-25 14:25:02'),(33,11,'01793143870','http://103.199.168.69/water-testing-request-list','far_pump_opt_rejects',1,'',0,'2021-02-25 14:25:38','2021-02-25 14:25:38'),(34,11,'01793143870','http://103.199.168.69/water-testing-request-list','irrigation_payments',1,'',0,'2021-02-25 14:25:38','2021-02-25 14:25:38'),(35,11,'01793143870','http://103.199.168.69/water-testing-request-list#','far_pump_opt_rejects',2,'',0,'2021-02-25 14:40:31','2021-02-25 14:40:31'),(36,11,'01793143870','http://103.199.168.69/water-testing-request-list#','irrigation_payments',2,'',0,'2021-02-25 14:40:31','2021-02-25 14:40:31'),(37,12,'01843867772','http://103.199.168.69/my-profile-form','far_basic_infos',4,'',1,'2021-03-01 04:32:28','2021-03-01 04:32:28'),(38,12,'01843867772','http://103.199.168.69/water-testing-request-list','far_pump_opt_rejects',3,'',0,'2021-03-01 04:32:55','2021-03-01 04:32:55'),(39,12,'01843867772','http://103.199.168.69/water-testing-request-list','irrigation_payments',3,'',0,'2021-03-01 04:32:55','2021-03-01 04:32:55'),(40,1,'admin','http://103.199.168.69/irrigation/water-testing/drinking-water','far_pump_opt_apps',3,'',2,'2021-03-01 04:35:35','2021-03-01 04:35:35'),(41,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',1,'',1,'2021-03-01 04:50:26','2021-03-01 04:50:26'),(42,12,'01843867772','http://103.199.168.69/water-testing-request-list','far_pump_opt_rejects',4,'',0,'2021-03-01 04:54:19','2021-03-01 04:54:19'),(43,12,'01843867772','http://103.199.168.69/water-testing-request-list','irrigation_payments',4,'',0,'2021-03-01 04:54:19','2021-03-01 04:54:19'),(44,12,'01843867772','http://103.199.168.69/water-testing-request-list','far_pump_opt_rejects',5,'',0,'2021-03-01 05:27:17','2021-03-01 05:27:17'),(45,12,'01843867772','http://103.199.168.69/water-testing-request-list','irrigation_payments',5,'',0,'2021-03-01 05:27:17','2021-03-01 05:27:17'),(46,12,'01843867772','http://localhost:8080/smart-card-application-form','irrigation_payments',6,'',0,'2021-03-02 04:54:01','2021-03-02 04:54:01'),(47,12,'01843867772','http://localhost:8080/smart-card-application-form','far_smart_card_apps',1,'',0,'2021-03-02 04:54:01','2021-03-02 04:54:01'),(48,12,'01843867772','http://localhost:8080/smart-card-application/edit/1','far_smart_card_apps',1,'',1,'2021-03-02 04:54:13','2021-03-02 04:54:13'),(49,1,'admin','http://localhost:8080/irrigation/card-payment/new-application','far_smart_card_apps',1,'',2,'2021-03-02 04:56:10','2021-03-02 04:56:10'),(50,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',2,'',0,'2021-03-01 22:58:03','2021-03-01 22:58:03'),(51,1,'admin','http://localhost:8080/irrigation/card-payment/new-application','far_smart_card_apps',1,'',2,'2021-03-02 05:04:41','2021-03-02 05:04:41'),(52,1,'admin','http://localhost:8080/irrigation/pump-information/pump-scheduler-list','pump_schedulers',2,'',0,'2021-03-01 23:05:43','2021-03-01 23:05:43'),(53,13,'01782599354','http://localhost:8081/my-profile-form','far_basic_infos',5,'',1,'2021-03-02 05:06:40','2021-03-02 05:06:40'),(54,1,'admin','http://localhost:8081/irrigation-scheme-service/configuration/scheme-type-list','master_scheme_types',2,'',0,'2021-03-02 05:08:04','2021-03-02 05:08:04'),(55,12,'01843867772','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',6,'',0,'2021-03-02 05:09:34','2021-03-02 05:09:34'),(56,12,'01843867772','http://localhost:8080/water-testing-request-list','irrigation_payments',7,'',0,'2021-03-02 05:09:34','2021-03-02 05:09:34'),(57,14,'01767778333','http://localhost:8080/my-profile-form','far_basic_infos',6,'',1,'2021-03-02 05:12:16','2021-03-02 05:12:16'),(58,14,'01767778333','http://localhost:8080/farmer-complain','far_complains',1,'',0,'2021-03-02 05:12:42','2021-03-02 05:12:42'),(59,13,'01782599354','http://localhost:8081/scheme-application-submit','far_scheme_application',1,'',0,'2021-03-02 05:13:37','2021-03-02 05:13:37'),(60,13,'01782599354','http://localhost:8081/water-testing-request-list','far_pump_opt_rejects',7,'',0,'2021-03-02 05:15:23','2021-03-02 05:15:23'),(61,13,'01782599354','http://localhost:8081/water-testing-request-list','irrigation_payments',8,'',0,'2021-03-02 05:15:23','2021-03-02 05:15:23'),(62,1,'admin','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',1,'',1,'2021-03-02 05:18:07','2021-03-02 05:18:07'),(63,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',1,'',1,'2021-03-02 05:19:04','2021-03-02 05:19:04'),(64,1,'admin','http://localhost:8081/irrigation/water-testing/drinking-water','far_pump_opt_apps',7,'',2,'2021-03-02 05:19:07','2021-03-02 05:19:07'),(65,1,'admin','http://localhost:8081/irrigation/water-testing/drinking-water','far_pump_opt_apps',4,'',2,'2021-03-02 05:26:40','2021-03-02 05:26:40'),(66,12,'01843867772','http://localhost:8080/water-testing-request-list','pump_operators',5,'',1,'2021-03-02 05:28:34','2021-03-02 05:28:34'),(67,12,'01843867772','http://localhost:8080/scheme-application-submit','far_scheme_application',2,'',0,'2021-03-02 05:32:11','2021-03-02 05:32:11'),(68,12,'01843867772','http://localhost:8080/scheme-application-submit/2','far_scheme_application',2,'',1,'2021-03-02 05:32:42','2021-03-02 05:32:42'),(69,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_pump_opt_apps',4,'',2,'2021-03-02 05:34:19','2021-03-02 05:34:19'),(70,14,'01767778333','http://localhost:8080/scheme-application-submit','far_scheme_application',3,'',0,'2021-03-02 05:35:24','2021-03-02 05:35:24'),(71,14,'01767778333','http://localhost:8080/scheme-application','irrigation_payments',9,'',0,'2021-03-02 05:38:21','2021-03-02 05:38:21'),(72,13,'01782599354','http://localhost:8081/water-testing-request-list#','far_pump_opt_rejects',8,'',0,'2021-03-02 05:40:47','2021-03-02 05:40:47'),(73,13,'01782599354','http://localhost:8081/water-testing-request-list#','irrigation_payments',10,'',0,'2021-03-02 05:40:47','2021-03-02 05:40:47'),(74,1,'admin','http://localhost:8081/irrigation/water-testing/irrigation-water','far_pump_opt_apps',8,'',2,'2021-03-02 05:41:50','2021-03-02 05:41:50'),(75,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_pump_opt_apps',3,'',2,'2021-03-02 05:46:24','2021-03-02 05:46:24'),(76,1,'admin','http://localhost:8081/irrigation/water-testing/irrigation-water#','far_pump_opt_apps',8,'',2,'2021-03-02 05:46:26','2021-03-02 05:46:26'),(77,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_pump_opt_apps',4,'',2,'2021-03-02 05:46:28','2021-03-02 05:46:28'),(78,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_pump_opt_apps',7,'',2,'2021-03-02 05:46:31','2021-03-02 05:46:31'),(79,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',3,'',2,'2021-03-02 05:51:01','2021-03-02 05:51:01'),(80,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',13,'',0,'2021-03-02 05:55:16','2021-03-02 05:55:16'),(81,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',3,'',2,'2021-03-02 05:55:29','2021-03-02 05:55:29'),(82,12,'01843867772','http://localhost:8080/scheme-application','irri_scheme_payments',11,'',0,'2021-03-02 05:55:45','2021-03-02 05:55:45'),(83,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status/0','far_scheme_license',1,'',0,'2021-03-02 06:03:52','2021-03-02 06:03:52'),(84,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status/0','far_scheme_license',1,'',1,'2021-03-02 06:03:58','2021-03-02 06:03:58'),(85,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_pump_opt_apps',4,'',2,'2021-03-02 06:10:32','2021-03-02 06:10:32'),(86,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_pump_opt_apps',3,'',2,'2021-03-02 06:12:46','2021-03-02 06:12:46'),(87,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_pump_opt_apps',4,'',2,'2021-03-02 06:13:03','2021-03-02 06:13:03'),(88,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',1,'',0,'2021-03-02 06:18:58','2021-03-02 06:18:58'),(89,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',3,'',1,'2021-03-02 06:19:11','2021-03-02 06:19:11'),(90,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',1,'',0,'2021-03-02 06:19:11','2021-03-02 06:19:11'),(91,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',2,'',0,'2021-03-02 00:20:53','2021-03-02 00:20:53'),(92,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_pump_opt_apps',3,'',2,'2021-03-02 06:21:20','2021-03-02 06:21:20'),(93,13,'01782599354','http://localhost:8081/water-testing-request-list#','far_pump_opt_rejects',9,'',0,'2021-03-02 06:22:19','2021-03-02 06:22:19'),(94,13,'01782599354','http://localhost:8081/water-testing-request-list#','irrigation_payments',12,'',0,'2021-03-02 06:22:19','2021-03-02 06:22:19'),(95,1,'admin','http://localhost:8081/irrigation/water-testing/industrial-water#','far_pump_opt_apps',9,'',2,'2021-03-02 06:27:15','2021-03-02 06:27:15'),(96,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_pump_opt_apps',4,'',2,'2021-03-02 06:28:57','2021-03-02 06:28:57'),(97,1,'admin','http://localhost:8081/irrigation/water-testing/irrigation-water','far_water_test_apps',8,'',2,'2021-03-02 06:35:17','2021-03-02 06:35:17'),(98,1,'admin','http://localhost:8081/irrigation/water-testing/drinking-water','far_water_test_apps',7,'',2,'2021-03-02 06:35:36','2021-03-02 06:35:36'),(99,1,'admin','http://localhost:8081/irrigation/water-testing/industrial-water','far_water_test_apps',9,'',2,'2021-03-02 06:35:47','2021-03-02 06:35:47'),(100,1,'admin','http://localhost:8080/irrigation/pump-information/pump-scheduler-list#','pump_schedulers',2,'',2,'2021-03-02 00:37:14','2021-03-02 00:37:14'),(101,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-suspension-list','pump_opt_suspensions',1,'',0,'2021-03-02 00:41:27','2021-03-02 00:41:27'),(102,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_pump_opt_apps',3,'',2,'2021-03-02 06:41:52','2021-03-02 06:41:52'),(103,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_pump_opt_apps',4,'',2,'2021-03-02 06:41:56','2021-03-02 06:41:56'),(104,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',1,'',1,'2021-03-02 00:42:47','2021-03-02 00:42:47'),(105,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',1,'',1,'2021-03-02 00:44:57','2021-03-02 00:44:57'),(106,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',2,'',1,'2021-03-02 00:45:43','2021-03-02 00:45:43'),(107,1,'admin','http://localhost:8081/irrigation/water-testing/drinking-water','far_pump_opt_apps',7,'',2,'2021-03-02 06:46:11','2021-03-02 06:46:11'),(108,1,'admin','http://localhost:8081/irrigation/water-testing/irrigation-water','far_water_test_apps',8,'',2,'2021-03-02 06:48:05','2021-03-02 06:48:05'),(109,1,'admin','http://localhost:8081/irrigation/water-testing/drinking-water','far_water_test_apps',7,'',2,'2021-03-02 06:48:15','2021-03-02 06:48:15'),(110,1,'admin','http://localhost:8081/irrigation/water-testing/testing-report-collection','far_water_test_apps',8,'',2,'2021-03-02 06:50:19','2021-03-02 06:50:19'),(111,1,'admin','http://localhost:8081/irrigation/water-testing/testing-report-collection','far_water_test_apps',7,'',2,'2021-03-02 06:50:56','2021-03-02 06:50:56'),(112,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',2,'',1,'2021-03-02 00:51:21','2021-03-02 00:51:21'),(113,13,'01782599354','http://localhost:8081/water-testing-request-list#','far_pump_opt_rejects',10,'',0,'2021-03-02 06:52:09','2021-03-02 06:52:09'),(114,13,'01782599354','http://localhost:8081/water-testing-request-list#','irrigation_payments',13,'',0,'2021-03-02 06:52:09','2021-03-02 06:52:09'),(115,13,'01782599354','http://localhost:8081/water-testing-request-list#','far_pump_opt_rejects',11,'',0,'2021-03-02 06:52:22','2021-03-02 06:52:22'),(116,13,'01782599354','http://localhost:8081/water-testing-request-list#','irrigation_payments',14,'',0,'2021-03-02 06:52:22','2021-03-02 06:52:22'),(117,13,'01782599354','http://localhost:8081/water-testing-request-list#','far_pump_opt_rejects',12,'',0,'2021-03-02 06:52:33','2021-03-02 06:52:33'),(118,13,'01782599354','http://localhost:8081/water-testing-request-list#','irrigation_payments',15,'',0,'2021-03-02 06:52:33','2021-03-02 06:52:33'),(119,1,'admin','http://localhost:8081/irrigation/water-testing/drinking-water','far_water_test_apps',10,'',2,'2021-03-02 06:53:24','2021-03-02 06:53:24'),(120,1,'admin','http://localhost:8081/irrigation/water-testing/industrial-water','far_water_test_apps',12,'',2,'2021-03-02 06:53:39','2021-03-02 06:53:39'),(121,1,'admin','http://localhost:8081/irrigation/water-testing/irrigation-water','far_water_test_apps',11,'',2,'2021-03-02 06:53:55','2021-03-02 06:53:55'),(122,1,'admin','http://localhost:8081/irrigation/water-testing/testing-report-collection','far_water_test_apps',9,'',2,'2021-03-02 06:54:20','2021-03-02 06:54:20'),(123,1,'admin','http://localhost:8081/irrigation/water-testing/testing-report-collection','far_water_test_apps',10,'',2,'2021-03-02 06:54:33','2021-03-02 06:54:33'),(124,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 06:56:48','2021-03-02 06:56:48'),(125,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 06:58:35','2021-03-02 06:58:35'),(126,13,'01782599354','http://localhost:8081/water-testing-request-list#','far_pump_opt_rejects',13,'',0,'2021-03-02 06:58:43','2021-03-02 06:58:43'),(127,13,'01782599354','http://localhost:8081/water-testing-request-list#','irrigation_payments',16,'',0,'2021-03-02 06:58:43','2021-03-02 06:58:43'),(128,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 07:01:19','2021-03-02 07:01:19'),(129,1,'admin','http://localhost:8081/irrigation/water-testing/irrigation-water','far_water_test_apps',13,'',2,'2021-03-02 07:01:20','2021-03-02 07:01:20'),(130,1,'admin','http://localhost:8081/irrigation/water-testing/testing-report-collection','far_water_test_apps',13,'',2,'2021-03-02 07:02:20','2021-03-02 07:02:20'),(131,1,'admin','http://localhost:8081/irrigation/water-testing/water-testing-reported','far_water_test_apps',13,'',2,'2021-03-02 07:04:12','2021-03-02 07:04:12'),(132,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 07:05:04','2021-03-02 07:05:04'),(133,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 07:11:22','2021-03-02 07:11:22'),(134,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 07:11:48','2021-03-02 07:11:48'),(135,13,'01782599354','http://localhost:8081/water-testing-request-list#','far_pump_opt_rejects',14,'',0,'2021-03-02 07:12:49','2021-03-02 07:12:49'),(136,13,'01782599354','http://localhost:8081/water-testing-request-list#','irrigation_payments',17,'',0,'2021-03-02 07:12:49','2021-03-02 07:12:49'),(137,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 07:12:59','2021-03-02 07:12:59'),(138,13,'01782599354','http://localhost:8081/water-testing-request-list#','far_pump_opt_rejects',15,'',0,'2021-03-02 07:13:04','2021-03-02 07:13:04'),(139,13,'01782599354','http://localhost:8081/water-testing-request-list#','irrigation_payments',18,'',0,'2021-03-02 07:13:05','2021-03-02 07:13:05'),(140,13,'01782599354','http://localhost:8081/water-testing-request-list#','far_pump_opt_rejects',16,'',0,'2021-03-02 07:13:19','2021-03-02 07:13:19'),(141,13,'01782599354','http://localhost:8081/water-testing-request-list#','irrigation_payments',19,'',0,'2021-03-02 07:13:19','2021-03-02 07:13:19'),(142,13,'01782599354','http://localhost:8081/water-testing-request-list#','far_pump_opt_rejects',17,'',0,'2021-03-02 07:13:34','2021-03-02 07:13:34'),(143,13,'01782599354','http://localhost:8081/water-testing-request-list#','irrigation_payments',20,'',0,'2021-03-02 07:13:34','2021-03-02 07:13:34'),(144,1,'admin','http://localhost:8081/irrigation/water-testing/testing-report-collection','far_water_test_apps',7,'',2,'2021-03-02 07:13:51','2021-03-02 07:13:51'),(145,1,'admin','http://localhost:8080/irrigation/water-testing/testing-report-collection','far_water_test_apps',12,'',2,'2021-03-02 07:13:56','2021-03-02 07:13:56'),(146,1,'admin','http://localhost:8081/irrigation/water-testing/testing-report-collection','far_water_test_apps',8,'',2,'2021-03-02 07:13:58','2021-03-02 07:13:58'),(147,1,'admin','http://localhost:8081/irrigation/water-testing/testing-report-collection','far_water_test_apps',9,'',2,'2021-03-02 07:14:04','2021-03-02 07:14:04'),(148,1,'admin','http://localhost:8081/irrigation/water-testing/testing-report-collection','far_water_test_apps',10,'',2,'2021-03-02 07:14:10','2021-03-02 07:14:10'),(149,1,'admin','http://localhost:8081/irrigation/water-testing/testing-report-collection','far_water_test_apps',11,'',2,'2021-03-02 07:14:20','2021-03-02 07:14:20'),(150,1,'admin','http://localhost:8081/irrigation/water-testing/water-testing-reported','far_water_test_apps',8,'',2,'2021-03-02 07:14:35','2021-03-02 07:14:35'),(151,1,'admin','http://localhost:8081/irrigation/water-testing/water-testing-reported','far_water_test_apps',7,'',2,'2021-03-02 07:14:37','2021-03-02 07:14:37'),(152,1,'admin','http://localhost:8081/irrigation/water-testing/water-testing-reported','far_water_test_apps',9,'',2,'2021-03-02 07:14:40','2021-03-02 07:14:40'),(153,1,'admin','http://localhost:8081/irrigation/water-testing/water-testing-reported','far_water_test_apps',10,'',2,'2021-03-02 07:14:42','2021-03-02 07:14:42'),(154,1,'admin','http://localhost:8081/irrigation/water-testing/water-testing-reported','far_water_test_apps',12,'',2,'2021-03-02 07:14:44','2021-03-02 07:14:44'),(155,1,'admin','http://localhost:8081/irrigation/water-testing/water-testing-reported','far_water_test_apps',11,'',2,'2021-03-02 07:14:46','2021-03-02 07:14:46'),(156,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 07:17:37','2021-03-02 07:17:37'),(157,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 07:19:00','2021-03-02 07:19:00'),(158,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 07:19:48','2021-03-02 07:19:48'),(159,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 07:34:47','2021-03-02 07:34:47'),(160,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_pump_opt_apps',15,'',2,'2021-03-02 07:35:07','2021-03-02 07:35:07'),(161,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 07:38:29','2021-03-02 07:38:29'),(162,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 07:39:25','2021-03-02 07:39:25'),(163,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 07:40:06','2021-03-02 07:40:06'),(164,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 07:40:46','2021-03-02 07:40:46'),(165,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 08:16:03','2021-03-02 08:16:03'),(166,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 08:18:32','2021-03-02 08:18:32'),(167,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 08:22:46','2021-03-02 08:22:46'),(168,9,'01533894967','http://localhost:8080/scheme-application-submit','far_scheme_application',4,'',0,'2021-03-02 08:30:31','2021-03-02 08:30:31'),(169,9,'01533894967','http://localhost:8080/scheme-application','scheme_farmers_land_details',1,'',0,'2021-03-02 08:33:23','2021-03-02 08:33:23'),(170,9,'01533894967','http://localhost:8080/scheme-application','scheme_farmers_land_details',2,'',0,'2021-03-02 08:34:00','2021-03-02 08:34:00'),(171,9,'01533894967','http://localhost:8080/scheme-application','scheme_farmers_land_details',3,'',0,'2021-03-02 08:34:36','2021-03-02 08:34:36'),(172,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card#','far_smart_card_apps',1,'',2,'2021-03-02 08:35:57','2021-03-02 08:35:57'),(173,9,'01533894967','http://localhost:8080/scheme-application','scheme_farmers_land_details',4,'',0,'2021-03-02 08:36:01','2021-03-02 08:36:01'),(174,9,'01533894967','http://localhost:8080/scheme-application','irrigation_payments',21,'',0,'2021-03-02 08:36:56','2021-03-02 08:36:56'),(175,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card#','far_smart_card_apps',1,'',2,'2021-03-02 08:37:32','2021-03-02 08:37:32'),(176,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',3,'',0,'2021-03-02 08:38:55','2021-03-02 08:38:55'),(177,13,'01782599354','http://localhost:8080/smart-card-application-form','irrigation_payments',22,'',0,'2021-03-02 08:39:17','2021-03-02 08:39:17'),(178,13,'01782599354','http://localhost:8080/smart-card-application-form','far_smart_card_apps',2,'',0,'2021-03-02 08:39:17','2021-03-02 08:39:17'),(179,13,'01782599354','http://localhost:8080/smart-card-application/edit/2','far_smart_card_apps',2,'',1,'2021-03-02 08:39:35','2021-03-02 08:39:35'),(180,9,'01533894967','http://localhost:8080/pump-opt-application','far_pump_opt_apps',1,'',0,'2021-03-02 08:45:19','2021-03-02 08:45:19'),(181,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card#','far_smart_card_apps',1,'',2,'2021-03-02 08:45:33','2021-03-02 08:45:33'),(182,9,'01533894967','http://localhost:8080/pump-operator-application','irrigation_payments',23,'',0,'2021-03-02 08:45:28','2021-03-02 08:45:28'),(183,9,'01533894967','http://localhost:8080/pump-operator-application','irrigation_payments',24,'',0,'2021-03-02 08:45:36','2021-03-02 08:45:36'),(184,9,'01533894967','http://localhost:8080/pump-operator-application','irrigation_payments',25,'',0,'2021-03-02 08:46:16','2021-03-02 08:46:16'),(185,9,'01533894967','http://localhost:8080/smart-card-application-form','irrigation_payments',26,'',0,'2021-03-02 08:48:04','2021-03-02 08:48:04'),(186,9,'01533894967','http://localhost:8080/smart-card-application-form','far_smart_card_apps',3,'',0,'2021-03-02 08:48:04','2021-03-02 08:48:04'),(187,9,'01533894967','http://localhost:8080/smart-card-application-form','irrigation_payments',27,'',0,'2021-03-02 08:48:10','2021-03-02 08:48:10'),(188,9,'01533894967','http://localhost:8080/smart-card-application-form','far_smart_card_apps',4,'',0,'2021-03-02 08:48:10','2021-03-02 08:48:10'),(189,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card#','far_smart_card_apps',1,'',2,'2021-03-02 08:48:22','2021-03-02 08:48:22'),(190,9,'01533894967','http://localhost:8080/smart-card-application/edit/4','far_smart_card_apps',4,'',1,'2021-03-02 08:49:44','2021-03-02 08:49:44'),(191,1,'admin','http://localhost:8080/irrigation/card-payment/new-application#','far_smart_card_apps',2,'',2,'2021-03-02 08:50:24','2021-03-02 08:50:24'),(192,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card#','far_smart_card_apps',1,'',2,'2021-03-02 08:50:50','2021-03-02 08:50:50'),(193,9,'01533894967','http://localhost:8080/farmer-complain','far_complains',2,'',0,'2021-03-02 08:51:06','2021-03-02 08:51:06'),(194,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card#','far_smart_card_apps',3,'',2,'2021-03-02 08:51:40','2021-03-02 08:51:40'),(195,9,'01533894967','http://localhost:8080/farmer-complain','far_complains',3,'',0,'2021-03-02 08:51:34','2021-03-02 08:51:34'),(196,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card#','far_smart_card_apps',2,'',2,'2021-03-02 08:51:44','2021-03-02 08:51:44'),(197,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-02 09:01:59','2021-03-02 09:01:59'),(198,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',1,'',0,'2021-03-02 09:09:55','2021-03-02 09:09:55'),(199,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-out','pump_stock_out_infos',1,'',0,'2021-03-02 09:11:44','2021-03-02 09:11:44'),(200,9,'01533894967','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',18,'',0,'2021-03-02 09:13:58','2021-03-02 09:13:58'),(201,9,'01533894967','http://localhost:8080/water-testing-request-list','irrigation_payments',28,'',0,'2021-03-02 09:13:58','2021-03-02 09:13:58'),(202,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card#','far_smart_card_apps',4,'',2,'2021-03-02 09:31:52','2021-03-02 09:31:52'),(203,19,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',7,'',1,'2021-03-02 09:33:31','2021-03-02 09:33:31'),(204,12,'01843867772','http://localhost:8080/smart-card-application-form','irrigation_payments',29,'',0,'2021-03-02 09:38:02','2021-03-02 09:38:02'),(205,12,'01843867772','http://localhost:8080/smart-card-application-form','far_smart_card_apps',5,'',0,'2021-03-02 09:38:02','2021-03-02 09:38:02'),(206,12,'01843867772','http://localhost:8080/smart-card-application/edit/5','far_smart_card_apps',5,'',1,'2021-03-02 09:41:15','2021-03-02 09:41:15'),(207,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',1,'',0,'2021-03-02 09:48:23','2021-03-02 09:48:23'),(208,19,'01730233032','http://localhost:8080/smart-card-application-form','irrigation_payments',30,'',0,'2021-03-02 09:50:02','2021-03-02 09:50:02'),(209,19,'01730233032','http://localhost:8080/smart-card-application-form','far_smart_card_apps',6,'',0,'2021-03-02 09:50:02','2021-03-02 09:50:02'),(210,12,'01843867772','http://localhost:8080/irrigation/card-payment/new-application','far_smart_card_apps',5,'',2,'2021-03-02 10:01:53','2021-03-02 10:01:53'),(211,12,'01843867772','http://localhost:8080/irrigation/card-payment/new-application','far_smart_card_apps',6,'',2,'2021-03-02 10:01:56','2021-03-02 10:01:56'),(212,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',2,'',0,'2021-03-02 10:02:11','2021-03-02 10:02:11'),(213,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',4,'',0,'2021-03-02 10:02:48','2021-03-02 10:02:48'),(214,12,'01843867772','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',4,'',2,'2021-03-02 10:07:00','2021-03-02 10:07:00'),(215,12,'01843867772','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',3,'',2,'2021-03-02 10:07:02','2021-03-02 10:07:02'),(216,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',5,'',0,'2021-03-02 10:11:13','2021-03-02 10:11:13'),(217,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',6,'',0,'2021-03-02 10:14:05','2021-03-02 10:14:05'),(218,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',7,'',0,'2021-03-02 10:14:23','2021-03-02 10:14:23'),(219,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',8,'',0,'2021-03-02 10:14:38','2021-03-02 10:14:38'),(220,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',9,'',0,'2021-03-02 10:15:02','2021-03-02 10:15:02'),(221,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',10,'',0,'2021-03-02 10:15:22','2021-03-02 10:15:22'),(222,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',11,'',0,'2021-03-02 10:15:53','2021-03-02 10:15:53'),(223,12,'01843867772','http://localhost:8080/irrigation/card-payment/new-application','far_smart_card_apps',6,'',2,'2021-03-02 10:16:46','2021-03-02 10:16:46'),(224,12,'01843867772','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',6,'',2,'2021-03-02 10:16:59','2021-03-02 10:16:59'),(225,1,'admin','http://localhost:8080/irrigation/pump-information/pump-scheduler-list','pump_schedulers',3,'',0,'2021-03-02 10:19:24','2021-03-02 10:19:24'),(226,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-suspension-list','pump_opt_suspensions',2,'',0,'2021-03-02 10:20:09','2021-03-02 10:20:09'),(227,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',3,'',0,'2021-03-02 10:22:35','2021-03-02 10:22:35'),(228,1,'admin','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',2,'',1,'2021-03-02 10:28:39','2021-03-02 10:28:39'),(229,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complain_tro_equipments',1,'',0,'2021-03-02 10:30:56','2021-03-02 10:30:56'),(230,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',2,'',1,'2021-03-02 10:31:08','2021-03-02 10:31:08'),(231,19,'01730233032','http://localhost:8080/smart-card-application','irrigation_payments',31,'',0,'2021-03-02 10:31:20','2021-03-02 10:31:20'),(232,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_requisitions',1,'',0,'2021-03-02 10:35:30','2021-03-02 10:35:30'),(233,19,'01730233032','http://localhost:8080/smart-card-application','irrigation_payments',32,'',0,'2021-03-02 10:37:46','2021-03-02 10:37:46'),(234,1,'admin','http://localhost:8080/irrigation/water-testing/irrigation-water','far_pump_opt_apps',16,'',2,'2021-03-02 10:38:46','2021-03-02 10:38:46'),(235,19,'01730233032','http://localhost:8080/smart-card-application','irrigation_payments',33,'',0,'2021-03-02 10:39:05','2021-03-02 10:39:05'),(236,1,'admin','http://localhost:8080/irrigation/water-testing/irrigation-water','far_water_test_apps',16,'',2,'2021-03-02 10:40:17','2021-03-02 10:40:17'),(237,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',4,'',0,'2021-03-02 10:43:34','2021-03-02 10:43:34'),(238,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',5,'',0,'2021-03-02 10:48:57','2021-03-02 10:48:57'),(239,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',6,'',0,'2021-03-02 10:49:34','2021-03-02 10:49:34'),(240,1,'admin','http://localhost:8080/irrigation/pump-information/pump-scheduler-list','pump_schedulers',4,'',0,'2021-03-02 11:00:32','2021-03-02 11:00:32'),(241,1,'admin','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',3,'',1,'2021-03-02 11:11:39','2021-03-02 11:11:39'),(242,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-suspension-list','pump_opt_suspensions',3,'',0,'2021-03-02 11:12:07','2021-03-02 11:12:07'),(243,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-suspension-list','pump_opt_suspensions',4,'',0,'2021-03-02 11:14:07','2021-03-02 11:14:07'),(244,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-suspension-list','pump_opt_suspensions',5,'',0,'2021-03-02 11:23:27','2021-03-02 11:23:27'),(245,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',14,'',0,'2021-03-02 11:42:04','2021-03-02 11:42:04'),(246,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',15,'',0,'2021-03-02 11:43:35','2021-03-02 11:43:35'),(247,13,'01782599354','http://localhost:8080/scheme-application','irrigation_payments',34,'',0,'2021-03-02 11:43:45','2021-03-02 11:43:45'),(248,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',1,'',1,'2021-03-02 11:44:51','2021-03-02 11:44:51'),(249,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',1,'',0,'2021-03-02 11:44:51','2021-03-02 11:44:51'),(250,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',1,'',0,'2021-03-02 11:44:51','2021-03-02 11:44:51'),(251,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',1,'',1,'2021-03-02 11:45:26','2021-03-02 11:45:26'),(252,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',1,'',0,'2021-03-02 11:45:26','2021-03-02 11:45:26'),(253,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',1,'',2,'2021-03-02 11:47:08','2021-03-02 11:47:08'),(254,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',12,'',0,'2021-03-02 05:48:57','2021-03-02 05:48:57'),(255,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',12,'',1,'2021-03-02 05:49:12','2021-03-02 05:49:12'),(256,12,'01843867772','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',19,'',0,'2021-03-02 11:49:10','2021-03-02 11:49:10'),(257,12,'01843867772','http://localhost:8080/water-testing-request-list','irrigation_payments',35,'',0,'2021-03-02 11:49:11','2021-03-02 11:49:11'),(258,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',1,'',2,'2021-03-02 11:50:53','2021-03-02 11:50:53'),(259,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status/1','far_scheme_license',2,'',0,'2021-03-02 11:51:27','2021-03-02 11:51:27'),(260,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status/1','far_scheme_license',2,'',1,'2021-03-02 11:51:43','2021-03-02 11:51:43'),(261,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',2,'',0,'2021-03-02 11:52:31','2021-03-02 11:52:31'),(262,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',1,'',1,'2021-03-02 11:52:40','2021-03-02 11:52:40'),(263,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',2,'',0,'2021-03-02 11:52:40','2021-03-02 11:52:40'),(264,13,'01782599354','http://localhost:8080/scheme-application-submit','far_scheme_application',5,'',0,'2021-03-02 12:06:10','2021-03-02 12:06:10'),(265,13,'01782599354','http://localhost:8080/scheme-application','irrigation_payments',36,'',0,'2021-03-02 12:06:47','2021-03-02 12:06:47'),(266,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',5,'',1,'2021-03-02 12:09:11','2021-03-02 12:09:11'),(267,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',2,'',0,'2021-03-02 12:09:11','2021-03-02 12:09:11'),(268,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',2,'',0,'2021-03-02 12:09:11','2021-03-02 12:09:11'),(269,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',5,'',1,'2021-03-02 12:09:11','2021-03-02 12:09:11'),(270,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',3,'',0,'2021-03-02 12:09:11','2021-03-02 12:09:11'),(271,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',3,'',0,'2021-03-02 12:09:11','2021-03-02 12:09:11'),(272,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',5,'',2,'2021-03-02 12:14:03','2021-03-02 12:14:03'),(273,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',5,'',2,'2021-03-02 12:16:31','2021-03-02 12:16:31'),(274,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',3,'',0,'2021-03-02 12:18:30','2021-03-02 12:18:30'),(275,1,'admin','http://localhost:8080/irrigation/task/task-tracker','task_review_notes',1,'',0,'2021-03-02 12:18:37','2021-03-02 12:18:37'),(276,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',3,'',1,'2021-03-02 12:18:40','2021-03-02 12:18:40'),(277,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',1,'',0,'2021-03-02 12:26:47','2021-03-02 12:26:47'),(278,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',2,'',0,'2021-03-02 12:27:42','2021-03-02 12:27:42'),(279,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',1,'',1,'2021-03-02 06:30:05','2021-03-02 06:30:05'),(280,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',3,'',0,'2021-03-02 12:30:56','2021-03-02 12:30:56'),(281,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/contractor-list','master_contractors',2,'',0,'2021-03-02 12:33:17','2021-03-02 12:33:17'),(282,19,'01730233032','http://localhost:8080/scheme-application-submit#','far_scheme_application',6,'',0,'2021-03-02 12:39:02','2021-03-02 12:39:02'),(283,19,'01730233032','http://localhost:8080/scheme-application','irrigation_payments',37,'',0,'2021-03-02 12:39:14','2021-03-02 12:39:14'),(284,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list#','master_scheme_affidavits',3,'',0,'2021-03-02 12:43:49','2021-03-02 12:43:49'),(285,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',2,'',0,'2021-03-02 12:47:52','2021-03-02 12:47:52'),(286,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-type-list','master_pump_types',1,'',2,'2021-03-02 12:55:21','2021-03-02 12:55:21'),(287,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-type-list','master_pump_types',1,'',2,'2021-03-02 12:55:24','2021-03-02 12:55:24'),(288,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list','master_laboratories',2,'',0,'2021-03-02 12:59:26','2021-03-02 12:59:26'),(289,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/equipment-type-list','master_equipment_types',2,'',0,'2021-03-02 13:03:18','2021-03-02 13:03:18'),(290,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list#','pump_operators',7,'',0,'2021-03-02 07:03:23','2021-03-02 07:03:23'),(291,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list#','pump_operators',8,'',0,'2021-03-02 07:04:18','2021-03-02 07:04:18'),(292,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list#','pump_operators',9,'',0,'2021-03-02 07:07:02','2021-03-02 07:07:02'),(293,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',2,'',0,'2021-03-02 14:05:15','2021-03-02 14:05:15'),(294,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',3,'',0,'2021-03-02 14:12:49','2021-03-02 14:12:49'),(295,1,'admin','http://localhost:8080/irrigation/task/task-calendar','task_task_reports',1,'',0,'2021-03-02 14:47:51','2021-03-02 14:47:51'),(296,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',13,'',0,'2021-03-02 22:28:49','2021-03-02 22:28:49'),(297,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',14,'',0,'2021-03-02 22:29:01','2021-03-02 22:29:01'),(298,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',13,'',1,'2021-03-02 22:31:16','2021-03-02 22:31:16'),(299,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',14,'',1,'2021-03-02 22:31:27','2021-03-02 22:31:27'),(300,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',10,'',0,'2021-03-02 22:31:53','2021-03-02 22:31:53'),(301,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',11,'',0,'2021-03-02 22:33:25','2021-03-02 22:33:25'),(302,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',3,'',0,'2021-03-03 04:35:44','2021-03-03 04:35:44'),(303,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',5,'',1,'2021-03-03 04:36:17','2021-03-03 04:36:17'),(304,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',3,'',0,'2021-03-03 04:36:18','2021-03-03 04:36:18'),(305,13,'01782599354','http://localhost:8080/scheme-application','irrigation_payments',38,'',0,'2021-03-03 04:37:36','2021-03-03 04:37:36'),(306,13,'01782599354','http://localhost:8080/scheme-application','irrigation_payments',39,'',0,'2021-03-03 04:39:04','2021-03-03 04:39:04'),(307,1,'admin','http://localhost:8080/irrigation/water-testing/testing-report-collection','far_water_test_apps',16,'',2,'2021-03-03 04:40:34','2021-03-03 04:40:34'),(308,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',12,'',0,'2021-03-02 22:40:54','2021-03-02 22:40:54'),(309,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',12,'',1,'2021-03-02 22:41:20','2021-03-02 22:41:20'),(310,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',12,'',1,'2021-03-02 22:41:45','2021-03-02 22:41:45'),(311,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',14,'',1,'2021-03-02 22:42:16','2021-03-02 22:42:16'),(312,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',12,'',1,'2021-03-02 22:42:29','2021-03-02 22:42:29'),(313,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',11,'',1,'2021-03-02 22:43:54','2021-03-02 22:43:54'),(314,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',12,'',1,'2021-03-02 22:43:58','2021-03-02 22:43:58'),(315,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-03 04:52:31','2021-03-03 04:52:31'),(316,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',4,'',0,'2021-03-03 04:52:31','2021-03-03 04:52:31'),(317,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',5,'',0,'2021-03-03 04:52:31','2021-03-03 04:52:31'),(318,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-03 04:52:31','2021-03-03 04:52:31'),(319,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',5,'',0,'2021-03-03 04:52:31','2021-03-03 04:52:31'),(320,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',7,'',0,'2021-03-03 04:52:31','2021-03-03 04:52:31'),(321,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-03 04:52:31','2021-03-03 04:52:31'),(322,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',6,'',0,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(323,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',9,'',0,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(324,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(325,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',7,'',0,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(326,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',11,'',0,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(327,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(328,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',8,'',0,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(329,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',13,'',0,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(330,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(331,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(332,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(333,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',11,'',0,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(334,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',15,'',0,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(335,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(336,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',9,'',0,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(337,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',10,'',0,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(338,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',12,'',0,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(339,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',19,'',0,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(340,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',18,'',0,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(341,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',21,'',0,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(342,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(343,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',13,'',0,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(344,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',23,'',0,'2021-03-03 04:52:32','2021-03-03 04:52:32'),(345,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-03 04:52:33','2021-03-03 04:52:33'),(346,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',14,'',0,'2021-03-03 04:52:33','2021-03-03 04:52:33'),(347,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',25,'',0,'2021-03-03 04:52:33','2021-03-03 04:52:33'),(348,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-03 04:52:33','2021-03-03 04:52:33'),(349,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',15,'',0,'2021-03-03 04:52:33','2021-03-03 04:52:33'),(350,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',27,'',0,'2021-03-03 04:52:33','2021-03-03 04:52:33'),(351,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-03 04:52:33','2021-03-03 04:52:33'),(352,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',16,'',0,'2021-03-03 04:52:33','2021-03-03 04:52:33'),(353,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',29,'',0,'2021-03-03 04:52:33','2021-03-03 04:52:33'),(354,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-03 04:52:34','2021-03-03 04:52:34'),(355,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',17,'',0,'2021-03-03 04:52:34','2021-03-03 04:52:34'),(356,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',31,'',0,'2021-03-03 04:52:34','2021-03-03 04:52:34'),(357,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-suspension-list','pump_opt_suspensions',6,'',0,'2021-03-02 22:54:41','2021-03-02 22:54:41'),(358,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-suspension-list','pump_opt_suspensions',7,'',0,'2021-03-02 22:55:09','2021-03-02 22:55:09'),(359,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list#','master_circle_areas',1,'',1,'2021-03-03 04:56:28','2021-03-03 04:56:28'),(360,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-03 04:56:28','2021-03-03 04:56:28'),(361,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',2,'',0,'2021-03-03 04:56:28','2021-03-03 04:56:28'),(362,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',2,'2021-03-03 04:56:52','2021-03-03 04:56:52'),(363,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',4,'',2,'2021-03-03 04:57:34','2021-03-03 04:57:34'),(364,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',1,'',0,'2021-03-03 04:59:46','2021-03-03 04:59:46'),(365,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',4,'',0,'2021-03-03 05:03:44','2021-03-03 05:03:44'),(366,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',4,'',1,'2021-03-03 05:04:51','2021-03-03 05:04:51'),(367,44,'01924496004','http://localhost:8080/my-profile-form','far_basic_infos',8,'',1,'2021-03-02 23:06:14','2021-03-02 23:06:14'),(368,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list#','master_circle_areas',3,'',0,'2021-03-03 05:06:19','2021-03-03 05:06:19'),(369,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',4,'',1,'2021-03-03 05:06:58','2021-03-03 05:06:58'),(370,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',4,'',0,'2021-03-03 05:06:58','2021-03-03 05:06:58'),(371,9,'01533894967','http://localhost:8080/scheme-application','irrigation_payments',40,'',0,'2021-03-03 05:08:43','2021-03-03 05:08:43'),(372,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_application',5,'',1,'2021-03-03 05:09:24','2021-03-03 05:09:24'),(373,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',1,'',1,'2021-03-03 05:09:25','2021-03-03 05:09:25'),(374,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',2,'',0,'2021-03-03 05:15:19','2021-03-03 05:15:19'),(375,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',2,'',0,'2021-03-03 05:15:40','2021-03-03 05:15:40'),(376,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',8,'',0,'2021-03-03 05:16:29','2021-03-03 05:16:29'),(377,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_application',4,'',1,'2021-03-03 05:17:15','2021-03-03 05:17:15'),(378,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',2,'',1,'2021-03-03 05:17:15','2021-03-03 05:17:15'),(379,13,'01782599354','http://localhost:8080/scheme-application-submit','far_scheme_application',7,'',0,'2021-03-03 05:20:30','2021-03-03 05:20:30'),(380,13,'01782599354','http://localhost:8080/scheme-application','irrigation_payments',41,'',0,'2021-03-03 05:20:42','2021-03-03 05:20:42'),(381,12,'01843867772','http://localhost:8080/scheme-application-submit/2','far_scheme_application',2,'',1,'2021-03-03 05:20:46','2021-03-03 05:20:46'),(382,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',7,'',1,'2021-03-03 05:21:13','2021-03-03 05:21:13'),(383,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',3,'',0,'2021-03-03 05:21:14','2021-03-03 05:21:14'),(384,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',7,'',1,'2021-03-03 05:21:41','2021-03-03 05:21:41'),(385,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',18,'',0,'2021-03-03 05:21:41','2021-03-03 05:21:41'),(386,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',32,'',0,'2021-03-03 05:21:41','2021-03-03 05:21:41'),(387,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',7,'',2,'2021-03-03 05:21:53','2021-03-03 05:21:53'),(388,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',7,'',2,'2021-03-03 05:22:43','2021-03-03 05:22:43'),(389,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_application',4,'',1,'2021-03-03 05:25:04','2021-03-03 05:25:04'),(390,40,'01791894967','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_supply_equipments',1,'',0,'2021-03-03 05:25:04','2021-03-03 05:25:04'),(391,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',5,'',0,'2021-03-03 05:26:10','2021-03-03 05:26:10'),(392,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',5,'',1,'2021-03-03 05:26:15','2021-03-03 05:26:15'),(393,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',9,'',0,'2021-03-03 05:26:39','2021-03-03 05:26:39'),(394,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',10,'',0,'2021-03-03 05:27:32','2021-03-03 05:27:32'),(395,13,'01782599354','http://localhost:8080/scheme-application-submit','far_scheme_application',8,'',0,'2021-03-03 05:30:52','2021-03-03 05:30:52'),(396,13,'01782599354','http://localhost:8080/scheme-application','irrigation_payments',42,'',0,'2021-03-03 05:31:01','2021-03-03 05:31:01'),(397,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',8,'',1,'2021-03-03 05:31:18','2021-03-03 05:31:18'),(398,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',4,'',0,'2021-03-03 05:31:18','2021-03-03 05:31:18'),(399,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',8,'',1,'2021-03-03 05:31:56','2021-03-03 05:31:56'),(400,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',19,'',0,'2021-03-03 05:31:57','2021-03-03 05:31:57'),(401,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',33,'',0,'2021-03-03 05:31:57','2021-03-03 05:31:57'),(402,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',8,'',2,'2021-03-03 05:32:30','2021-03-03 05:32:30'),(403,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',11,'',0,'2021-03-03 05:36:02','2021-03-03 05:36:02'),(404,40,'01791894967','http://localhost:8080/irrigation/water-testing/irrigation-water','far_pump_opt_apps',18,'',2,'2021-03-03 05:39:50','2021-03-03 05:39:50'),(405,40,'01791894967','http://localhost:8080/irrigation/water-testing/irrigation-water','far_water_test_apps',18,'',2,'2021-03-03 05:40:05','2021-03-03 05:40:05'),(406,40,'01791894967','http://localhost:8080/irrigation/water-testing/testing-report-collection','far_water_test_apps',18,'',2,'2021-03-03 05:40:46','2021-03-03 05:40:46'),(407,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',8,'',2,'2021-03-03 05:42:16','2021-03-03 05:42:16'),(408,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',12,'',0,'2021-03-03 05:42:28','2021-03-03 05:42:28'),(409,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',6,'',0,'2021-03-03 05:42:51','2021-03-03 05:42:51'),(410,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',6,'',1,'2021-03-03 05:42:57','2021-03-03 05:42:57'),(411,40,'01791894967','http://localhost:8080/irrigation/water-testing/water-testing-reported','far_water_test_apps',18,'',2,'2021-03-03 05:43:09','2021-03-03 05:43:09'),(412,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',4,'',0,'2021-03-03 05:43:56','2021-03-03 05:43:56'),(413,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',13,'',0,'2021-03-03 05:44:38','2021-03-03 05:44:38'),(414,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',14,'',0,'2021-03-03 05:44:48','2021-03-03 05:44:48'),(415,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',15,'',0,'2021-03-03 05:45:32','2021-03-03 05:45:32'),(416,40,'01791894967','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complain_tro_equipments',2,'',0,'2021-03-03 05:46:56','2021-03-03 05:46:56'),(417,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',16,'',0,'2021-03-03 05:47:04','2021-03-03 05:47:04'),(418,40,'01791894967','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',3,'',1,'2021-03-03 05:47:04','2021-03-03 05:47:04'),(419,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',8,'',1,'2021-03-03 05:48:37','2021-03-03 05:48:37'),(420,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',5,'',0,'2021-03-03 05:48:37','2021-03-03 05:48:37'),(421,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-out','pump_stock_out_infos',2,'',0,'2021-03-03 05:49:28','2021-03-03 05:49:28'),(422,13,'01782599354','http://localhost:8080/scheme-application','irrigation_payments',43,'',0,'2021-03-03 05:49:42','2021-03-03 05:49:42'),(423,40,'01791894967','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complains',2,'',1,'2021-03-03 05:50:53','2021-03-03 05:50:53'),(424,40,'01791894967','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_requisitions',1,'',1,'2021-03-03 05:50:54','2021-03-03 05:50:54'),(425,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',17,'',0,'2021-03-03 05:52:52','2021-03-03 05:52:52'),(426,40,'01791894967','http://localhost:8080/irrigation/pump-maintenance/supply-equipment','far_complain_supply_equipments',1,'',0,'2021-03-03 05:52:57','2021-03-03 05:52:57'),(427,40,'01791894967','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_progress_reports',1,'',0,'2021-03-03 05:53:34','2021-03-03 05:53:34'),(428,13,'01782599354','http://localhost:8080/scheme-application','irrigation_payments',44,'',0,'2021-03-03 05:54:41','2021-03-03 05:54:41'),(429,1,'admin','&nbsp;','my_assign_tasks',1,'',0,'2021-03-03 05:55:24','2021-03-03 05:55:24'),(430,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',18,'',0,'2021-03-03 05:56:06','2021-03-03 05:56:06'),(431,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',19,'',0,'2021-03-03 05:56:18','2021-03-03 05:56:18'),(432,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',20,'',0,'2021-03-03 05:56:31','2021-03-03 05:56:31'),(433,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',1,'',1,'2021-03-03 05:56:39','2021-03-03 05:56:39'),(434,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',21,'',0,'2021-03-03 05:57:08','2021-03-03 05:57:08'),(435,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',3,'',0,'2021-03-03 05:57:17','2021-03-03 05:57:17'),(436,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',3,'',0,'2021-03-03 05:57:39','2021-03-03 05:57:39'),(437,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',22,'',0,'2021-03-03 05:59:50','2021-03-03 05:59:50'),(438,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_application',8,'',1,'2021-03-03 06:00:38','2021-03-03 06:00:38'),(439,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',3,'',1,'2021-03-03 06:00:38','2021-03-03 06:00:38'),(440,1,'admin','&nbsp;','my_assign_tasks',1,'',1,'2021-03-03 06:01:44','2021-03-03 06:01:44'),(441,13,'01782599354','http://localhost:8080/pump-opt-application','far_pump_opt_apps',2,'',0,'2021-03-03 06:04:56','2021-03-03 06:04:56'),(442,1,'admin','&nbsp;','my_assign_tasks',1,'',2,'2021-03-03 06:05:37','2021-03-03 06:05:37'),(443,1,'admin','&nbsp;','master_loan_rates',1,'',2,'2021-03-03 06:07:33','2021-03-03 06:07:33'),(444,1,'admin','&nbsp;','my_assign_tasks',2,'',0,'2021-03-03 06:08:13','2021-03-03 06:08:13'),(445,13,'01782599354','http://localhost:8080/pump-operator-application','irrigation_payments',45,'',0,'2021-03-03 06:12:22','2021-03-03 06:12:22'),(446,44,'01924496004','http://localhost:8080/smart-card-application-form','irrigation_payments',46,'',0,'2021-03-03 00:14:12','2021-03-03 00:14:12'),(447,44,'01924496004','http://localhost:8080/smart-card-application-form','far_smart_card_apps',7,'',0,'2021-03-03 00:14:12','2021-03-03 00:14:12'),(448,44,'01924496004','http://localhost:8080/smart-card-application-form','irrigation_payments',47,'',0,'2021-03-03 00:14:22','2021-03-03 00:14:22'),(449,44,'01924496004','http://localhost:8080/smart-card-application-form','far_smart_card_apps',8,'',0,'2021-03-03 00:14:22','2021-03-03 00:14:22'),(450,44,'01924496004','http://localhost:8080/smart-card-application/edit/8','far_smart_card_apps',8,'',1,'2021-03-03 00:15:04','2021-03-03 00:15:04'),(451,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list#','master_circle_areas',2,'',1,'2021-03-03 06:18:42','2021-03-03 06:18:42'),(452,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-out','pump_stock_out_infos',3,'',0,'2021-03-03 06:19:29','2021-03-03 06:19:29'),(453,44,'01924496004','http://localhost:8080/pump-opt-application','far_pump_opt_apps',3,'',0,'2021-03-03 00:20:15','2021-03-03 00:20:15'),(454,44,'01924496004','http://localhost:8080/pump-opt-application/3','far_pump_opt_apps',3,'',1,'2021-03-03 00:20:26','2021-03-03 00:20:26'),(455,44,'01924496004','http://localhost:8080/pump-opt-application/3','far_pump_opt_apps',3,'',1,'2021-03-03 00:23:57','2021-03-03 00:23:57'),(456,44,'01924496004','http://localhost:8080/pump-opt-application/3','far_pump_opt_apps',3,'',1,'2021-03-03 00:24:09','2021-03-03 00:24:09'),(457,44,'01924496004','http://localhost:8080/pump-opt-application','far_pump_opt_apps',4,'',0,'2021-03-03 00:25:13','2021-03-03 00:25:13'),(458,44,'01924496004','http://localhost:8080/pump-operator-application','irrigation_payments',48,'',0,'2021-03-03 00:25:40','2021-03-03 00:25:40'),(459,44,'01924496004','http://localhost:8080/scheme-application-submit','far_scheme_application',9,'',0,'2021-03-03 00:27:33','2021-03-03 00:27:33'),(460,44,'01924496004','http://localhost:8080/scheme-application-submit/9','far_scheme_application',9,'',1,'2021-03-03 00:28:01','2021-03-03 00:28:01'),(461,44,'01924496004','http://localhost:8080/scheme-application-submit/9','far_scheme_application',9,'',1,'2021-03-03 00:30:17','2021-03-03 00:30:17'),(462,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-out','pump_stock_out_infos',4,'',0,'2021-03-03 06:31:50','2021-03-03 06:31:50'),(463,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-out','pump_stock_out_infos',5,'',0,'2021-03-03 06:36:50','2021-03-03 06:36:50'),(464,9,'01533894967','http://localhost:8080/farmer-complain','far_complains',4,'',0,'2021-03-03 06:42:51','2021-03-03 06:42:51'),(465,40,'01791894967','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',4,'',1,'2021-03-03 06:44:11','2021-03-03 06:44:11'),(466,40,'01791894967','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_resunks',1,'',0,'2021-03-03 06:45:31','2021-03-03 06:45:31'),(467,44,'01924496004','http://localhost:8080/scheme-application','scheme_farmers_land_details',23,'',0,'2021-03-03 00:52:46','2021-03-03 00:52:46'),(468,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',3,'',2,'2021-03-03 06:58:27','2021-03-03 06:58:27'),(469,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',3,'',2,'2021-03-03 06:58:30','2021-03-03 06:58:30'),(470,8,'01671404511','&nbsp;','my_assign_tasks',3,'',0,'2021-03-03 07:11:53','2021-03-03 07:11:53'),(471,8,'01671404511','&nbsp;','my_assign_tasks',4,'',0,'2021-03-03 07:13:10','2021-03-03 07:13:10'),(472,8,'01671404511','&nbsp;','my_assign_tasks',2,'',1,'2021-03-03 07:14:37','2021-03-03 07:14:37'),(473,14,'01843867772','http://103.199.168.69/water-testing-request-list','far_pump_opt_rejects',20,'',0,'2021-03-03 01:16:16','2021-03-03 01:16:16'),(474,14,'01843867772','http://103.199.168.69/water-testing-request-list','irrigation_payments',49,'',0,'2021-03-03 01:16:16','2021-03-03 01:16:16'),(475,44,'01924496004','http://localhost:8080/scheme-application-submit/9','far_scheme_application',9,'',1,'2021-03-03 01:23:12','2021-03-03 01:23:12'),(476,44,'01924496004','http://localhost:8080/scheme-application-submit/9','far_scheme_application',9,'',1,'2021-03-03 01:24:26','2021-03-03 01:24:26'),(477,44,'01924496004','http://localhost:8080/scheme-application','scheme_farmers_land_details',24,'',0,'2021-03-03 01:24:59','2021-03-03 01:24:59'),(478,44,'01924496004','http://localhost:8080/scheme-application-submit/9','far_scheme_application',9,'',1,'2021-03-03 01:26:56','2021-03-03 01:26:56'),(479,44,'01924496004','http://localhost:8080/scheme-application','scheme_farmers_land_details',25,'',0,'2021-03-03 01:27:23','2021-03-03 01:27:23'),(480,44,'01924496004','http://localhost:8080/scheme-application-submit/9','far_scheme_application',9,'',1,'2021-03-03 01:27:35','2021-03-03 01:27:35'),(481,44,'01924496004','http://localhost:8080/scheme-application-submit/9','far_scheme_application',9,'',1,'2021-03-03 01:27:47','2021-03-03 01:27:47'),(482,44,'01924496004','http://localhost:8080/scheme-application-submit/9','far_scheme_application',9,'',1,'2021-03-03 01:28:54','2021-03-03 01:28:54'),(483,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',3,'',1,'2021-03-03 07:47:41','2021-03-03 07:47:41'),(484,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',20,'',0,'2021-03-03 07:47:41','2021-03-03 07:47:41'),(485,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',34,'',0,'2021-03-03 07:47:41','2021-03-03 07:47:41'),(486,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',3,'',1,'2021-03-03 07:48:05','2021-03-03 07:48:05'),(487,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',5,'',0,'2021-03-03 07:48:05','2021-03-03 07:48:05'),(488,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',3,'',2,'2021-03-03 07:48:14','2021-03-03 07:48:14'),(489,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',3,'',2,'2021-03-03 08:05:28','2021-03-03 08:05:28'),(490,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',7,'',0,'2021-03-03 08:07:09','2021-03-03 08:07:09'),(491,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',7,'',1,'2021-03-03 08:07:13','2021-03-03 08:07:13'),(492,12,'01843867772','http://localhost:8080/assign-task','my_assign_tasks',1,'',0,'2021-03-03 08:09:34','2021-03-03 08:09:34'),(493,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',5,'',0,'2021-03-03 08:11:28','2021-03-03 08:11:28'),(494,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',3,'',1,'2021-03-03 08:11:42','2021-03-03 08:11:42'),(495,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',6,'',0,'2021-03-03 08:11:42','2021-03-03 08:11:42'),(496,12,'01843867772','http://localhost:8080/assign-task','my_assign_tasks',1,'',0,'2021-03-03 08:13:50','2021-03-03 08:13:50'),(497,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',4,'',0,'2021-03-03 08:15:56','2021-03-03 08:15:56'),(498,44,'01924496004','http://localhost:8080/smart-card-application/edit/8','far_smart_card_apps',8,'',1,'2021-03-03 02:16:34','2021-03-03 02:16:34'),(499,44,'01924496004','http://localhost:8080/smart-card-application/edit/8','far_smart_card_apps',8,'',1,'2021-03-03 02:16:46','2021-03-03 02:16:46'),(500,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_application',3,'',1,'2021-03-03 08:17:27','2021-03-03 08:17:27'),(501,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',4,'',1,'2021-03-03 08:17:27','2021-03-03 08:17:27'),(502,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',26,'',0,'2021-03-03 08:33:49','2021-03-03 08:33:49'),(503,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',27,'',0,'2021-03-03 08:34:47','2021-03-03 08:34:47'),(504,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_application',3,'',1,'2021-03-03 08:37:23','2021-03-03 08:37:23'),(505,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_supply_equipments',2,'',0,'2021-03-03 08:37:23','2021-03-03 08:37:23'),(506,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',28,'',0,'2021-03-03 08:40:21','2021-03-03 08:40:21'),(507,44,'01924496004','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',21,'',0,'2021-03-03 02:48:48','2021-03-03 02:48:48'),(508,44,'01924496004','http://localhost:8080/water-testing-request-list','irrigation_payments',50,'',0,'2021-03-03 02:48:48','2021-03-03 02:48:48'),(509,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',4,'',0,'2021-03-03 08:55:42','2021-03-03 08:55:42'),(510,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',29,'',0,'2021-03-03 09:01:44','2021-03-03 09:01:44'),(511,12,'01843867772','http://localhost:8080/scheme-application','scheme_farmers_land_details',30,'',0,'2021-03-03 09:02:05','2021-03-03 09:02:05'),(512,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',4,'',2,'2021-03-03 09:09:45','2021-03-03 09:09:45'),(513,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',4,'',2,'2021-03-03 09:09:47','2021-03-03 09:09:47'),(514,19,'01730233032','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',22,'',0,'2021-03-03 09:13:08','2021-03-03 09:13:08'),(515,19,'01730233032','http://localhost:8080/water-testing-request-list','irrigation_payments',51,'',0,'2021-03-03 09:13:08','2021-03-03 09:13:08'),(516,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',16,'',0,'2021-03-03 09:14:39','2021-03-03 09:14:39'),(517,1,'admin','http://localhost:8080/irrigation/task/task-calendar','task_task_reports',2,'',0,'2021-03-03 09:15:10','2021-03-03 09:15:10'),(518,44,'01924496004','http://localhost:8080/scheme-application-submit','far_scheme_application',21,'',0,'2021-03-03 03:20:56','2021-03-03 03:20:56'),(519,1,'admin','http://localhost:8080/irrigation/task/task-tracker','task_review_notes',2,'',0,'2021-03-03 09:25:23','2021-03-03 09:25:23'),(520,44,'01924496004','http://localhost:8080/scheme-application','scheme_farmers_land_details',31,'',0,'2021-03-03 03:26:15','2021-03-03 03:26:15'),(521,44,'01924496004','http://localhost:8080/smart-card-application/edit/8#','far_smart_card_apps',8,'',1,'2021-03-03 03:32:27','2021-03-03 03:32:27'),(522,40,'01791894967','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',15,'',0,'2021-03-03 09:34:13','2021-03-03 09:34:13'),(523,1,'admin','http://localhost:8080/irrigation/task/task-tracker','task_review_notes',3,'',0,'2021-03-03 09:34:23','2021-03-03 09:34:23'),(524,44,'01924496004','http://localhost:8080/scheme-application-submit/21','far_scheme_application',21,'',1,'2021-03-03 03:35:25','2021-03-03 03:35:25'),(525,44,'01924496004','http://localhost:8080/scheme-application','scheme_farmers_land_details',32,'',0,'2021-03-03 03:35:45','2021-03-03 03:35:45'),(526,44,'01924496004','http://localhost:8080/scheme-application','scheme_farmers_land_details',33,'',0,'2021-03-03 03:36:07','2021-03-03 03:36:07'),(527,40,'01791894967','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',15,'',1,'2021-03-03 09:38:11','2021-03-03 09:38:11'),(528,9,'01533894967','http://localhost:8080/farmer-complain','far_complains',5,'',0,'2021-03-03 09:41:25','2021-03-03 09:41:25'),(529,40,'01791894967','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',5,'',1,'2021-03-03 09:41:45','2021-03-03 09:41:45'),(530,19,'01730233032','http://localhost:8080/scheme-application-submit/6','far_scheme_application',6,'',1,'2021-03-03 09:43:12','2021-03-03 09:43:12'),(531,19,'01730233032','http://localhost:8080/scheme-application','irri_scheme_payments',52,'',0,'2021-03-03 09:43:19','2021-03-03 09:43:19'),(532,40,'01791894967','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_resunks',2,'',0,'2021-03-03 09:44:14','2021-03-03 09:44:14'),(533,44,'01924496004','http://localhost:8080/pump-operator-application','irrigation_payments',53,'',0,'2021-03-03 03:47:29','2021-03-03 03:47:29'),(534,44,'01924496004','http://localhost:8080/pump-operator-application','irrigation_payments',54,'',0,'2021-03-03 03:47:39','2021-03-03 03:47:39'),(535,44,'01924496004','http://localhost:8080/pump-operator-application','irrigation_payments',55,'',0,'2021-03-03 03:50:59','2021-03-03 03:50:59'),(536,44,'01924496004','http://localhost:8080/smart-card-application/edit/8','far_smart_card_apps',8,'',1,'2021-03-03 03:52:18','2021-03-03 03:52:18'),(537,44,'01924496004','http://localhost:8080/scheme-application-submit/21','far_scheme_application',21,'',1,'2021-03-03 03:52:35','2021-03-03 03:52:35'),(538,46,'01846673958','http://localhost:8080/my-profile-form','far_basic_infos',9,'',1,'2021-03-03 09:56:38','2021-03-03 09:56:38'),(539,46,'01846673958','http://localhost:8080/scheme-application-submit','far_scheme_application',26,'',0,'2021-03-03 09:57:25','2021-03-03 09:57:25'),(540,47,'01924496004','http://localhost:8080/my-profile-form','far_basic_infos',10,'',1,'2021-03-03 03:57:34','2021-03-03 03:57:34'),(541,47,'01924496004','http://localhost:8080/scheme-application-submit','far_scheme_application',27,'',0,'2021-03-03 03:58:06','2021-03-03 03:58:06'),(542,47,'01924496004','http://localhost:8080/scheme-application-submit/27','far_scheme_application',27,'',1,'2021-03-03 03:58:19','2021-03-03 03:58:19'),(543,1,'admin','http://localhost:8080/irrigation/task/task-tracker','task_assign_tasks',4,'',2,'2021-03-03 09:58:32','2021-03-03 09:58:32'),(544,47,'01924496004','http://localhost:8080/smart-card-application-form','irrigation_payments',56,'',0,'2021-03-03 03:59:56','2021-03-03 03:59:56'),(545,47,'01924496004','http://localhost:8080/smart-card-application-form','far_smart_card_apps',9,'',0,'2021-03-03 03:59:56','2021-03-03 03:59:56'),(546,47,'01924496004','http://localhost:8080/smart-card-application-form','irrigation_payments',57,'',0,'2021-03-03 04:00:02','2021-03-03 04:00:02'),(547,47,'01924496004','http://localhost:8080/smart-card-application-form','far_smart_card_apps',10,'',0,'2021-03-03 04:00:02','2021-03-03 04:00:02'),(548,47,'01924496004','http://localhost:8080/smart-card-application-form','irrigation_payments',58,'',0,'2021-03-03 04:00:07','2021-03-03 04:00:07'),(549,47,'01924496004','http://localhost:8080/smart-card-application-form','far_smart_card_apps',11,'',0,'2021-03-03 04:00:07','2021-03-03 04:00:07'),(550,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',16,'',0,'2021-03-03 10:01:40','2021-03-03 10:01:40'),(551,47,'01924496004','http://localhost:8080/smart-card-application-form','irrigation_payments',59,'',0,'2021-03-03 04:04:19','2021-03-03 04:04:19'),(552,47,'01924496004','http://localhost:8080/smart-card-application-form','far_smart_card_apps',12,'',0,'2021-03-03 04:04:19','2021-03-03 04:04:19'),(553,47,'01924496004','http://localhost:8080/smart-card-application-form','irrigation_payments',60,'',0,'2021-03-03 04:09:31','2021-03-03 04:09:31'),(554,47,'01924496004','http://localhost:8080/smart-card-application-form','far_smart_card_apps',13,'',0,'2021-03-03 04:09:31','2021-03-03 04:09:31'),(555,47,'01924496004','http://localhost:8080/smart-card-application-form','irrigation_payments',61,'',0,'2021-03-03 04:10:47','2021-03-03 04:10:47'),(556,47,'01924496004','http://localhost:8080/smart-card-application-form','far_smart_card_apps',14,'',0,'2021-03-03 04:10:47','2021-03-03 04:10:47'),(557,47,'01924496004','http://localhost:8080/smart-card-application-form','irrigation_payments',62,'',0,'2021-03-03 04:12:05','2021-03-03 04:12:05'),(558,47,'01924496004','http://localhost:8080/smart-card-application-form','far_smart_card_apps',15,'',0,'2021-03-03 04:12:05','2021-03-03 04:12:05'),(559,47,'01924496004','http://localhost:8080/rating','far_ratings',1,'',0,'2021-03-03 04:15:46','2021-03-03 04:15:46'),(560,47,'01924496004','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',23,'',0,'2021-03-03 04:27:18','2021-03-03 04:27:18'),(561,47,'01924496004','http://localhost:8080/water-testing-request-list','irrigation_payments',63,'',0,'2021-03-03 04:27:18','2021-03-03 04:27:18'),(562,47,'01924496004','http://localhost:8080/smart-card-application-form','irrigation_payments',64,'',0,'2021-03-03 04:29:47','2021-03-03 04:29:47'),(563,47,'01924496004','http://localhost:8080/smart-card-application-form','far_smart_card_apps',16,'',0,'2021-03-03 04:29:47','2021-03-03 04:29:47'),(564,47,'01924496004','http://localhost:8080/water-testing-request-list','pump_operators',21,'',1,'2021-03-03 04:31:01','2021-03-03 04:31:01'),(565,47,'01924496004','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',24,'',0,'2021-03-03 04:31:12','2021-03-03 04:31:12'),(566,47,'01924496004','http://localhost:8080/water-testing-request-list','irrigation_payments',65,'',0,'2021-03-03 04:31:12','2021-03-03 04:31:12'),(567,46,'01846673958','http://localhost:8080/scheme-application-submit/26','far_scheme_application',26,'',1,'2021-03-03 10:32:39','2021-03-03 10:32:39'),(568,46,'01846673958','http://localhost:8080/scheme-application-submit/26','far_scheme_application',26,'',1,'2021-03-03 10:33:45','2021-03-03 10:33:45'),(569,46,'01846673958','http://localhost:8080/scheme-application-submit/26','far_scheme_application',26,'',1,'2021-03-03 10:34:33','2021-03-03 10:34:33'),(570,48,'0188888888','http://localhost:8080/my-profile-form','far_basic_infos',11,'',1,'2021-03-03 10:39:00','2021-03-03 10:39:00'),(571,48,'0188888888','http://localhost:8080/pump-opt-application','far_pump_opt_apps',5,'',0,'2021-03-03 10:40:05','2021-03-03 10:40:05'),(572,40,'01791894967','http://localhost:8080/irrigation/card-payment/new-application','far_smart_card_apps',16,'',2,'2021-03-03 10:46:06','2021-03-03 10:46:06'),(573,48,'0188888888','http://localhost:8080/pump-operator-application','irrigation_payments',66,'',0,'2021-03-03 10:48:12','2021-03-03 10:48:12'),(574,13,'01782599354','http://localhost:8080/farmer-complain','far_complains',6,'',0,'2021-03-03 10:52:22','2021-03-03 10:52:22'),(575,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',5,'',2,'2021-03-03 11:01:22','2021-03-03 11:01:22'),(576,48,'0188888888','http://localhost:8080/pump-operator-application','irrigation_payments',67,'',0,'2021-03-03 11:01:55','2021-03-03 11:01:55'),(577,1,'admin','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',6,'',1,'2021-03-03 11:05:15','2021-03-03 11:05:15'),(578,46,'01846673958','http://localhost:8080/scheme-application-submit/26','far_scheme_application',26,'',1,'2021-03-03 11:05:48','2021-03-03 11:05:48'),(579,46,'01846673958','http://localhost:8080/scheme-application-submit/26','far_scheme_application',26,'',1,'2021-03-03 11:06:57','2021-03-03 11:06:57'),(580,46,'01846673958','http://localhost:8080/scheme-application-submit/26','far_scheme_application',26,'',1,'2021-03-03 11:07:34','2021-03-03 11:07:34'),(581,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',68,'',0,'2021-03-03 11:07:51','2021-03-03 11:07:51'),(582,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance#','far_complain_tro_equipments',3,'',0,'2021-03-03 11:17:45','2021-03-03 11:17:45'),(583,46,'01846673958','http://localhost:8080/scheme-application-submit/26','far_scheme_application',26,'',1,'2021-03-03 11:21:50','2021-03-03 11:21:50'),(584,46,'01846673958','http://localhost:8080/scheme-application-submit/26','far_scheme_application',26,'',1,'2021-03-03 11:22:09','2021-03-03 11:22:09'),(585,46,'01846673958','http://localhost:8080/scheme-application-submit/26','far_scheme_application',26,'',1,'2021-03-03 11:22:56','2021-03-03 11:22:56'),(586,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',6,'',1,'2021-03-03 11:23:59','2021-03-03 11:23:59'),(587,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_progress_reports',2,'',0,'2021-03-03 11:24:24','2021-03-03 11:24:24'),(588,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',1,'',0,'2021-03-03 11:24:45','2021-03-03 11:24:45'),(589,47,'01924496004','http://localhost:8080/scheme-application-submit/27','far_scheme_application',27,'',1,'2021-03-03 05:25:12','2021-03-03 05:25:12'),(590,47,'01924496004','http://localhost:8080/scheme-application-submit/27','far_scheme_application',27,'',1,'2021-03-03 05:25:13','2021-03-03 05:25:13'),(591,47,'01924496004','http://localhost:8080/scheme-application-submit/27','far_scheme_application',27,'',1,'2021-03-03 05:25:28','2021-03-03 05:25:28'),(592,47,'01924496004','http://localhost:8080/scheme-application-submit/27','far_scheme_application',27,'',1,'2021-03-03 05:27:19','2021-03-03 05:27:19'),(593,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task#','far_complain_requisitions',2,'',0,'2021-03-03 11:27:53','2021-03-03 11:27:53'),(594,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task#','far_complains',6,'',1,'2021-03-03 11:28:25','2021-03-03 11:28:25'),(595,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task#','far_complain_requisitions',2,'',1,'2021-03-03 11:28:25','2021-03-03 11:28:25'),(596,1,'admin','http://localhost:8080/irrigation/pump-maintenance/supply-equipment','far_complain_supply_equipments',2,'',0,'2021-03-03 11:29:01','2021-03-03 11:29:01'),(597,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_resolves',1,'',0,'2021-03-03 11:31:58','2021-03-03 11:31:58'),(598,1,'admin','http://localhost:8080/irrigation/pump-maintenance/directory','master_item_sub_categories',1,'',0,'2021-03-03 11:34:58','2021-03-03 11:34:58'),(599,1,'admin','http://localhost:8080/irrigation/pump-maintenance/directory','master_item_sub_categories',2,'',0,'2021-03-03 11:36:26','2021-03-03 11:36:26'),(600,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',69,'',0,'2021-03-03 11:37:28','2021-03-03 11:37:28'),(601,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',26,'',2,'2021-03-03 11:40:18','2021-03-03 11:40:18'),(602,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',26,'',2,'2021-03-03 11:47:53','2021-03-03 11:47:53'),(603,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status/0','far_scheme_license',8,'',0,'2021-03-03 11:48:18','2021-03-03 11:48:18'),(604,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',8,'',1,'2021-03-03 11:48:31','2021-03-03 11:48:31'),(605,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',26,'',1,'2021-03-03 11:49:09','2021-03-03 11:49:09'),(606,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',7,'',0,'2021-03-03 11:49:09','2021-03-03 11:49:09'),(607,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','farmer_land_details',2,'',0,'2021-03-03 11:53:42','2021-03-03 11:53:42'),(608,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','farmer_land_details',3,'',0,'2021-03-03 12:25:22','2021-03-03 12:25:22'),(609,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','farmer_land_details',4,'',0,'2021-03-03 12:29:14','2021-03-03 12:29:14'),(610,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','farmer_land_details',5,'',0,'2021-03-03 12:31:03','2021-03-03 12:31:03'),(611,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',17,'',0,'2021-03-03 12:34:25','2021-03-03 12:34:25'),(612,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',18,'',0,'2021-03-03 12:36:52','2021-03-03 12:36:52'),(613,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',19,'',0,'2021-03-03 12:38:04','2021-03-03 12:38:04'),(614,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','farmer_land_details',6,'',0,'2021-03-03 12:56:33','2021-03-03 12:56:33'),(615,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','farmer_land_details',7,'',0,'2021-03-03 12:57:18','2021-03-03 12:57:18'),(616,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',70,'',0,'2021-03-03 13:05:52','2021-03-03 13:05:52'),(617,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',71,'',0,'2021-03-03 13:06:16','2021-03-03 13:06:16'),(618,9,'01533894967','http://localhost:8080/scheme-application','farmer_land_details',8,'',0,'2021-03-03 13:08:48','2021-03-03 13:08:48'),(619,27,'011111111111','http://localhost:8080/my-profile-form','far_basic_infos',12,'',1,'2021-03-03 22:04:22','2021-03-03 22:04:22'),(620,27,'011111111111','http://localhost:8080/pump-opt-application','far_pump_opt_apps',6,'',0,'2021-03-03 22:04:47','2021-03-03 22:04:47'),(621,27,'011111111111','http://localhost:8080/pump-operator-application','irrigation_payments',72,'',0,'2021-03-03 22:04:57','2021-03-03 22:04:57'),(622,27,'011111111111','http://localhost:8080/pump-operator-application','irrigation_payments',73,'',0,'2021-03-03 22:14:04','2021-03-03 22:14:04'),(623,27,'011111111111','http://localhost:8080/pump-opt-application','far_pump_opt_apps',7,'',0,'2021-03-03 22:14:53','2021-03-03 22:14:53'),(624,27,'011111111111','http://localhost:8080/pump-operator-application','irrigation_payments',74,'',0,'2021-03-03 22:15:00','2021-03-03 22:15:00'),(625,27,'011111111111','http://localhost:8080/pump-operator-application','irrigation_payments',75,'',0,'2021-03-03 22:28:42','2021-03-03 22:28:42'),(626,27,'011111111111','http://localhost:8080/pump-operator-application','irrigation_payments',76,'',0,'2021-03-03 22:31:33','2021-03-03 22:31:33'),(627,27,'011111111111','http://localhost:8080/pump-operator-application','irrigation_payments',77,'',0,'2021-03-03 22:32:33','2021-03-03 22:32:33'),(628,27,'011111111111','http://localhost:8080/smart-card-application-form','irrigation_payments',78,'',0,'2021-03-03 22:33:58','2021-03-03 22:33:58'),(629,27,'011111111111','http://localhost:8080/smart-card-application-form','far_smart_card_apps',17,'',0,'2021-03-03 22:33:58','2021-03-03 22:33:58'),(630,12,'01843867772','http://localhost:8080/scheme-application-submit','far_scheme_application',29,'',0,'2021-03-04 04:39:34','2021-03-04 04:39:34'),(631,12,'01843867772','http://localhost:8080/scheme-application','irrigation_payments',79,'',0,'2021-03-04 04:40:55','2021-03-04 04:40:55'),(632,19,'01730233032','http://localhost:8080/scheme-application','irri_scheme_payments',80,'',0,'2021-03-04 04:48:43','2021-03-04 04:48:43'),(633,12,'01843867772','http://localhost:8080/assign-task','my_assign_tasks',2,'',0,'2021-03-04 04:52:11','2021-03-04 04:52:11'),(634,1,'admin','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complain_resolves',2,'',0,'2021-03-03 22:52:42','2021-03-03 22:52:42'),(635,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',81,'',0,'2021-03-04 05:02:53','2021-03-04 05:02:53'),(636,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',82,'',0,'2021-03-04 05:02:59','2021-03-04 05:02:59'),(637,46,'01846673958','http://localhost:8080/pump-opt-application','far_pump_opt_apps',8,'',0,'2021-03-04 05:04:45','2021-03-04 05:04:45'),(638,1,'admin','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',1,'',1,'2021-03-03 23:06:25','2021-03-03 23:06:25'),(639,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',20,'',0,'2021-03-04 05:12:35','2021-03-04 05:12:35'),(640,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complain_tro_equipments',4,'',0,'2021-03-03 23:18:35','2021-03-03 23:18:35'),(641,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',1,'',1,'2021-03-03 23:18:51','2021-03-03 23:18:51'),(642,46,'01846673958','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',25,'',0,'2021-03-04 05:19:24','2021-03-04 05:19:24'),(643,46,'01846673958','http://localhost:8080/water-testing-request-list','irrigation_payments',83,'',0,'2021-03-04 05:19:24','2021-03-04 05:19:24'),(644,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',1,'',1,'2021-03-03 23:19:28','2021-03-03 23:19:28'),(645,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',1,'',1,'2021-03-03 23:21:22','2021-03-03 23:21:22'),(646,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',2,'',0,'2021-03-04 05:28:34','2021-03-04 05:28:34'),(647,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',1,'',0,'2021-03-04 05:30:35','2021-03-04 05:30:35'),(648,17,'01730233032','http://103.199.168.69/my-profile-form','far_basic_infos',13,'',1,'2021-03-03 23:34:49','2021-03-03 23:34:49'),(649,17,'01730233032','http://103.199.168.69/water-testing-request-list','far_pump_opt_rejects',26,'',0,'2021-03-03 23:35:56','2021-03-03 23:35:56'),(650,17,'01730233032','http://103.199.168.69/water-testing-request-list','irrigation_payments',84,'',0,'2021-03-03 23:35:56','2021-03-03 23:35:56'),(651,17,'01730233032','http://103.199.168.69/water-testing-request-list','far_pump_opt_rejects',27,'',0,'2021-03-03 23:36:00','2021-03-03 23:36:00'),(652,17,'01730233032','http://103.199.168.69/water-testing-request-list','irrigation_payments',85,'',0,'2021-03-03 23:36:00','2021-03-03 23:36:00'),(653,13,'01782599354','http://localhost:8080/scheme-application-submit','far_scheme_application',30,'',0,'2021-03-04 05:37:14','2021-03-04 05:37:14'),(654,13,'01782599354','http://localhost:8080/scheme-application','irrigation_payments',86,'',0,'2021-03-04 05:37:27','2021-03-04 05:37:27'),(655,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',30,'',1,'2021-03-04 05:37:57','2021-03-04 05:37:57'),(656,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',6,'',0,'2021-03-04 05:37:58','2021-03-04 05:37:58'),(657,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',30,'',1,'2021-03-04 05:38:26','2021-03-04 05:38:26'),(658,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',21,'',0,'2021-03-04 05:38:26','2021-03-04 05:38:26'),(659,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',35,'',0,'2021-03-04 05:38:26','2021-03-04 05:38:26'),(660,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',30,'',2,'2021-03-04 05:38:38','2021-03-04 05:38:38'),(661,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',30,'',2,'2021-03-04 05:38:58','2021-03-04 05:38:58'),(662,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',30,'',2,'2021-03-04 05:43:20','2021-03-04 05:43:20'),(663,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',30,'',2,'2021-03-04 05:45:17','2021-03-04 05:45:17'),(664,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status/1','far_scheme_license',9,'',0,'2021-03-04 05:46:11','2021-03-04 05:46:11'),(665,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status/1','far_scheme_license',9,'',1,'2021-03-04 05:46:25','2021-03-04 05:46:25'),(666,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',6,'',0,'2021-03-04 05:47:45','2021-03-04 05:47:45'),(667,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',30,'',1,'2021-03-04 05:48:19','2021-03-04 05:48:19'),(668,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',8,'',0,'2021-03-04 05:48:19','2021-03-04 05:48:19'),(669,13,'01782599354','http://localhost:8080/scheme-application','irrigation_payments',87,'',0,'2021-03-04 05:49:31','2021-03-04 05:49:31'),(670,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',5,'',0,'2021-03-04 05:51:14','2021-03-04 05:51:14'),(671,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_application',30,'',1,'2021-03-04 06:00:45','2021-03-04 06:00:45'),(672,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',5,'',1,'2021-03-04 06:00:45','2021-03-04 06:00:45'),(673,46,'01846673958','http://localhost:8080/pump-opt-renew/8#','far_pump_opt_apps',8,'',1,'2021-03-04 06:03:06','2021-03-04 06:03:06'),(674,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',1,'',0,'2021-03-04 06:07:09','2021-03-04 06:07:09'),(675,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_application',30,'',1,'2021-03-04 06:10:07','2021-03-04 06:10:07'),(676,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_supply_equipments',3,'',0,'2021-03-04 06:10:07','2021-03-04 06:10:07'),(677,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',1,'',0,'2021-03-04 06:11:15','2021-03-04 06:11:15'),(678,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',1,'',0,'2021-03-04 06:14:28','2021-03-04 06:14:28'),(679,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list','master_pump_progress_types',2,'',0,'2021-03-04 06:14:51','2021-03-04 06:14:51'),(680,46,'01846673958','http://localhost:8080/pump-opt-renew/8','far_pump_opt_apps',8,'',1,'2021-03-04 06:15:15','2021-03-04 06:15:15'),(681,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/contractor-list','master_contractors',3,'',0,'2021-03-04 06:15:31','2021-03-04 06:15:31'),(682,13,'01782599354','http://localhost:8080/scheme-application-submit','far_scheme_application',31,'',0,'2021-03-04 06:18:31','2021-03-04 06:18:31'),(683,13,'01782599354','http://localhost:8080/scheme-application','irrigation_payments',88,'',0,'2021-03-04 06:18:36','2021-03-04 06:18:36'),(684,46,'01846673958','http://localhost:8080/pump-opt-renew/8','far_pump_opt_apps',8,'',1,'2021-03-04 06:20:36','2021-03-04 06:20:36'),(685,13,'01782599354','http://localhost:8080/scheme-application-submit','far_scheme_application',32,'',0,'2021-03-04 06:21:03','2021-03-04 06:21:03'),(686,46,'01846673958','http://localhost:8080/pump-opt-renew/8','far_pump_opt_apps',8,'',1,'2021-03-04 06:21:17','2021-03-04 06:21:17'),(687,13,'01782599354','http://localhost:8080/scheme-application','irrigation_payments',89,'',0,'2021-03-04 06:22:46','2021-03-04 06:22:46'),(688,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',32,'',1,'2021-03-04 06:23:22','2021-03-04 06:23:22'),(689,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',7,'',0,'2021-03-04 06:23:22','2021-03-04 06:23:22'),(690,46,'01846673958','http://localhost:8080/pump-opt-renew/8','far_pump_opt_apps',8,'',1,'2021-03-04 06:27:07','2021-03-04 06:27:07'),(691,46,'01846673958','http://localhost:8080/pump-opt-renew/8','far_pump_opt_apps',8,'',1,'2021-03-04 06:27:54','2021-03-04 06:27:54'),(692,46,'01846673958','http://localhost:8080/pump-opt-renew/8','far_pump_opt_apps',8,'',1,'2021-03-04 06:28:37','2021-03-04 06:28:37'),(693,46,'01846673958','http://localhost:8080/pump-opt-renew/8','far_pump_opt_apps',8,'',1,'2021-03-04 06:29:13','2021-03-04 06:29:13'),(694,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',1,'',0,'2021-03-04 06:30:14','2021-03-04 06:30:14'),(695,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',32,'',1,'2021-03-04 06:30:35','2021-03-04 06:30:35'),(696,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',22,'',0,'2021-03-04 06:30:35','2021-03-04 06:30:35'),(697,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',36,'',0,'2021-03-04 06:30:35','2021-03-04 06:30:35'),(698,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',32,'',2,'2021-03-04 06:30:40','2021-03-04 06:30:40'),(699,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',32,'',2,'2021-03-04 06:31:04','2021-03-04 06:31:04'),(700,46,'01846673958','http://localhost:8080/pump-opt-renew/8','far_pump_opt_apps',8,'',1,'2021-03-04 06:32:04','2021-03-04 06:32:04'),(701,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',10,'',0,'2021-03-04 06:33:29','2021-03-04 06:33:29'),(702,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',10,'',1,'2021-03-04 06:33:34','2021-03-04 06:33:34'),(703,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',7,'',0,'2021-03-04 06:34:16','2021-03-04 06:34:16'),(704,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',32,'',1,'2021-03-04 06:34:24','2021-03-04 06:34:24'),(705,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',9,'',0,'2021-03-04 06:34:24','2021-03-04 06:34:24'),(706,52,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',14,'',1,'2021-03-04 06:34:47','2021-03-04 06:34:47'),(707,52,'01730233032','http://localhost:8080/scheme-application-submit','far_scheme_application',33,'',0,'2021-03-04 06:35:45','2021-03-04 06:35:45'),(708,46,'01846673958','http://localhost:8080/pump-opt-renew/8','far_pump_opt_app_reniews',1,'',0,'2021-03-04 06:36:14','2021-03-04 06:36:14'),(709,46,'01846673958','http://localhost:8080/pump-opt-renew/8','far_pump_opt_apps',9,'',0,'2021-03-04 06:36:14','2021-03-04 06:36:14'),(710,13,'01782599354','http://localhost:8080/scheme-application','irrigation_payments',90,'',0,'2021-03-04 06:36:34','2021-03-04 06:36:34'),(711,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',16,'',0,'2021-03-04 06:37:23','2021-03-04 06:37:23'),(712,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',6,'',0,'2021-03-04 06:37:32','2021-03-04 06:37:32'),(713,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_application',32,'',1,'2021-03-04 06:37:52','2021-03-04 06:37:52'),(714,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',6,'',1,'2021-03-04 06:37:52','2021-03-04 06:37:52'),(715,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',17,'',0,'2021-03-04 06:38:08','2021-03-04 06:38:08'),(716,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',18,'',0,'2021-03-04 06:38:24','2021-03-04 06:38:24'),(717,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_application',32,'',1,'2021-03-04 06:42:33','2021-03-04 06:42:33'),(718,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_supply_equipments',4,'',0,'2021-03-04 06:42:33','2021-03-04 06:42:33'),(719,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',5,'',2,'2021-03-04 06:44:22','2021-03-04 06:44:22'),(720,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',5,'',2,'2021-03-04 06:45:16','2021-03-04 06:45:16'),(721,54,'12345678','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',20,'',0,'2021-03-04 00:46:57','2021-03-04 00:46:57'),(722,54,'12345678','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',22,'',0,'2021-03-04 00:47:24','2021-03-04 00:47:24'),(723,54,'12345678','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',22,'',1,'2021-03-04 00:47:38','2021-03-04 00:47:38'),(724,54,'12345678','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',22,'',1,'2021-03-04 00:47:51','2021-03-04 00:47:51'),(725,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction#','far_app_payment_refunds_deducts',3,'',0,'2021-03-04 06:48:18','2021-03-04 06:48:18'),(726,54,'12345678','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',22,'',1,'2021-03-04 00:48:24','2021-03-04 00:48:24'),(727,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',5,'',2,'2021-03-04 06:50:03','2021-03-04 06:50:03'),(728,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',2,'',0,'2021-03-04 06:52:07','2021-03-04 06:52:07'),(729,55,'01938790501','http://localhost:8080/my-profile-form','far_basic_infos',15,'',1,'2021-03-04 00:52:50','2021-03-04 00:52:50'),(730,55,'01938790501','http://localhost:8080/farmer-complain','far_complains',7,'',0,'2021-03-04 00:54:37','2021-03-04 00:54:37'),(731,46,'01846673958','http://localhost:8080/pump-opt-renew/9','far_pump_opt_app_reniews',2,'',0,'2021-03-04 07:01:32','2021-03-04 07:01:32'),(732,46,'01846673958','http://localhost:8080/pump-opt-renew/9','far_pump_opt_apps',10,'',0,'2021-03-04 07:01:32','2021-03-04 07:01:32'),(733,19,'01730233031','http://localhost:8080/scheme-application-submit/6','far_scheme_application',6,'',1,'2021-03-04 07:02:23','2021-03-04 07:02:23'),(734,46,'01846673958','http://localhost:8080/pump-opt-renew/8','far_pump_opt_app_reniews',1,'',0,'2021-03-04 07:02:52','2021-03-04 07:02:52'),(735,46,'01846673958','http://localhost:8080/pump-opt-renew/8','far_pump_opt_apps',11,'',0,'2021-03-04 07:02:52','2021-03-04 07:02:52'),(736,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',13,'',1,'2021-03-04 07:03:46','2021-03-04 07:03:46'),(737,46,'01846673958','http://localhost:8080/pump-opt-renew/8','far_pump_opt_app_reniews',1,'',0,'2021-03-04 07:04:35','2021-03-04 07:04:35'),(738,46,'01846673958','http://localhost:8080/pump-opt-renew/8','far_pump_opt_apps',12,'',0,'2021-03-04 07:04:35','2021-03-04 07:04:35'),(739,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',4,'',0,'2021-03-04 07:13:20','2021-03-04 07:13:20'),(740,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-out','pump_stock_out_infos',6,'',0,'2021-03-04 07:13:44','2021-03-04 07:13:44'),(741,19,'01730233031','http://localhost:8080/scheme-application','irri_scheme_payments',91,'',0,'2021-03-04 07:17:10','2021-03-04 07:17:10'),(742,1,'admin','http://localhost:8080/irrigation/card-payment/new-application','far_smart_card_apps',3,'',2,'2021-03-04 07:25:16','2021-03-04 07:25:16'),(743,19,'01730233031','http://localhost:8080/scheme-application','irri_scheme_payments',92,'',0,'2021-03-04 07:28:53','2021-03-04 07:28:53'),(744,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complain_tro_equipments',5,'',0,'2021-03-04 01:40:29','2021-03-04 01:40:29'),(745,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',7,'',1,'2021-03-04 01:40:42','2021-03-04 01:40:42'),(746,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',6,'',1,'2021-03-04 01:42:00','2021-03-04 01:42:00'),(747,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',6,'',1,'2021-03-04 01:42:49','2021-03-04 01:42:49'),(748,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_progress_reports',3,'',0,'2021-03-04 01:44:17','2021-03-04 01:44:17'),(749,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',19,'',0,'2021-03-04 07:58:30','2021-03-04 07:58:30'),(750,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',20,'',0,'2021-03-04 07:59:01','2021-03-04 07:59:01'),(751,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',1,'',1,'2021-03-04 08:17:10','2021-03-04 08:17:10'),(752,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',93,'',0,'2021-03-04 08:19:34','2021-03-04 08:19:34'),(753,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',94,'',0,'2021-03-04 08:40:37','2021-03-04 08:40:37'),(754,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',4,'',0,'2021-03-04 08:40:39','2021-03-04 08:40:39'),(755,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',26,'',2,'2021-03-04 08:41:38','2021-03-04 08:41:38'),(756,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',26,'',2,'2021-03-04 08:42:20','2021-03-04 08:42:20'),(757,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status/0','far_scheme_license',8,'',1,'2021-03-04 08:42:29','2021-03-04 08:42:29'),(758,14,'01767778333','http://localhost:8080/scheme-application-submit','far_scheme_application',34,'',0,'2021-03-04 08:43:30','2021-03-04 08:43:30'),(759,14,'01767778333','http://localhost:8080/scheme-application','irrigation_payments',95,'',0,'2021-03-04 08:43:47','2021-03-04 08:43:47'),(760,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',8,'',0,'2021-03-04 08:44:13','2021-03-04 08:44:13'),(761,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',26,'',1,'2021-03-04 08:50:04','2021-03-04 08:50:04'),(762,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',10,'',0,'2021-03-04 08:50:05','2021-03-04 08:50:05'),(763,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',2,'',1,'2021-03-04 02:53:24','2021-03-04 02:53:24'),(764,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',1,'',1,'2021-03-04 02:54:09','2021-03-04 02:54:09'),(765,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',2,'',1,'2021-03-04 02:54:51','2021-03-04 02:54:51'),(766,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',1,'',1,'2021-03-04 02:55:01','2021-03-04 02:55:01'),(767,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',1,'',1,'2021-03-04 03:02:13','2021-03-04 03:02:13'),(768,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',21,'',0,'2021-03-04 09:02:39','2021-03-04 09:02:39'),(769,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',22,'',0,'2021-03-04 09:03:03','2021-03-04 09:03:03'),(770,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',23,'',0,'2021-03-04 09:03:33','2021-03-04 09:03:33'),(771,27,'011111111111','http://localhost:8080/farmer-complain','far_complains',8,'',0,'2021-03-04 03:04:00','2021-03-04 03:04:00'),(772,1,'admin','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',8,'',1,'2021-03-04 03:04:32','2021-03-04 03:04:32'),(773,1,'admin','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complain_resolves',1,'',0,'2021-03-04 03:04:47','2021-03-04 03:04:47'),(774,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',24,'',0,'2021-03-04 09:05:27','2021-03-04 09:05:27'),(775,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',25,'',0,'2021-03-04 09:05:47','2021-03-04 09:05:47'),(776,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',26,'',0,'2021-03-04 09:06:00','2021-03-04 09:06:00'),(777,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',27,'',0,'2021-03-04 09:06:23','2021-03-04 09:06:23'),(778,27,'011111111111','http://localhost:8080/farmer-complain','far_complains',9,'',0,'2021-03-04 03:06:34','2021-03-04 03:06:34'),(779,27,'011111111111','http://localhost:8080/farmer-complain','far_complains',10,'',0,'2021-03-04 03:08:14','2021-03-04 03:08:14'),(780,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',10,'',1,'2021-03-04 03:09:53','2021-03-04 03:09:53'),(781,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',9,'',1,'2021-03-04 03:11:02','2021-03-04 03:11:02'),(782,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',10,'',1,'2021-03-04 03:11:53','2021-03-04 03:11:53'),(783,12,'01843867772','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',28,'',0,'2021-03-04 09:12:22','2021-03-04 09:12:22'),(784,12,'01843867772','http://localhost:8080/water-testing-request-list','irrigation_payments',96,'',0,'2021-03-04 09:12:22','2021-03-04 09:12:22'),(785,12,'01843867772','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',29,'',0,'2021-03-04 09:12:32','2021-03-04 09:12:32'),(786,12,'01843867772','http://localhost:8080/water-testing-request-list','irrigation_payments',97,'',0,'2021-03-04 09:12:32','2021-03-04 09:12:32'),(787,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',98,'',0,'2021-03-04 09:16:21','2021-03-04 09:16:21'),(788,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_progress_reports',4,'',0,'2021-03-04 03:19:26','2021-03-04 03:19:26'),(789,27,'011111111111','http://localhost:8080/farmer-complain','far_complains',11,'',0,'2021-03-04 03:21:10','2021-03-04 03:21:10'),(790,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',11,'',1,'2021-03-04 03:21:18','2021-03-04 03:21:18'),(791,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',11,'',1,'2021-03-04 03:21:34','2021-03-04 03:21:34'),(792,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',99,'',0,'2021-03-04 09:21:43','2021-03-04 09:21:43'),(793,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',100,'',0,'2021-03-04 09:25:41','2021-03-04 09:25:41'),(794,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',101,'',0,'2021-03-04 09:32:56','2021-03-04 09:32:56'),(795,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',102,'',0,'2021-03-04 09:36:51','2021-03-04 09:36:51'),(796,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',103,'',0,'2021-03-04 09:37:59','2021-03-04 09:37:59'),(797,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_progress_reports',5,'',0,'2021-03-04 03:44:11','2021-03-04 03:44:11'),(798,27,'011111111111','http://localhost:8080/farmer-complain','far_complains',12,'',0,'2021-03-04 03:45:44','2021-03-04 03:45:44'),(799,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',12,'',1,'2021-03-04 03:45:55','2021-03-04 03:45:55'),(800,54,'12345678','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',12,'',1,'2021-03-04 03:46:03','2021-03-04 03:46:03'),(801,1,'admin','http://103.199.168.69/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',26,'',1,'2021-03-04 03:51:13','2021-03-04 03:51:13'),(802,1,'admin','http://103.199.168.69/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',8,'',0,'2021-03-04 03:51:13','2021-03-04 03:51:13'),(803,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',104,'',0,'2021-03-04 10:02:27','2021-03-04 10:02:27'),(804,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',105,'',0,'2021-03-04 10:05:03','2021-03-04 10:05:03'),(805,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',106,'',0,'2021-03-04 10:08:21','2021-03-04 10:08:21'),(806,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',107,'',0,'2021-03-04 10:09:52','2021-03-04 10:09:52'),(807,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',108,'',0,'2021-03-04 10:12:16','2021-03-04 10:12:16'),(808,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',109,'',0,'2021-03-04 10:15:14','2021-03-04 10:15:14'),(809,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',110,'',0,'2021-03-04 10:15:26','2021-03-04 10:15:26'),(810,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',111,'',0,'2021-03-04 10:15:41','2021-03-04 10:15:41'),(811,46,'01846673958','http://localhost:8080/scheme-application','farmer_land_details',9,'',0,'2021-03-04 10:17:13','2021-03-04 10:17:13'),(812,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',112,'',0,'2021-03-04 10:18:48','2021-03-04 10:18:48'),(813,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',113,'',0,'2021-03-04 10:19:38','2021-03-04 10:19:38'),(814,46,'01846673958','http://localhost:8080/scheme-application','irrigation_payments',114,'',0,'2021-03-04 10:19:44','2021-03-04 10:19:44'),(815,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_progress_reports',6,'',0,'2021-03-04 04:34:20','2021-03-04 04:34:20'),(816,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/project-entry-list','master_projects',4,'',0,'2021-03-04 04:34:36','2021-03-04 04:34:36'),(817,52,'01730233032','http://localhost:8080/scheme-application','irrigation_payments',115,'',0,'2021-03-04 10:43:38','2021-03-04 10:43:38'),(818,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',5,'',0,'2021-03-04 10:45:15','2021-03-04 10:45:15'),(819,52,'01730233032','http://localhost:8080/scheme-application','irrigation_payments',116,'',0,'2021-03-04 10:47:33','2021-03-04 10:47:33'),(820,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',33,'',2,'2021-03-04 10:54:11','2021-03-04 10:54:11'),(821,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',33,'',2,'2021-03-04 10:54:29','2021-03-04 10:54:29'),(822,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',33,'',2,'2021-03-04 10:54:34','2021-03-04 10:54:34'),(823,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',11,'',0,'2021-03-04 10:55:07','2021-03-04 10:55:07'),(824,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',11,'',1,'2021-03-04 10:55:12','2021-03-04 10:55:12'),(825,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',9,'',0,'2021-03-04 10:55:45','2021-03-04 10:55:45'),(826,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',33,'',1,'2021-03-04 10:56:03','2021-03-04 10:56:03'),(827,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',11,'',0,'2021-03-04 10:56:03','2021-03-04 10:56:03'),(828,52,'01730233032','http://localhost:8080/scheme-application','irrigation_payments',117,'',0,'2021-03-04 11:06:19','2021-03-04 11:06:19'),(829,44,'01924496005','http://localhost:8080/smart-card-application-form','irrigation_payments',118,'',0,'2021-03-04 05:11:34','2021-03-04 05:11:34'),(830,44,'01924496005','http://localhost:8080/smart-card-application-form','far_smart_card_apps',18,'',0,'2021-03-04 05:11:35','2021-03-04 05:11:35'),(831,44,'01924496005','http://localhost:8080/smart-card-application-form','irrigation_payments',119,'',0,'2021-03-04 05:13:14','2021-03-04 05:13:14'),(832,44,'01924496005','http://localhost:8080/smart-card-application-form','far_smart_card_apps',19,'',0,'2021-03-04 05:13:14','2021-03-04 05:13:14'),(833,62,'01533894967','http://localhost:8080/my-profile-form','far_basic_infos',16,'',1,'2021-03-04 11:21:47','2021-03-04 11:21:47'),(834,62,'01533894967','http://localhost:8080/my-profile-form','far_basic_infos',16,'',1,'2021-03-04 11:21:48','2021-03-04 11:21:48'),(835,44,'01924496005','http://localhost:8080/smart-card-application/edit/19','far_smart_card_apps',19,'',1,'2021-03-04 05:23:37','2021-03-04 05:23:37'),(836,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',2,'',0,'2021-03-04 11:24:41','2021-03-04 11:24:41'),(837,44,'01924496005','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',30,'',0,'2021-03-04 05:27:12','2021-03-04 05:27:12'),(838,44,'01924496005','http://localhost:8080/water-testing-request-list','irrigation_payments',120,'',0,'2021-03-04 05:27:12','2021-03-04 05:27:12'),(839,44,'01924496005','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',31,'',0,'2021-03-04 05:32:01','2021-03-04 05:32:01'),(840,44,'01924496005','http://localhost:8080/water-testing-request-list','irrigation_payments',121,'',0,'2021-03-04 05:32:01','2021-03-04 05:32:01'),(841,44,'01924496005','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',32,'',0,'2021-03-04 05:32:12','2021-03-04 05:32:12'),(842,44,'01924496005','http://localhost:8080/water-testing-request-list','irrigation_payments',122,'',0,'2021-03-04 05:32:12','2021-03-04 05:32:12'),(843,44,'01924496005','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',33,'',0,'2021-03-04 05:32:28','2021-03-04 05:32:28'),(844,44,'01924496005','http://localhost:8080/water-testing-request-list','irrigation_payments',123,'',0,'2021-03-04 05:32:28','2021-03-04 05:32:28'),(845,46,'01846673958','http://localhost:8080/pump-opt-application','far_pump_opt_apps',1,'',0,'2021-03-04 11:32:53','2021-03-04 11:32:53'),(846,46,'01846673958','http://localhost:8080/pump-operator-application','irrigation_payments',124,'',0,'2021-03-04 11:33:04','2021-03-04 11:33:04'),(847,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',7,'',0,'2021-03-04 05:33:49','2021-03-04 05:33:49'),(848,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',2,'',1,'2021-03-04 11:46:52','2021-03-04 11:46:52'),(849,52,'01730233032','http://localhost:8080/pump-opt-application','far_pump_opt_apps',2,'',0,'2021-03-04 11:47:07','2021-03-04 11:47:07'),(850,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',2,'',1,'2021-03-04 11:47:12','2021-03-04 11:47:12'),(851,52,'01730233032','http://localhost:8080/pump-operator-application','irrigation_payments',125,'',0,'2021-03-04 11:47:42','2021-03-04 11:47:42'),(852,44,'01924496005','http://localhost:8080/farmer-complain','far_complains',13,'',0,'2021-03-04 05:49:36','2021-03-04 05:49:36'),(853,60,'sun_nnykhan1','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',13,'',1,'2021-03-04 05:50:11','2021-03-04 05:50:11'),(854,60,'sun_nnykhan1','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',13,'',1,'2021-03-04 05:50:17','2021-03-04 05:50:17'),(855,60,'sun_nnykhan1','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_progress_reports',7,'',0,'2021-03-04 05:50:33','2021-03-04 05:50:33'),(856,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',3,'',0,'2021-03-04 11:51:07','2021-03-04 11:51:07'),(857,52,'01730233032','http://localhost:8080/pump-operator-application','irrigation_payments',126,'',0,'2021-03-04 11:52:35','2021-03-04 11:52:35'),(858,62,'01533894967','http://localhost:8080/scheme-application-submit','far_scheme_application',35,'',0,'2021-03-04 11:53:12','2021-03-04 11:53:12'),(859,62,'01533894967','http://localhost:8080/scheme-application','farmer_land_details',10,'',0,'2021-03-04 11:54:10','2021-03-04 11:54:10'),(860,62,'01533894967','http://localhost:8080/scheme-application','farmer_land_details',11,'',0,'2021-03-04 11:54:37','2021-03-04 11:54:37'),(861,62,'01533894967','http://localhost:8080/scheme-application','farmer_land_details',12,'',0,'2021-03-04 11:55:14','2021-03-04 11:55:14'),(862,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',28,'',0,'2021-03-04 12:02:27','2021-03-04 12:02:27'),(863,52,'01730233032','http://localhost:8080/pump-opt-application','far_pump_opt_apps',3,'',0,'2021-03-04 12:22:47','2021-03-04 12:22:47'),(864,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance#','far_complains',9,'',1,'2021-03-04 12:31:53','2021-03-04 12:31:53'),(865,1,'admin','http://localhost:8080/irrigation/task/task-calendar','task_task_reports',3,'',0,'2021-03-04 12:34:16','2021-03-04 12:34:16'),(866,52,'01730233032','http://localhost:8080/pump-opt-application/3','far_pump_opt_apps',3,'',1,'2021-03-04 13:21:29','2021-03-04 13:21:29'),(867,52,'01730233032','http://localhost:8080/pump-opt-application/3','far_pump_opt_apps',3,'',1,'2021-03-04 13:21:39','2021-03-04 13:21:39'),(868,52,'01730233032','http://localhost:8080/pump-opt-application/3','far_pump_opt_apps',3,'',1,'2021-03-04 13:21:51','2021-03-04 13:21:51'),(869,52,'01730233032','http://localhost:8080/pump-opt-application/3','far_pump_opt_apps',3,'',1,'2021-03-04 13:23:31','2021-03-04 13:23:31'),(870,19,'01730233031','http://localhost:8080/pump-opt-application','far_pump_opt_apps',4,'',0,'2021-03-04 13:24:31','2021-03-04 13:24:31'),(871,19,'01730233031','http://localhost:8080/pump-opt-application/4','far_pump_opt_apps',4,'',1,'2021-03-04 13:24:44','2021-03-04 13:24:44'),(872,19,'01730233031','http://localhost:8080/pump-operator-application','irrigation_payments',127,'',0,'2021-03-04 13:24:50','2021-03-04 13:24:50'),(873,19,'01730233031','http://localhost:8080/pump-operator-application','irrigation_payments',128,'',0,'2021-03-04 13:25:22','2021-03-04 13:25:22'),(874,52,'01730233032','http://localhost:8080/pump-operator-application','irrigation_payments',129,'',0,'2021-03-04 13:28:13','2021-03-04 13:28:13'),(875,52,'01730233032','http://localhost:8080/smart-card-application-form','irrigation_payments',130,'',0,'2021-03-04 13:32:25','2021-03-04 13:32:25'),(876,52,'01730233032','http://localhost:8080/smart-card-application-form','far_smart_card_apps',20,'',0,'2021-03-04 13:32:25','2021-03-04 13:32:25'),(877,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',2,'',1,'2021-03-04 12:08:40','2021-03-04 12:08:40'),(878,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',2,'',1,'2021-03-04 12:59:28','2021-03-04 12:59:28'),(879,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',2,'',1,'2021-03-04 13:05:01','2021-03-04 13:05:01'),(880,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',2,'',1,'2021-03-04 13:09:06','2021-03-04 13:09:06'),(881,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',2,'',1,'2021-03-04 13:10:09','2021-03-04 13:10:09'),(882,13,'01782599354','http://localhost:8080/scheme-application','farmer_land_details',13,'',0,'2021-03-06 04:25:42','2021-03-06 04:25:42'),(883,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-renew-application-list','pump_operators',21,'',0,'2021-03-06 04:34:57','2021-03-06 04:34:57'),(884,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-renew-application-list','far_pump_opt_apps',1,'',2,'2021-03-06 04:34:57','2021-03-06 04:34:57'),(885,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-renew-application-list','pump_operators',22,'',0,'2021-03-06 04:37:14','2021-03-06 04:37:14'),(886,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-renew-application-list','far_pump_opt_apps',1,'',2,'2021-03-06 04:37:14','2021-03-06 04:37:14'),(887,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-renew-application-list','pum_opt_apps_approvals',3,'',0,'2021-03-06 04:39:27','2021-03-06 04:39:27'),(888,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',33,'',1,'2021-03-06 04:47:59','2021-03-06 04:47:59'),(889,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',9,'',0,'2021-03-06 04:47:59','2021-03-06 04:47:59'),(890,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',34,'',0,'2021-03-06 04:54:41','2021-03-06 04:54:41'),(891,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',131,'',0,'2021-03-06 04:54:41','2021-03-06 04:54:41'),(892,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',35,'',0,'2021-03-06 04:55:22','2021-03-06 04:55:22'),(893,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',132,'',0,'2021-03-06 04:55:23','2021-03-06 04:55:23'),(894,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',36,'',0,'2021-03-06 04:56:12','2021-03-06 04:56:12'),(895,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',133,'',0,'2021-03-06 04:56:12','2021-03-06 04:56:12'),(896,27,'011111111111','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',37,'',0,'2021-03-05 22:58:50','2021-03-05 22:58:50'),(897,27,'011111111111','http://localhost:8080/water-testing-request-list','irrigation_payments',134,'',0,'2021-03-05 22:58:50','2021-03-05 22:58:50'),(898,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',38,'',0,'2021-03-06 04:59:49','2021-03-06 04:59:49'),(899,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',135,'',0,'2021-03-06 04:59:49','2021-03-06 04:59:49'),(900,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',39,'',0,'2021-03-06 05:00:53','2021-03-06 05:00:53'),(901,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',136,'',0,'2021-03-06 05:00:53','2021-03-06 05:00:53'),(902,1,'admin','http://103.199.168.69/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',3,'',1,'2021-03-05 23:07:16','2021-03-05 23:07:16'),(903,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',40,'',0,'2021-03-06 05:08:12','2021-03-06 05:08:12'),(904,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',137,'',0,'2021-03-06 05:08:12','2021-03-06 05:08:12'),(905,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',41,'',0,'2021-03-06 05:11:59','2021-03-06 05:11:59'),(906,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',138,'',0,'2021-03-06 05:11:59','2021-03-06 05:11:59'),(907,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',42,'',0,'2021-03-06 05:13:19','2021-03-06 05:13:19'),(908,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',139,'',0,'2021-03-06 05:13:19','2021-03-06 05:13:19'),(909,18,'01884445330','http://103.199.168.69/my-profile-form','far_basic_infos',17,'',1,'2021-03-05 23:14:30','2021-03-05 23:14:30'),(910,18,'01884445330','http://103.199.168.69/scheme-application-submit','far_scheme_application',36,'',0,'2021-03-05 23:17:53','2021-03-05 23:17:53'),(911,18,'01884445330','http://103.199.168.69/scheme-application','irrigation_payments',140,'',0,'2021-03-05 23:22:23','2021-03-05 23:22:23'),(912,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',43,'',0,'2021-03-06 05:23:04','2021-03-06 05:23:04'),(913,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',141,'',0,'2021-03-06 05:23:04','2021-03-06 05:23:04'),(914,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',44,'',0,'2021-03-06 05:27:12','2021-03-06 05:27:12'),(915,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',142,'',0,'2021-03-06 05:27:12','2021-03-06 05:27:12'),(916,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',45,'',0,'2021-03-06 05:29:34','2021-03-06 05:29:34'),(917,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',143,'',0,'2021-03-06 05:29:34','2021-03-06 05:29:34'),(918,13,'01782599354','http://localhost:8080/smart-card-application-form','irrigation_payments',144,'',0,'2021-03-06 05:35:27','2021-03-06 05:35:27'),(919,13,'01782599354','http://localhost:8080/smart-card-application-form','far_smart_card_apps',21,'',0,'2021-03-06 05:35:27','2021-03-06 05:35:27'),(920,1,'admin','http://localhost:8080/irrigation/pump-maintenance/directory','master_item_sub_categories',3,'',0,'2021-03-06 05:40:04','2021-03-06 05:40:04'),(921,1,'admin','http://localhost:8080/irrigation/pump-maintenance/directory','master_item_sub_categories',1,'',1,'2021-03-06 05:45:16','2021-03-06 05:45:16'),(922,28,'01791894967','http://103.199.168.69/my-profile-form','far_basic_infos',18,'',1,'2021-03-05 23:49:22','2021-03-05 23:49:22'),(923,29,'01533894967','http://103.199.168.69/my-profile-form','far_basic_infos',19,'',1,'2021-03-05 23:56:59','2021-03-05 23:56:59'),(924,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',46,'',0,'2021-03-06 06:00:26','2021-03-06 06:00:26'),(925,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',145,'',0,'2021-03-06 06:00:26','2021-03-06 06:00:26'),(926,30,'123456','http://103.199.168.69/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',36,'',1,'2021-03-06 00:11:13','2021-03-06 00:11:13'),(927,30,'123456','http://103.199.168.69/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',10,'',0,'2021-03-06 00:11:13','2021-03-06 00:11:13'),(928,30,'123456','http://103.199.168.69/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',36,'',1,'2021-03-06 00:11:34','2021-03-06 00:11:34'),(929,30,'123456','http://103.199.168.69/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',23,'',0,'2021-03-06 00:11:34','2021-03-06 00:11:34'),(930,30,'123456','http://103.199.168.69/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',37,'',0,'2021-03-06 00:11:34','2021-03-06 00:11:34'),(931,30,'123456','http://103.199.168.69/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',36,'',2,'2021-03-06 00:11:40','2021-03-06 00:11:40'),(932,30,'123456','http://103.199.168.69/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',36,'',2,'2021-03-06 00:12:06','2021-03-06 00:12:06'),(933,30,'123456','http://103.199.168.69/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',36,'',2,'2021-03-06 00:12:12','2021-03-06 00:12:12'),(934,30,'123456','http://103.199.168.69/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',12,'',0,'2021-03-06 00:12:54','2021-03-06 00:12:54'),(935,1,'admin','http://localhost:8080/irrigation/card-payment/new-application','far_smart_card_apps',19,'',2,'2021-03-06 06:12:53','2021-03-06 06:12:53'),(936,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_pump_opt_rejects',47,'',0,'2021-03-06 06:18:50','2021-03-06 06:18:50'),(937,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_water_samples',12,'',0,'2021-03-06 06:18:50','2021-03-06 06:18:50'),(938,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',23,'',0,'2021-03-06 06:28:37','2021-03-06 06:28:37'),(939,30,'123456','http://103.199.168.69/my-profile-form','far_basic_infos',3,'',1,'2021-03-06 00:35:55','2021-03-06 00:35:55'),(940,35,'01791894967','http://103.199.168.69/my-profile-form','far_basic_infos',20,'',1,'2021-03-06 00:43:07','2021-03-06 00:43:07'),(941,35,'01791894967','http://103.199.168.69/my-profile-form','far_basic_infos',20,'',1,'2021-03-06 00:43:53','2021-03-06 00:43:53'),(942,35,'01791894967','http://103.199.168.69/scheme-application-submit','far_scheme_application',37,'',0,'2021-03-06 00:46:39','2021-03-06 00:46:39'),(943,13,'01782599354','http://localhost:8080/smart-card-application-form','irrigation_payments',146,'',0,'2021-03-06 06:52:47','2021-03-06 06:52:47'),(944,13,'01782599354','http://localhost:8080/smart-card-application-form','far_smart_card_apps',22,'',0,'2021-03-06 06:52:47','2021-03-06 06:52:47'),(945,1,'admin','http://localhost:8080/irrigation/pump-maintenance/directory','master_item_sub_categories',1,'',1,'2021-03-06 07:01:55','2021-03-06 07:01:55'),(946,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',1,'',2,'2021-03-06 07:13:54','2021-03-06 07:13:54'),(947,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',1,'',2,'2021-03-06 07:13:56','2021-03-06 07:13:56'),(948,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-type-list','master_pump_types',2,'',0,'2021-03-06 07:15:03','2021-03-06 07:15:03'),(949,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-type-list','master_pump_types',2,'',1,'2021-03-06 07:15:12','2021-03-06 07:15:12'),(950,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list','master_pump_progress_types',3,'',0,'2021-03-06 07:16:15','2021-03-06 07:16:15'),(951,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',24,'',0,'2021-03-06 07:19:44','2021-03-06 07:19:44'),(952,19,'01730233031','http://localhost:8080/my-profile-form','far_basic_infos',21,'',1,'2021-03-06 07:21:09','2021-03-06 07:21:09'),(953,19,'01730233031','http://localhost:8080/my-profile-form','far_basic_infos',7,'',1,'2021-03-06 07:21:17','2021-03-06 07:21:17'),(954,19,'01730233031','http://localhost:8080/my-profile-form','far_basic_infos',7,'',1,'2021-03-06 07:21:26','2021-03-06 07:21:26'),(955,19,'01730233031','http://localhost:8080/my-profile-form','far_basic_infos',7,'',1,'2021-03-06 07:21:35','2021-03-06 07:21:35'),(956,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',25,'',0,'2021-03-06 07:23:50','2021-03-06 07:23:50'),(957,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',14,'',1,'2021-03-06 07:33:44','2021-03-06 07:33:44'),(958,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',14,'',1,'2021-03-06 07:34:12','2021-03-06 07:34:12'),(959,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',17,'',1,'2021-03-06 07:34:34','2021-03-06 07:34:34'),(960,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',17,'',1,'2021-03-06 07:35:02','2021-03-06 07:35:02'),(961,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',19,'',1,'2021-03-06 07:35:34','2021-03-06 07:35:34'),(962,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',22,'',1,'2021-03-06 07:36:05','2021-03-06 07:36:05'),(963,13,'01782599354','http://localhost:8080/farmer-complain','far_complains',14,'',0,'2021-03-06 07:37:15','2021-03-06 07:37:15'),(964,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',20,'',1,'2021-03-06 07:38:18','2021-03-06 07:38:18'),(965,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',21,'',1,'2021-03-06 07:38:42','2021-03-06 07:38:42'),(966,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',18,'',1,'2021-03-06 07:39:11','2021-03-06 07:39:11'),(967,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',18,'',1,'2021-03-06 07:39:40','2021-03-06 07:39:40'),(968,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',1,'',0,'2021-03-06 07:46:48','2021-03-06 07:46:48'),(969,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',2,'',0,'2021-03-06 07:47:19','2021-03-06 07:47:19'),(970,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',3,'',0,'2021-03-06 07:47:45','2021-03-06 07:47:45'),(971,1,'admin','http://localhost:8080/irrigation/pump-maintenance/directory','pump_directories',1,'',2,'2021-03-06 07:50:26','2021-03-06 07:50:26'),(972,1,'admin','http://localhost:8080/irrigation/pump-maintenance/directory','pump_directories',1,'',2,'2021-03-06 07:50:30','2021-03-06 07:50:30'),(973,1,'admin','http://localhost:8080/irrigation/pump-maintenance/directory','pump_directories',1,'',2,'2021-03-06 07:50:34','2021-03-06 07:50:34'),(974,1,'admin','http://localhost:8080/irrigation/pump-maintenance/directory','pump_directories',1,'',2,'2021-03-06 07:50:47','2021-03-06 07:50:47'),(975,1,'admin','http://localhost:8080/irrigation/pump-maintenance/directory','pump_directories',1,'',2,'2021-03-06 07:54:22','2021-03-06 07:54:22'),(976,1,'admin','http://localhost:8080/irrigation/pump-maintenance/directory','pump_directories',1,'',2,'2021-03-06 07:54:25','2021-03-06 07:54:25'),(977,1,'admin','http://localhost:8080/irrigation/pump-maintenance/directory','pump_directories',1,'',2,'2021-03-06 07:54:28','2021-03-06 07:54:28'),(978,1,'admin','http://localhost:8080/irrigation/pump-maintenance/directory','pump_directories',1,'',2,'2021-03-06 07:54:31','2021-03-06 07:54:31'),(979,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',4,'',0,'2021-03-06 08:04:44','2021-03-06 08:04:44'),(980,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',5,'',0,'2021-03-06 08:05:09','2021-03-06 08:05:09'),(981,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',4,'',0,'2021-03-06 08:06:42','2021-03-06 08:06:42'),(982,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',6,'',0,'2021-03-06 08:23:17','2021-03-06 08:23:17'),(983,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',6,'',0,'2021-03-06 08:25:40','2021-03-06 08:25:40'),(984,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',7,'',0,'2021-03-06 08:31:35','2021-03-06 08:31:35'),(985,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',8,'',0,'2021-03-06 08:32:18','2021-03-06 08:32:18'),(986,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-suspension-list','pump_opt_suspensions',8,'',0,'2021-03-06 08:36:33','2021-03-06 08:36:33'),(987,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',23,'',0,'2021-03-06 08:38:24','2021-03-06 08:38:24'),(988,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-suspension-list','pump_opt_suspensions',9,'',0,'2021-03-06 08:38:58','2021-03-06 08:38:58'),(989,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',26,'',0,'2021-03-06 08:40:13','2021-03-06 08:40:13'),(990,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',24,'',0,'2021-03-06 08:41:39','2021-03-06 08:41:39'),(991,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-suspension-list','pump_opt_suspensions',10,'',0,'2021-03-06 08:43:15','2021-03-06 08:43:15'),(992,19,'01730233031','http://localhost:8080/my-profile-form','far_basic_infos',7,'',1,'2021-03-06 08:43:34','2021-03-06 08:43:34'),(993,12,'01843867772','http://localhost:8080/my-task','task_task_reports',4,'',0,'2021-03-06 08:47:29','2021-03-06 08:47:29'),(994,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','farmer_land_details',14,'',0,'2021-03-06 08:51:19','2021-03-06 08:51:19'),(995,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/store-item-list','master_items',2,'',0,'2021-03-06 08:54:47','2021-03-06 08:54:47'),(996,1,'admin','http://localhost:8080/irrigation/pump-information/pump-scheduler-list','pump_schedulers',5,'',0,'2021-03-06 08:59:39','2021-03-06 08:59:39'),(997,19,'01730233031','http://localhost:8080/my-profile-form','far_basic_infos',7,'',1,'2021-03-06 09:04:39','2021-03-06 09:04:39'),(998,19,'01730233031','http://localhost:8080/my-profile-form','far_basic_infos',7,'',1,'2021-03-06 09:05:22','2021-03-06 09:05:22'),(999,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',5,'',0,'2021-03-06 09:09:53','2021-03-06 09:09:53'),(1000,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',6,'',0,'2021-03-06 09:14:01','2021-03-06 09:14:01'),(1001,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',7,'',0,'2021-03-06 09:16:06','2021-03-06 09:16:06'),(1002,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',34,'',1,'2021-03-06 09:20:13','2021-03-06 09:20:13'),(1003,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',11,'',0,'2021-03-06 09:20:13','2021-03-06 09:20:13'),(1004,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',5,'',0,'2021-03-06 09:25:29','2021-03-06 09:25:29'),(1005,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-out','pump_stock_out_infos',7,'',0,'2021-03-06 09:26:54','2021-03-06 09:26:54'),(1006,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',9,'',0,'2021-03-06 09:29:27','2021-03-06 09:29:27'),(1007,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',48,'',0,'2021-03-06 09:29:42','2021-03-06 09:29:42'),(1008,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',147,'',0,'2021-03-06 09:29:42','2021-03-06 09:29:42'),(1009,1,'admin','http://localhost:8080/irrigation/task/task-tracker','task_review_notes',4,'',0,'2021-03-06 09:34:56','2021-03-06 09:34:56'),(1010,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',49,'',0,'2021-03-06 09:42:03','2021-03-06 09:42:03'),(1011,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',148,'',0,'2021-03-06 09:42:03','2021-03-06 09:42:03'),(1012,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',50,'',0,'2021-03-06 09:43:41','2021-03-06 09:43:41'),(1013,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',149,'',0,'2021-03-06 09:43:41','2021-03-06 09:43:41'),(1014,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',8,'',0,'2021-03-06 09:58:17','2021-03-06 09:58:17'),(1015,13,'01782599354','http://localhost:8080/pump-opt-application','far_pump_opt_apps',5,'',0,'2021-03-06 10:07:00','2021-03-06 10:07:00'),(1016,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',10,'',0,'2021-03-06 10:07:34','2021-03-06 10:07:34'),(1017,13,'01782599354','http://localhost:8080/pump-operator-application','irrigation_payments',150,'',0,'2021-03-06 10:07:48','2021-03-06 10:07:48'),(1018,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',11,'',0,'2021-03-06 10:09:06','2021-03-06 10:09:06'),(1019,13,'01782599354','http://localhost:8080/pump-operator-application','irrigation_payments',151,'',0,'2021-03-06 10:09:14','2021-03-06 10:09:14'),(1020,13,'01782599354','http://localhost:8080/pump-operator-application','irrigation_payments',152,'',0,'2021-03-06 10:10:03','2021-03-06 10:10:03'),(1021,13,'01782599354','http://localhost:8080/pump-operator-application','irrigation_payments',153,'',0,'2021-03-06 10:23:31','2021-03-06 10:23:31'),(1022,13,'01782599354','http://localhost:8080/pump-operator-application','irrigation_payments',154,'',0,'2021-03-06 10:27:17','2021-03-06 10:27:17'),(1023,35,'01791894967','http://103.199.168.69/irrigation/pump-maintenance/maintenance-task','far_complain_progress_reports',8,'',0,'2021-03-06 04:35:52','2021-03-06 04:35:52'),(1024,13,'01782599354','http://localhost:8080/pump-opt-application','far_pump_opt_apps',6,'',0,'2021-03-06 10:54:58','2021-03-06 10:54:58'),(1025,13,'01782599354','http://localhost:8080/pump-operator-application','irrigation_payments',155,'',0,'2021-03-06 10:55:04','2021-03-06 10:55:04'),(1026,13,'01782599354','http://localhost:8080/pump-operator-application','irrigation_payments',156,'',0,'2021-03-06 10:55:09','2021-03-06 10:55:09'),(1027,13,'01782599354','http://localhost:8080/pump-operator-application','irrigation_payments',157,'',0,'2021-03-06 11:00:35','2021-03-06 11:00:35'),(1028,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_pump_opt_rejects',51,'',0,'2021-03-06 11:09:02','2021-03-06 11:09:02'),(1029,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_water_samples',13,'',0,'2021-03-06 11:09:03','2021-03-06 11:09:03'),(1030,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_water_test_apps',4,'',2,'2021-03-06 11:30:16','2021-03-06 11:30:16'),(1031,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',9,'',0,'2021-03-06 11:58:15','2021-03-06 11:58:15'),(1032,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',52,'',0,'2021-03-06 11:59:19','2021-03-06 11:59:19'),(1033,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',158,'',0,'2021-03-06 11:59:19','2021-03-06 11:59:19'),(1034,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',10,'',0,'2021-03-06 12:02:06','2021-03-06 12:02:06'),(1035,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',34,'',2,'2021-03-06 12:16:14','2021-03-06 12:16:14'),(1036,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',11,'',0,'2021-03-06 12:25:28','2021-03-06 12:25:28'),(1037,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',29,'',1,'2021-03-06 06:27:49','2021-03-06 06:27:49'),(1038,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',12,'',0,'2021-03-06 06:27:49','2021-03-06 06:27:49'),(1039,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',12,'',0,'2021-03-06 12:28:54','2021-03-06 12:28:54'),(1040,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_water_test_apps',14,'',2,'2021-03-06 12:30:27','2021-03-06 12:30:27'),(1041,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_pump_opt_rejects',53,'',0,'2021-03-06 12:31:20','2021-03-06 12:31:20'),(1042,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_water_samples',16,'',0,'2021-03-06 12:31:20','2021-03-06 12:31:20'),(1043,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',13,'',0,'2021-03-06 12:36:38','2021-03-06 12:36:38'),(1044,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',14,'',0,'2021-03-06 12:38:30','2021-03-06 12:38:30'),(1045,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_water_test_apps',15,'',2,'2021-03-06 12:38:36','2021-03-06 12:38:36'),(1046,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',15,'',0,'2021-03-06 13:01:28','2021-03-06 13:01:28'),(1047,14,'01767778333','http://localhost:8080/smart-card-application-form','irrigation_payments',159,'',0,'2021-03-06 13:02:15','2021-03-06 13:02:15'),(1048,14,'01767778333','http://localhost:8080/smart-card-application-form','far_smart_card_apps',23,'',0,'2021-03-06 13:02:15','2021-03-06 13:02:15'),(1049,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',16,'',0,'2021-03-06 13:05:47','2021-03-06 13:05:47'),(1050,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',17,'',0,'2021-03-06 13:06:42','2021-03-06 13:06:42'),(1051,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',18,'',0,'2021-03-06 13:13:38','2021-03-06 13:13:38'),(1052,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',19,'',0,'2021-03-06 13:15:42','2021-03-06 13:15:42'),(1053,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',34,'',2,'2021-03-06 13:16:13','2021-03-06 13:16:13'),(1054,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',13,'',0,'2021-03-06 13:16:46','2021-03-06 13:16:46'),(1055,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',13,'',1,'2021-03-06 13:16:54','2021-03-06 13:16:54'),(1056,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',20,'',0,'2021-03-06 13:17:14','2021-03-06 13:17:14'),(1057,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',10,'',0,'2021-03-06 13:17:33','2021-03-06 13:17:33'),(1058,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',34,'',1,'2021-03-06 13:17:41','2021-03-06 13:17:41'),(1059,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',12,'',0,'2021-03-06 13:17:41','2021-03-06 13:17:41'),(1060,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',34,'',1,'2021-03-06 13:36:13','2021-03-06 13:36:13'),(1061,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',13,'',0,'2021-03-06 13:36:13','2021-03-06 13:36:13'),(1062,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_application',26,'',1,'2021-03-06 13:36:34','2021-03-06 13:36:34'),(1063,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',7,'',1,'2021-03-06 13:36:34','2021-03-06 13:36:34'),(1064,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_application',26,'',1,'2021-03-06 13:41:57','2021-03-06 13:41:57'),(1065,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_supply_equipments',5,'',0,'2021-03-06 13:41:57','2021-03-06 13:41:57'),(1066,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',22,'',0,'2021-03-06 13:58:31','2021-03-06 13:58:31'),(1067,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',23,'',0,'2021-03-07 04:25:24','2021-03-07 04:25:24'),(1068,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',24,'',0,'2021-03-07 04:28:56','2021-03-07 04:28:56'),(1069,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',25,'',0,'2021-03-07 04:31:48','2021-03-07 04:31:48'),(1070,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',26,'',0,'2021-03-07 04:32:00','2021-03-07 04:32:00'),(1071,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',25,'',0,'2021-03-06 23:39:02','2021-03-06 23:39:02'),(1072,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-suspension-list','pump_opt_suspensions',11,'',0,'2021-03-06 23:39:48','2021-03-06 23:39:48'),(1073,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',27,'',0,'2021-03-07 06:05:11','2021-03-07 06:05:11'),(1074,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',28,'',0,'2021-03-07 06:05:33','2021-03-07 06:05:33'),(1075,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',29,'',0,'2021-03-07 06:05:47','2021-03-07 06:05:47'),(1076,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',30,'',0,'2021-03-07 06:07:51','2021-03-07 06:07:51'),(1077,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',31,'',0,'2021-03-07 06:11:16','2021-03-07 06:11:16'),(1078,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',32,'',0,'2021-03-07 06:11:37','2021-03-07 06:11:37'),(1079,14,'01767778333','http://localhost:8080/scheme-application-submit','far_scheme_application',38,'',0,'2021-03-07 06:23:29','2021-03-07 06:23:29'),(1080,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',6,'',0,'2021-03-07 00:36:26','2021-03-07 00:36:26'),(1081,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',6,'',2,'2021-03-07 00:36:40','2021-03-07 00:36:40'),(1082,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',7,'',0,'2021-03-07 00:59:59','2021-03-07 00:59:59'),(1083,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',6,'',2,'2021-03-07 01:00:05','2021-03-07 01:00:05'),(1084,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',3,'',2,'2021-03-07 01:00:07','2021-03-07 01:00:07'),(1085,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',33,'',0,'2021-03-07 07:09:02','2021-03-07 07:09:02'),(1086,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',34,'',0,'2021-03-07 07:14:24','2021-03-07 07:14:24'),(1087,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',35,'',0,'2021-03-07 07:14:47','2021-03-07 07:14:47'),(1088,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',36,'',0,'2021-03-07 07:15:09','2021-03-07 07:15:09'),(1089,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',37,'',0,'2021-03-07 01:45:12','2021-03-07 01:45:12'),(1090,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',38,'',0,'2021-03-07 01:53:05','2021-03-07 01:53:05'),(1091,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-out','pump_stock_out_infos',8,'',0,'2021-03-07 07:55:02','2021-03-07 07:55:02'),(1092,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',33,'',2,'2021-03-07 08:12:49','2021-03-07 08:12:49'),(1093,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',33,'',2,'2021-03-07 08:13:28','2021-03-07 08:13:28'),(1094,14,'01767778333','http://localhost:8080/scheme-application','farmer_land_details',15,'',0,'2021-03-07 08:19:46','2021-03-07 08:19:46'),(1095,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',8,'',0,'2021-03-07 03:02:32','2021-03-07 03:02:32'),(1096,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',9,'',0,'2021-03-07 03:04:02','2021-03-07 03:04:02'),(1097,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',10,'',0,'2021-03-07 03:04:20','2021-03-07 03:04:20'),(1098,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',11,'',0,'2021-03-07 03:22:51','2021-03-07 03:22:51'),(1099,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',12,'',0,'2021-03-07 03:28:26','2021-03-07 03:28:26'),(1100,14,'01767778333','http://localhost:8080/scheme-application','irrigation_payments',160,'',0,'2021-03-07 09:47:09','2021-03-07 09:47:09'),(1101,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',38,'',1,'2021-03-07 09:47:32','2021-03-07 09:47:32'),(1102,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',24,'',0,'2021-03-07 09:47:32','2021-03-07 09:47:32'),(1103,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',38,'',0,'2021-03-07 09:47:32','2021-03-07 09:47:32'),(1104,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',38,'',1,'2021-03-07 09:47:37','2021-03-07 09:47:37'),(1105,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',13,'',0,'2021-03-07 09:47:37','2021-03-07 09:47:37'),(1106,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',38,'',2,'2021-03-07 09:47:40','2021-03-07 09:47:40'),(1107,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',38,'',2,'2021-03-07 09:47:49','2021-03-07 09:47:49'),(1108,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',14,'',0,'2021-03-07 09:48:24','2021-03-07 09:48:24'),(1109,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',14,'',1,'2021-03-07 09:48:28','2021-03-07 09:48:28'),(1110,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',11,'',0,'2021-03-07 09:48:43','2021-03-07 09:48:43'),(1111,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',38,'',1,'2021-03-07 09:48:52','2021-03-07 09:48:52'),(1112,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',14,'',0,'2021-03-07 09:48:52','2021-03-07 09:48:52'),(1113,14,'01767778333','http://localhost:8080/scheme-application','irrigation_payments',161,'',0,'2021-03-07 09:57:57','2021-03-07 09:57:57'),(1114,14,'01767778333','http://localhost:8080/scheme-application','irrigation_payments',162,'',0,'2021-03-07 09:58:01','2021-03-07 09:58:01'),(1115,14,'01767778333','http://localhost:8080/scheme-application','irrigation_payments',163,'',0,'2021-03-07 10:05:39','2021-03-07 10:05:39'),(1116,14,'01767778333','http://localhost:8080/scheme-application','irrigation_payments',164,'',0,'2021-03-07 10:05:46','2021-03-07 10:05:46'),(1117,14,'01767778333','http://localhost:8080/scheme-application-submit','far_scheme_application',39,'',0,'2021-03-07 10:11:05','2021-03-07 10:11:05'),(1118,14,'01767778333','http://localhost:8080/scheme-application','irrigation_payments',165,'',0,'2021-03-07 10:14:54','2021-03-07 10:14:54'),(1119,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',39,'',1,'2021-03-07 10:15:47','2021-03-07 10:15:47'),(1120,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',25,'',0,'2021-03-07 10:15:47','2021-03-07 10:15:47'),(1121,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',39,'',0,'2021-03-07 10:15:47','2021-03-07 10:15:47'),(1122,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',39,'',1,'2021-03-07 10:15:56','2021-03-07 10:15:56'),(1123,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',14,'',0,'2021-03-07 10:15:56','2021-03-07 10:15:56'),(1124,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',39,'',2,'2021-03-07 10:15:59','2021-03-07 10:15:59'),(1125,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',39,'',2,'2021-03-07 10:16:05','2021-03-07 10:16:05'),(1126,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',15,'',0,'2021-03-07 10:16:23','2021-03-07 10:16:23'),(1127,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',15,'',1,'2021-03-07 10:16:27','2021-03-07 10:16:27'),(1128,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',12,'',0,'2021-03-07 10:16:40','2021-03-07 10:16:40'),(1129,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',39,'',1,'2021-03-07 10:16:45','2021-03-07 10:16:45'),(1130,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',15,'',0,'2021-03-07 10:16:45','2021-03-07 10:16:45'),(1131,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pump_operators',26,'',0,'2021-03-07 10:17:14','2021-03-07 10:17:14'),(1132,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',3,'',2,'2021-03-07 10:17:15','2021-03-07 10:17:15'),(1133,103,'01733322211','http://localhost:8080/my-profile-form','far_basic_infos',22,'',1,'2021-03-07 10:53:41','2021-03-07 10:53:41'),(1134,103,'01733322211','http://localhost:8080/my-profile-form','far_basic_infos',22,'',1,'2021-03-07 10:53:50','2021-03-07 10:53:50'),(1135,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',39,'',0,'2021-03-07 10:57:02','2021-03-07 10:57:02'),(1136,13,'01782599354','http://localhost:8080/scheme-application','farmer_land_details',16,'',0,'2021-03-08 05:14:53','2021-03-08 05:14:53'),(1137,13,'01782599354','http://localhost:8080/scheme-application','farmer_land_details',17,'',0,'2021-03-08 05:16:55','2021-03-08 05:16:55'),(1138,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',12,'',0,'2021-03-07 23:23:00','2021-03-07 23:23:00'),(1139,14,'01767778333','http://localhost:8080/scheme-application','farmer_land_details',18,'',0,'2021-03-08 05:36:02','2021-03-08 05:36:02'),(1140,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',13,'',0,'2021-03-08 05:53:31','2021-03-08 05:53:31'),(1141,13,'01782599354','http://localhost:8080/smart-card-application-form','irrigation_payments',166,'',0,'2021-03-08 05:54:24','2021-03-08 05:54:24'),(1142,13,'01782599354','http://localhost:8080/smart-card-application-form','far_smart_card_apps',24,'',0,'2021-03-08 05:54:24','2021-03-08 05:54:24'),(1143,1,'admin','http://localhost:8080/irrigation/card-payment/new-application','far_smart_card_apps',20,'',2,'2021-03-08 05:55:43','2021-03-08 05:55:43'),(1144,1,'admin','http://localhost:8080/irrigation/card-payment/new-application','far_smart_card_apps',24,'',2,'2021-03-08 05:56:46','2021-03-08 05:56:46'),(1145,1,'admin','http://localhost:8080/irrigation/card-payment/new-application','far_smart_card_apps',24,'',2,'2021-03-08 05:57:02','2021-03-08 05:57:02'),(1146,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',24,'',2,'2021-03-08 05:57:25','2021-03-08 05:57:25'),(1147,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',14,'',0,'2021-03-08 00:03:45','2021-03-08 00:03:45'),(1148,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',15,'',0,'2021-03-08 00:04:02','2021-03-08 00:04:02'),(1149,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',16,'',0,'2021-03-08 00:45:32','2021-03-08 00:45:32'),(1150,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',17,'',0,'2021-03-08 00:45:48','2021-03-08 00:45:48'),(1151,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',18,'',0,'2021-03-08 00:46:17','2021-03-08 00:46:17'),(1152,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',19,'',0,'2021-03-08 00:52:31','2021-03-08 00:52:31'),(1153,14,'01767778333','http://localhost:8080/scheme-application','farmer_land_details',19,'',0,'2021-03-08 07:22:14','2021-03-08 07:22:14'),(1154,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_pump_opt_apps',29,'',2,'2021-03-08 07:28:59','2021-03-08 07:28:59'),(1155,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_pump_opt_apps',21,'',2,'2021-03-08 07:29:01','2021-03-08 07:29:01'),(1156,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',54,'',0,'2021-03-08 07:39:11','2021-03-08 07:39:11'),(1157,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',167,'',0,'2021-03-08 07:39:11','2021-03-08 07:39:11'),(1158,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',55,'',0,'2021-03-08 09:31:13','2021-03-08 09:31:13'),(1159,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',168,'',0,'2021-03-08 09:31:13','2021-03-08 09:31:13'),(1160,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_pump_opt_rejects',56,'',0,'2021-03-08 09:58:35','2021-03-08 09:58:35'),(1161,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_water_samples',18,'',0,'2021-03-08 09:58:36','2021-03-08 09:58:36'),(1162,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list','master_pump_progress_types',4,'',0,'2021-03-08 11:17:38','2021-03-08 11:17:38'),(1163,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',8,'',0,'2021-03-08 13:06:19','2021-03-08 13:06:19'),(1164,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_application',39,'',1,'2021-03-08 13:06:30','2021-03-08 13:06:30'),(1165,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',8,'',1,'2021-03-08 13:06:30','2021-03-08 13:06:30'),(1166,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_application',39,'',1,'2021-03-08 13:06:48','2021-03-08 13:06:48'),(1167,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_supply_equipments',6,'',0,'2021-03-08 13:06:48','2021-03-08 13:06:48'),(1168,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/store-item-list','master_items',3,'',0,'2021-03-09 04:50:23','2021-03-09 04:50:23'),(1169,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',4,'',0,'2021-03-09 04:53:35','2021-03-09 04:53:35'),(1170,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',4,'',2,'2021-03-09 04:54:43','2021-03-09 04:54:43'),(1171,13,'01782599354','http://localhost:8080/scheme-application-submit','far_scheme_application',40,'',0,'2021-03-09 05:04:07','2021-03-09 05:04:07'),(1172,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',57,'',0,'2021-03-09 05:08:59','2021-03-09 05:08:59'),(1173,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',169,'',0,'2021-03-09 05:08:59','2021-03-09 05:08:59'),(1174,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',7,'',0,'2021-03-09 05:20:19','2021-03-09 05:20:19'),(1175,13,'01782599354','http://localhost:8080/farmer-complain','far_complains',15,'',0,'2021-03-09 06:10:42','2021-03-09 06:10:42'),(1176,13,'01782599354','http://localhost:8080/farmer-complain','far_complains',16,'',0,'2021-03-09 06:12:08','2021-03-09 06:12:08'),(1177,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',20,'',0,'2021-03-09 00:51:13','2021-03-09 00:51:13'),(1178,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',21,'',0,'2021-03-09 00:51:25','2021-03-09 00:51:25'),(1179,14,'01767778333','http://localhost:8080/assign-task','my_assign_tasks',3,'',0,'2021-03-09 06:55:08','2021-03-09 06:55:08'),(1180,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',40,'',0,'2021-03-09 00:56:51','2021-03-09 00:56:51'),(1181,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',41,'',0,'2021-03-09 00:57:07','2021-03-09 00:57:07'),(1182,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',42,'',0,'2021-03-09 00:57:19','2021-03-09 00:57:19'),(1183,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',8,'',0,'2021-03-09 01:00:23','2021-03-09 01:00:23'),(1184,27,'011111111111','http://localhost:8080/pump-opt-application','far_pump_opt_apps',7,'',0,'2021-03-09 01:30:27','2021-03-09 01:30:27'),(1185,27,'011111111111','http://localhost:8080/pump-opt-application/7','far_pump_opt_apps',7,'',1,'2021-03-09 01:32:03','2021-03-09 01:32:03'),(1186,27,'011111111111','http://localhost:8080/pump-opt-application/7','far_pump_opt_apps',7,'',1,'2021-03-09 01:32:57','2021-03-09 01:32:57'),(1187,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pump_opt_apps_surveys',1,'',0,'2021-03-09 08:15:58','2021-03-09 08:15:58'),(1188,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',1,'',2,'2021-03-09 10:53:21','2021-03-09 10:53:21'),(1189,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',2,'',2,'2021-03-09 10:53:29','2021-03-09 10:53:29'),(1190,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',2,'',2,'2021-03-09 10:54:37','2021-03-09 10:54:37'),(1191,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',3,'',2,'2021-03-09 10:55:11','2021-03-09 10:55:11'),(1192,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',1,'',2,'2021-03-09 11:12:14','2021-03-09 11:12:14'),(1193,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',1,'',2,'2021-03-09 11:12:17','2021-03-09 11:12:17'),(1194,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',2,'',2,'2021-03-09 11:12:20','2021-03-09 11:12:20'),(1195,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',3,'',2,'2021-03-09 11:12:23','2021-03-09 11:12:23'),(1196,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',27,'',0,'2021-03-09 11:15:07','2021-03-09 11:15:07'),(1197,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',11,'',1,'2021-03-10 04:12:43','2021-03-10 04:12:43'),(1198,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',9,'',0,'2021-03-10 04:17:08','2021-03-10 04:17:08'),(1199,1,'admin','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',16,'',1,'2021-03-10 05:02:45','2021-03-10 05:02:45'),(1200,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complain_tro_equipments',6,'',0,'2021-03-10 05:03:20','2021-03-10 05:03:20'),(1201,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',16,'',1,'2021-03-10 05:03:41','2021-03-10 05:03:41'),(1202,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_requisitions',3,'',0,'2021-03-10 05:04:20','2021-03-10 05:04:20'),(1203,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_progress_reports',9,'',0,'2021-03-10 05:04:41','2021-03-10 05:04:41'),(1204,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complains',16,'',1,'2021-03-10 05:06:01','2021-03-10 05:06:01'),(1205,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_requisitions',3,'',1,'2021-03-10 05:06:01','2021-03-10 05:06:01'),(1206,1,'admin','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',15,'',1,'2021-03-10 05:06:21','2021-03-10 05:06:21'),(1207,1,'admin','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',14,'',1,'2021-03-10 05:06:24','2021-03-10 05:06:24'),(1208,1,'admin','http://localhost:8080/irrigation/pump-maintenance/supply-equipment','far_complain_supply_equipments',3,'',0,'2021-03-10 05:06:52','2021-03-10 05:06:52'),(1209,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',5,'',0,'2021-03-10 05:16:10','2021-03-10 05:16:10'),(1210,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',6,'',0,'2021-03-10 05:32:40','2021-03-10 05:32:40'),(1211,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',7,'',0,'2021-03-10 05:33:02','2021-03-10 05:33:02'),(1212,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',8,'',0,'2021-03-10 05:33:21','2021-03-10 05:33:21'),(1213,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',9,'',0,'2021-03-10 05:34:38','2021-03-10 05:34:38'),(1214,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',10,'',0,'2021-03-10 05:35:37','2021-03-10 05:35:37'),(1215,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',11,'',0,'2021-03-10 05:36:13','2021-03-10 05:36:13'),(1216,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',15,'',1,'2021-03-10 05:47:59','2021-03-10 05:47:59'),(1217,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/contractor-list','master_contractors',6,'',0,'2021-03-10 06:06:57','2021-03-10 06:06:57'),(1218,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/contractor-list','master_contractors',7,'',0,'2021-03-10 06:07:35','2021-03-10 06:07:35'),(1219,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/contractor-list','master_contractors',8,'',0,'2021-03-10 06:08:21','2021-03-10 06:08:21'),(1220,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/contractor-list','master_contractors',8,'',2,'2021-03-10 06:11:58','2021-03-10 06:11:58'),(1221,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/contractor-list','master_contractors',8,'',2,'2021-03-10 06:12:02','2021-03-10 06:12:02'),(1222,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-type-list','master_scheme_types',2,'',2,'2021-03-10 06:12:39','2021-03-10 06:12:39'),(1223,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-type-list','master_scheme_types',2,'',2,'2021-03-10 06:12:41','2021-03-10 06:12:41'),(1224,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',5,'',0,'2021-03-10 06:23:31','2021-03-10 06:23:31'),(1225,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',6,'',0,'2021-03-10 06:23:49','2021-03-10 06:23:49'),(1226,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',4,'',0,'2021-03-10 06:40:05','2021-03-10 06:40:05'),(1227,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',5,'',0,'2021-03-10 06:43:25','2021-03-10 06:43:25'),(1228,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',6,'',0,'2021-03-10 06:45:36','2021-03-10 06:45:36'),(1229,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/store-item-list','master_items',2,'',1,'2021-03-10 06:50:24','2021-03-10 06:50:24'),(1230,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/item-category-list','master_item_categories',4,'',0,'2021-03-10 07:17:09','2021-03-10 07:17:09'),(1231,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/item-category-list','master_item_categories',5,'',0,'2021-03-10 07:17:34','2021-03-10 07:17:34'),(1232,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/measurement-unit-list','master_measurement_units',2,'',0,'2021-03-10 07:18:22','2021-03-10 07:18:22'),(1233,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/measurement-unit-list','master_measurement_units',3,'',0,'2021-03-10 07:18:38','2021-03-10 07:18:38'),(1234,186,'01792938497','http://localhost:8080/my-profile-form','far_basic_infos',43,'',1,'2021-03-10 07:24:14','2021-03-10 07:24:14'),(1235,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',13,'',0,'2021-03-10 07:24:45','2021-03-10 07:24:45'),(1236,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/store-item-list','master_items',4,'',0,'2021-03-10 07:35:07','2021-03-10 07:35:07'),(1237,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/store-item-list','master_items',5,'',0,'2021-03-10 07:36:07','2021-03-10 07:36:07'),(1238,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-type-list','master_pump_types',3,'',0,'2021-03-10 07:36:36','2021-03-10 07:36:36'),(1239,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-type-list','master_pump_types',4,'',0,'2021-03-10 07:36:51','2021-03-10 07:36:51'),(1240,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list','master_pump_progress_types',5,'',0,'2021-03-10 07:40:48','2021-03-10 07:40:48'),(1241,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list','master_pump_progress_types',6,'',0,'2021-03-10 07:41:31','2021-03-10 07:41:31'),(1242,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list','master_pump_progress_types',7,'',0,'2021-03-10 07:42:47','2021-03-10 07:42:47'),(1243,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',7,'',0,'2021-03-10 07:44:16','2021-03-10 07:44:16'),(1244,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',8,'',0,'2021-03-10 07:45:54','2021-03-10 07:45:54'),(1245,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',9,'',0,'2021-03-10 07:48:38','2021-03-10 07:48:38'),(1246,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',10,'',0,'2021-03-10 07:48:46','2021-03-10 07:48:46'),(1247,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list','master_pump_progress_types',8,'',0,'2021-03-10 07:49:04','2021-03-10 07:49:04'),(1248,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list','master_laboratories',18,'',0,'2021-03-10 07:50:05','2021-03-10 07:50:05'),(1249,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list','master_laboratories',19,'',0,'2021-03-10 07:51:05','2021-03-10 07:51:05'),(1250,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',6,'',0,'2021-03-10 07:52:24','2021-03-10 07:52:24'),(1251,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/equipment-type-list','master_equipment_types',3,'',0,'2021-03-10 07:53:13','2021-03-10 07:53:13'),(1252,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/equipment-type-list','master_equipment_types',4,'',0,'2021-03-10 07:53:34','2021-03-10 07:53:34'),(1253,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/equipment-type-list','master_equipment_types',5,'',0,'2021-03-10 07:53:56','2021-03-10 07:53:56'),(1254,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',22,'',0,'2021-03-10 07:56:06','2021-03-10 07:56:06'),(1255,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',23,'',0,'2021-03-10 07:58:25','2021-03-10 07:58:25'),(1256,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',11,'',0,'2021-03-10 08:00:14','2021-03-10 08:00:14'),(1257,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',12,'',0,'2021-03-10 08:00:25','2021-03-10 08:00:25'),(1258,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',13,'',0,'2021-03-10 08:02:34','2021-03-10 08:02:34'),(1259,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',14,'',0,'2021-03-10 08:02:46','2021-03-10 08:02:46'),(1260,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-10 08:05:27','2021-03-10 08:05:27'),(1261,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-10 08:05:30','2021-03-10 08:05:30'),(1262,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',43,'',0,'2021-03-10 08:06:54','2021-03-10 08:06:54'),(1263,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_apps',8,'',0,'2021-03-10 08:11:22','2021-03-10 08:11:22'),(1264,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',15,'',0,'2021-03-10 08:14:28','2021-03-10 08:14:28'),(1265,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',16,'',0,'2021-03-10 08:14:36','2021-03-10 08:14:36'),(1266,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_apps',9,'',0,'2021-03-10 08:22:42','2021-03-10 08:22:42'),(1267,14,'01767778333','http://localhost:8080/pump-operator-application','irrigation_payments',170,'',0,'2021-03-10 08:23:02','2021-03-10 08:23:02'),(1268,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-10 08:40:43','2021-03-10 08:40:43'),(1269,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-10 08:40:50','2021-03-10 08:40:50'),(1270,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-10 08:41:00','2021-03-10 08:41:00'),(1271,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',4,'',2,'2021-03-10 08:41:03','2021-03-10 08:41:03'),(1272,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-10 08:41:17','2021-03-10 08:41:17'),(1273,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-10 08:41:18','2021-03-10 08:41:18'),(1274,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-10 08:41:23','2021-03-10 08:41:23'),(1275,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-10 08:41:27','2021-03-10 08:41:27'),(1276,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-10 08:41:30','2021-03-10 08:41:30'),(1277,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',2,'',2,'2021-03-10 08:41:34','2021-03-10 08:41:34'),(1278,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',2,'',2,'2021-03-10 08:41:37','2021-03-10 08:41:37'),(1279,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-10 08:41:42','2021-03-10 08:41:42'),(1280,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-10 08:41:46','2021-03-10 08:41:46'),(1281,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',4,'',2,'2021-03-10 08:41:48','2021-03-10 08:41:48'),(1282,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pump_operators',51,'',0,'2021-03-10 08:44:03','2021-03-10 08:44:03'),(1283,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',9,'',2,'2021-03-10 08:44:03','2021-03-10 08:44:03'),(1284,14,'01767778333','http://localhost:8080/pump-opt-renew/9','far_pump_opt_docs',15,'',2,'2021-03-10 08:49:17','2021-03-10 08:49:17'),(1285,12,'01843867772','http://localhost:8080/my-profile-form','far_basic_infos',4,'',1,'2021-03-10 08:50:26','2021-03-10 08:50:26'),(1286,12,'01843867772','http://localhost:8080/smart-card-application-form','irrigation_payments',171,'',0,'2021-03-10 11:01:11','2021-03-10 11:01:11'),(1287,12,'01843867772','http://localhost:8080/smart-card-application-form','far_smart_card_apps',26,'',0,'2021-03-10 11:01:11','2021-03-10 11:01:11'),(1288,19,'01730233031','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',58,'',0,'2021-03-10 11:44:18','2021-03-10 11:44:18'),(1289,19,'01730233031','http://localhost:8080/water-testing-request-list','irrigation_payments',172,'',0,'2021-03-10 11:44:18','2021-03-10 11:44:18'),(1290,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',4,'',0,'2021-03-10 11:46:10','2021-03-10 11:46:10'),(1291,12,'01843867772','http://localhost:8080/smart-card-application/edit/26','far_smart_card_apps',26,'',1,'2021-03-10 12:27:30','2021-03-10 12:27:30'),(1299,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_scheme_application',9,'',1,'2021-03-11 06:14:33','2021-03-11 06:14:33'),(1300,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_rejects',2,'',0,'2021-03-11 06:14:33','2021-03-11 06:14:33'),(1301,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pump_operators',52,'',0,'2021-03-11 06:18:26','2021-03-11 06:18:26'),(1302,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',9,'',2,'2021-03-11 06:18:27','2021-03-11 06:18:27'),(1303,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',5,'',0,'2021-03-11 06:22:33','2021-03-11 06:22:33'),(1304,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',6,'',0,'2021-03-11 06:23:42','2021-03-11 06:23:42'),(1305,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',7,'',0,'2021-03-11 06:26:14','2021-03-11 06:26:14'),(1306,19,'01730233031','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',59,'',0,'2021-03-11 06:35:54','2021-03-11 06:35:54'),(1307,19,'01730233031','http://localhost:8080/water-testing-request-list','irrigation_payments',173,'',0,'2021-03-11 06:35:55','2021-03-11 06:35:55'),(1310,19,'01730233031','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',62,'',0,'2021-03-11 07:25:53','2021-03-11 07:25:53'),(1311,19,'01730233031','http://localhost:8080/water-testing-request-list','irrigation_payments',174,'',0,'2021-03-11 07:25:53','2021-03-11 07:25:53'),(1312,19,'01730233031','http://localhost:8080/water-testing-request-list','pump_operators',62,'',1,'2021-03-11 07:26:04','2021-03-11 07:26:04'),(1313,19,'01730233031','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',63,'',0,'2021-03-11 07:28:31','2021-03-11 07:28:31'),(1314,19,'01730233031','http://localhost:8080/water-testing-request-list','irrigation_payments',175,'',0,'2021-03-11 07:28:31','2021-03-11 07:28:31'),(1315,19,'01730233031','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',64,'',0,'2021-03-11 07:29:50','2021-03-11 07:29:50'),(1316,19,'01730233031','http://localhost:8080/water-testing-request-list','irrigation_payments',176,'',0,'2021-03-11 07:29:51','2021-03-11 07:29:51'),(1317,19,'01730233031','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',65,'',0,'2021-03-11 07:30:22','2021-03-11 07:30:22'),(1318,19,'01730233031','http://localhost:8080/water-testing-request-list','irrigation_payments',177,'',0,'2021-03-11 07:30:22','2021-03-11 07:30:22'),(1319,19,'01730233031','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',66,'',0,'2021-03-11 07:31:45','2021-03-11 07:31:45'),(1320,19,'01730233031','http://localhost:8080/water-testing-request-list','irrigation_payments',178,'',0,'2021-03-11 07:31:46','2021-03-11 07:31:46'),(1321,19,'01730233031','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',67,'',0,'2021-03-11 07:33:59','2021-03-11 07:33:59'),(1322,19,'01730233031','http://localhost:8080/water-testing-request-list','irrigation_payments',179,'',0,'2021-03-11 07:33:59','2021-03-11 07:33:59'),(1323,19,'01730233031','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',68,'',0,'2021-03-11 07:34:12','2021-03-11 07:34:12'),(1324,19,'01730233031','http://localhost:8080/water-testing-request-list','irrigation_payments',180,'',0,'2021-03-11 07:34:12','2021-03-11 07:34:12'),(1325,19,'01730233031','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',69,'',0,'2021-03-11 07:35:03','2021-03-11 07:35:03'),(1326,19,'01730233031','http://localhost:8080/water-testing-request-list','irrigation_payments',181,'',0,'2021-03-11 07:35:04','2021-03-11 07:35:04'),(1327,19,'01730233031','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',70,'',0,'2021-03-11 07:35:58','2021-03-11 07:35:58'),(1328,19,'01730233031','http://localhost:8080/water-testing-request-list','irrigation_payments',182,'',0,'2021-03-11 07:35:58','2021-03-11 07:35:58'),(1329,19,'01730233031','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',71,'',0,'2021-03-11 07:41:59','2021-03-11 07:41:59'),(1330,19,'01730233031','http://localhost:8080/water-testing-request-list','irrigation_payments',183,'',0,'2021-03-11 07:41:59','2021-03-11 07:41:59'),(1331,12,'01843867772','http://localhost:8080/assign-task','my_assign_tasks',4,'',0,'2021-03-11 07:49:05','2021-03-11 07:49:05'),(1332,12,'01843867772','http://localhost:8080/assign-task','my_assign_tasks',5,'',0,'2021-03-11 07:50:17','2021-03-11 07:50:17'),(1333,12,'01843867772','http://localhost:8080/assign-task','my_assign_tasks',6,'',0,'2021-03-11 07:50:47','2021-03-11 07:50:47'),(1334,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-11 08:39:42','2021-03-11 08:39:42'),(1335,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-11 08:39:49','2021-03-11 08:39:49'),(1336,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','far_pump_opt_apps',9,'',2,'2021-03-11 08:46:42','2021-03-11 08:46:42'),(1337,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','pump_opt_apps_surveys',1,'',0,'2021-03-11 08:50:03','2021-03-11 08:50:03'),(1338,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','pum_opt_apps_approvals',8,'',0,'2021-03-11 09:00:08','2021-03-11 09:00:08'),(1339,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-app-survey','pump_opt_apps_surveys',1,'',0,'2021-03-11 09:22:42','2021-03-11 09:22:42'),(1340,13,'01782599354','http://localhost:8080/pump-opt-application','far_pump_opt_docs',17,'',0,'2021-03-11 10:21:30','2021-03-11 10:21:30'),(1341,13,'01782599354','http://localhost:8080/pump-opt-application','far_pump_opt_apps',10,'',0,'2021-03-11 10:21:51','2021-03-11 10:21:51'),(1342,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',153,'',0,'2021-03-11 10:23:02','2021-03-11 10:23:02'),(1343,13,'01782599354','http://localhost:8080/pump-operator-application','irrigation_payments',184,'',0,'2021-03-11 04:23:17','2021-03-11 04:23:17'),(1344,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pump_opt_apps_surveys',2,'',0,'2021-03-11 10:24:07','2021-03-11 10:24:07'),(1345,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pump_operators',53,'',0,'2021-03-11 10:24:24','2021-03-11 10:24:24'),(1346,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',10,'',2,'2021-03-11 10:24:24','2021-03-11 10:24:24'),(1347,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',9,'',0,'2021-03-11 10:25:44','2021-03-11 10:25:44'),(1348,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',5,'',2,'2021-03-11 11:46:36','2021-03-11 11:46:36'),(1349,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log-entry-form/5','pump_drilling_log',5,'',1,'2021-03-11 11:48:41','2021-03-11 11:48:41'),(1350,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log-entry-form/5','pump_drilling_log',5,'',1,'2021-03-11 11:50:16','2021-03-11 11:50:16'),(1351,27,'011111111111','http://localhost:8080/pump-opt-application','far_pump_opt_apps',11,'',0,'2021-03-11 05:51:24','2021-03-11 05:51:24'),(1352,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',3,'',2,'2021-03-11 11:51:26','2021-03-11 11:51:26'),(1353,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',3,'',2,'2021-03-11 11:51:51','2021-03-11 11:51:51'),(1354,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',3,'',2,'2021-03-11 11:51:55','2021-03-11 11:51:55'),(1355,27,'011111111111','http://localhost:8080/pump-opt-application/11','far_pump_opt_apps',11,'',1,'2021-03-11 05:51:55','2021-03-11 05:51:55'),(1356,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details-entry-form/3','pump_construction_details',3,'',1,'2021-03-11 11:57:41','2021-03-11 11:57:41'),(1357,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',4,'',2,'2021-03-14 05:32:41','2021-03-14 05:32:41'),(1358,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-14 05:32:47','2021-03-14 05:32:47'),(1359,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',2,'',2,'2021-03-14 05:32:58','2021-03-14 05:32:58'),(1360,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',2,'',2,'2021-03-14 05:33:17','2021-03-14 05:33:17'),(1361,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-14 05:33:25','2021-03-14 05:33:25'),(1362,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',4,'',2,'2021-03-14 05:33:40','2021-03-14 05:33:40'),(1363,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',4,'',2,'2021-03-14 05:44:55','2021-03-14 05:44:55'),(1364,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-14 05:45:52','2021-03-14 05:45:52'),(1365,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-14 05:46:02','2021-03-14 05:46:02'),(1366,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-14 05:46:09','2021-03-14 05:46:09'),(1367,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',4,'',2,'2021-03-14 05:46:46','2021-03-14 05:46:46'),(1368,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-14 05:46:51','2021-03-14 05:46:51'),(1369,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-14 05:46:57','2021-03-14 05:46:57'),(1370,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-14 05:48:08','2021-03-14 05:48:08'),(1371,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-14 05:52:22','2021-03-14 05:52:22'),(1372,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',5,'',2,'2021-03-14 05:52:26','2021-03-14 05:52:26'),(1373,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',2,'',2,'2021-03-14 05:52:50','2021-03-14 05:52:50'),(1374,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',9,'',0,'2021-03-14 05:58:56','2021-03-14 05:58:56'),(1375,1,'admin','http://localhost:8080/irrigation/task/task-calendar','task_task_reports',5,'',0,'2021-03-14 05:59:51','2021-03-14 05:59:51'),(1376,1,'admin','http://localhost:8080/irrigation/task/task-tracker','task_assign_tasks',9,'',2,'2021-03-14 06:01:36','2021-03-14 06:01:36'),(1377,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details#','pump_construction_details',2,'',2,'2021-03-14 06:02:06','2021-03-14 06:02:06'),(1378,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',10,'',0,'2021-03-14 06:32:38','2021-03-14 06:32:38'),(1379,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','far_pump_opt_apps',3,'',2,'2021-03-14 06:47:30','2021-03-14 06:47:30'),(1380,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','pum_opt_apps_approvals',11,'',0,'2021-03-14 06:48:59','2021-03-14 06:48:59'),(1381,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pump_operators',54,'',0,'2021-03-14 08:02:26','2021-03-14 08:02:26'),(1382,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',10,'',2,'2021-03-14 08:02:26','2021-03-14 08:02:26'),(1383,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',12,'',0,'2021-03-14 08:40:08','2021-03-14 08:40:08'),(1384,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-app-survey','far_pump_opt_apps',9,'',2,'2021-03-14 08:44:10','2021-03-14 08:44:10'),(1385,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-app-survey','pump_opt_apps_surveys',1,'',0,'2021-03-14 08:45:32','2021-03-14 08:45:32'),(1386,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list#','master_scheme_types',1,'',2,'2021-03-14 10:29:33','2021-03-14 10:29:33'),(1387,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list#','master_scheme_types',2,'',0,'2021-03-14 11:04:02','2021-03-14 11:04:02'),(1388,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list#','master_scheme_types',1,'',1,'2021-03-14 11:07:59','2021-03-14 11:07:59'),(1389,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list#','master_scheme_types',1,'',1,'2021-03-14 11:08:06','2021-03-14 11:08:06'),(1390,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list#','master_scheme_types',1,'',1,'2021-03-14 11:12:18','2021-03-14 11:12:18'),(1391,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 04:31:30','2021-03-15 04:31:30'),(1392,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 04:31:32','2021-03-15 04:31:32'),(1393,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-15 04:31:38','2021-03-15 04:31:38'),(1394,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',2,'',2,'2021-03-15 04:33:34','2021-03-15 04:33:34'),(1395,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 04:33:38','2021-03-15 04:33:38'),(1396,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 04:33:41','2021-03-15 04:33:41'),(1397,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-15 04:33:45','2021-03-15 04:33:45'),(1398,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 04:38:12','2021-03-15 04:38:12'),(1399,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 04:38:15','2021-03-15 04:38:15'),(1400,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',2,'',2,'2021-03-15 04:38:22','2021-03-15 04:38:22'),(1401,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',5,'',2,'2021-03-15 04:47:16','2021-03-15 04:47:16'),(1402,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 04:53:33','2021-03-15 04:53:33'),(1403,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 04:53:55','2021-03-15 04:53:55'),(1404,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',2,'',2,'2021-03-15 04:54:49','2021-03-15 04:54:49'),(1405,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 04:56:29','2021-03-15 04:56:29'),(1406,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 04:57:28','2021-03-15 04:57:28'),(1407,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 04:58:41','2021-03-15 04:58:41'),(1408,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-15 04:58:55','2021-03-15 04:58:55'),(1409,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',4,'',2,'2021-03-15 04:58:57','2021-03-15 04:58:57'),(1410,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 04:59:00','2021-03-15 04:59:00'),(1411,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 05:07:17','2021-03-15 05:07:17'),(1412,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',2,'',2,'2021-03-15 05:08:23','2021-03-15 05:08:23'),(1413,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',2,'',2,'2021-03-15 05:09:04','2021-03-15 05:09:04'),(1414,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 05:11:23','2021-03-15 05:11:23'),(1415,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-15 05:12:40','2021-03-15 05:12:40'),(1416,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',2,'',2,'2021-03-15 05:13:29','2021-03-15 05:13:29'),(1417,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 05:13:48','2021-03-15 05:13:48'),(1418,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',2,'',2,'2021-03-15 05:14:21','2021-03-15 05:14:21'),(1419,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',5,'',2,'2021-03-15 05:16:05','2021-03-15 05:16:05'),(1420,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',2,'',2,'2021-03-15 05:16:40','2021-03-15 05:16:40'),(1421,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 05:16:44','2021-03-15 05:16:44'),(1422,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',3,'',2,'2021-03-15 05:16:47','2021-03-15 05:16:47'),(1423,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 05:17:00','2021-03-15 05:17:00'),(1424,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',3,'',2,'2021-03-15 05:17:03','2021-03-15 05:17:03'),(1425,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',2,'',2,'2021-03-15 05:17:06','2021-03-15 05:17:06'),(1426,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 05:18:43','2021-03-15 05:18:43'),(1427,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',4,'',2,'2021-03-15 05:18:57','2021-03-15 05:18:57'),(1428,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',14,'',2,'2021-03-15 05:19:42','2021-03-15 05:19:42'),(1429,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',11,'',2,'2021-03-15 05:19:55','2021-03-15 05:19:55'),(1430,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',16,'',2,'2021-03-15 05:20:00','2021-03-15 05:20:00'),(1431,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',19,'',2,'2021-03-15 05:20:04','2021-03-15 05:20:04'),(1432,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-15 05:20:18','2021-03-15 05:20:18'),(1433,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',11,'',2,'2021-03-15 05:22:03','2021-03-15 05:22:03'),(1434,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',16,'',2,'2021-03-15 05:22:08','2021-03-15 05:22:08'),(1435,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',5,'',2,'2021-03-15 05:22:24','2021-03-15 05:22:24'),(1436,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 05:22:43','2021-03-15 05:22:43'),(1437,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 05:22:49','2021-03-15 05:22:49'),(1438,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',3,'',2,'2021-03-15 05:22:53','2021-03-15 05:22:53'),(1439,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',2,'',2,'2021-03-15 05:22:57','2021-03-15 05:22:57'),(1440,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-15 05:23:11','2021-03-15 05:23:11'),(1441,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 05:23:57','2021-03-15 05:23:57'),(1442,13,'01782599354','http://localhost:8080/smart-card-application-form#','irrigation_payments',1,'',0,'2021-03-15 05:25:27','2021-03-15 05:25:27'),(1443,13,'01782599354','http://localhost:8080/smart-card-application-form#','far_smart_card_apps',1,'',0,'2021-03-15 05:25:27','2021-03-15 05:25:27'),(1444,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',2,'',2,'2021-03-15 05:25:53','2021-03-15 05:25:53'),(1445,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',3,'',2,'2021-03-15 05:26:10','2021-03-15 05:26:10'),(1446,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',2,'',2,'2021-03-15 05:26:17','2021-03-15 05:26:17'),(1447,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 05:27:51','2021-03-15 05:27:51'),(1448,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',3,'',2,'2021-03-15 05:28:38','2021-03-15 05:28:38'),(1449,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 05:31:10','2021-03-15 05:31:10'),(1450,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',2,'',2,'2021-03-15 05:32:04','2021-03-15 05:32:04'),(1451,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 05:36:13','2021-03-15 05:36:13'),(1452,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',2,'',2,'2021-03-15 05:36:16','2021-03-15 05:36:16'),(1453,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 05:36:24','2021-03-15 05:36:24'),(1454,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',2,'',2,'2021-03-15 05:36:38','2021-03-15 05:36:38'),(1455,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',2,'',2,'2021-03-15 05:36:45','2021-03-15 05:36:45'),(1456,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',2,'',2,'2021-03-15 05:36:49','2021-03-15 05:36:49'),(1457,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',3,'',2,'2021-03-15 05:36:53','2021-03-15 05:36:53'),(1458,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',3,'',2,'2021-03-15 05:36:56','2021-03-15 05:36:56'),(1459,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',3,'',2,'2021-03-15 05:36:58','2021-03-15 05:36:58'),(1460,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 05:40:07','2021-03-15 05:40:07'),(1461,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',2,'',2,'2021-03-15 05:40:13','2021-03-15 05:40:13'),(1462,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',3,'',2,'2021-03-15 05:40:31','2021-03-15 05:40:31'),(1463,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 05:41:41','2021-03-15 05:41:41'),(1464,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-14 23:45:29','2021-03-14 23:45:29'),(1465,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',2,'',2,'2021-03-15 05:46:33','2021-03-15 05:46:33'),(1466,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-14 23:55:10','2021-03-14 23:55:10'),(1467,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-14 23:55:20','2021-03-14 23:55:20'),(1468,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-14 23:57:33','2021-03-14 23:57:33'),(1469,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-14 23:58:04','2021-03-14 23:58:04'),(1470,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-14 23:58:42','2021-03-14 23:58:42'),(1471,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 00:03:21','2021-03-15 00:03:21'),(1472,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 00:06:46','2021-03-15 00:06:46'),(1473,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 00:06:52','2021-03-15 00:06:52'),(1474,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 00:06:58','2021-03-15 00:06:58'),(1475,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 00:07:04','2021-03-15 00:07:04'),(1476,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 06:16:47','2021-03-15 06:16:47'),(1477,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',2,'',2,'2021-03-15 06:16:51','2021-03-15 06:16:51'),(1478,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 06:16:58','2021-03-15 06:16:58'),(1479,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',3,'',2,'2021-03-15 06:17:03','2021-03-15 06:17:03'),(1480,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 06:19:52','2021-03-15 06:19:52'),(1481,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',1,'',2,'2021-03-15 06:20:43','2021-03-15 06:20:43'),(1482,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log','pump_drilling_log',2,'',2,'2021-03-15 06:20:47','2021-03-15 06:20:47'),(1483,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',1,'',2,'2021-03-15 06:22:40','2021-03-15 06:22:40'),(1484,1,'admin','http://localhost:8080/irrigation/pump-information/construction-details','pump_construction_details',3,'',2,'2021-03-15 06:22:44','2021-03-15 06:22:44'),(1485,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',13,'',2,'2021-03-15 06:26:24','2021-03-15 06:26:24'),(1486,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',13,'',2,'2021-03-15 06:27:02','2021-03-15 06:27:02'),(1487,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list','master_scheme_types',1,'',0,'2021-03-15 06:28:05','2021-03-15 06:28:05'),(1488,1,'admin','http://localhost:8080/irrigation/pump-information/pump-scheduler-list','pump_schedulers',1,'',2,'2021-03-15 06:28:24','2021-03-15 06:28:24'),(1489,1,'admin','http://localhost:8080/irrigation/pump-information/pump-scheduler-list','pump_schedulers',2,'',2,'2021-03-15 06:28:44','2021-03-15 06:28:44'),(1490,1,'admin','http://localhost:8080/irrigation/pump-information/pump-scheduler-list','pump_schedulers',5,'',2,'2021-03-15 06:28:48','2021-03-15 06:28:48'),(1491,1,'admin','http://localhost:8080/irrigation/pump-information/pump-scheduler-list','pump_schedulers',1,'',2,'2021-03-15 06:28:51','2021-03-15 06:28:51'),(1492,1,'admin','http://localhost:8080/irrigation/pump-information/pump-scheduler-list','pump_schedulers',3,'',2,'2021-03-15 06:28:55','2021-03-15 06:28:55'),(1493,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list','master_scheme_types',1,'',1,'2021-03-15 06:29:23','2021-03-15 06:29:23'),(1494,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list','master_scheme_types',2,'',0,'2021-03-15 06:29:33','2021-03-15 06:29:33'),(1495,19,'01730233031','http://localhost:8080/scheme-application-submit','far_scheme_application',1,'',0,'2021-03-15 06:52:53','2021-03-15 06:52:53'),(1496,19,'01730233031','http://localhost:8080/scheme-application-submit/1','far_scheme_application',1,'',1,'2021-03-15 06:53:22','2021-03-15 06:53:22'),(1497,19,'01730233031','http://localhost:8080/scheme-application-submit/1','far_scheme_application',1,'',1,'2021-03-15 06:53:32','2021-03-15 06:53:32'),(1498,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',11,'',0,'2021-03-15 07:09:27','2021-03-15 07:09:27'),(1499,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',154,'',0,'2021-03-15 07:13:44','2021-03-15 07:13:44'),(1500,13,'01782599354','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',1,'',0,'2021-03-15 07:13:59','2021-03-15 07:13:59'),(1501,13,'01782599354','http://localhost:8080/water-testing-request-list','irrigation_payments',2,'',0,'2021-03-15 07:14:06','2021-03-15 07:14:06'),(1502,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_pump_opt_apps',1,'',2,'2021-03-15 08:01:16','2021-03-15 08:01:16'),(1503,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_resolves',3,'',0,'2021-03-15 10:55:05','2021-03-15 10:55:05'),(1504,1,'admin','http://localhost:8080/irrigation/pump-information/pump-scheduler-list','pump_schedulers',1,'',2,'2021-03-15 11:11:15','2021-03-15 11:11:15'),(1505,1,'admin','http://localhost:8080/irrigation/pump-information/pump-scheduler-list','pump_schedulers',1,'',2,'2021-03-15 11:11:18','2021-03-15 11:11:18'),(1506,19,'01730233031','http://localhost:8080/scheme-application-submit/1','far_scheme_application',1,'',1,'2021-03-15 12:21:12','2021-03-15 12:21:12'),(1507,19,'01730233031','http://localhost:8080/scheme-application-submit/1','far_scheme_application',1,'',1,'2021-03-15 12:43:59','2021-03-15 12:43:59'),(1508,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',1,'',2,'2021-03-16 06:04:34','2021-03-16 06:04:34'),(1509,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',4,'',0,'2021-03-16 06:40:21','2021-03-16 06:40:21'),(1510,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',1,'',2,'2021-03-16 06:50:44','2021-03-16 06:50:44'),(1511,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',3,'',1,'2021-03-16 07:16:09','2021-03-16 07:16:09'),(1512,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',2,'',1,'2021-03-16 07:16:24','2021-03-16 07:16:24'),(1513,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',3,'',2,'2021-03-16 07:16:29','2021-03-16 07:16:29'),(1514,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',2,'',2,'2021-03-16 07:16:33','2021-03-16 07:16:33'),(1515,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',2,'',2,'2021-03-16 07:16:36','2021-03-16 07:16:36'),(1516,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',16,'',1,'2021-03-16 07:26:06','2021-03-16 07:26:06'),(1517,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',16,'',1,'2021-03-16 07:27:15','2021-03-16 07:27:15'),(1518,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',16,'',1,'2021-03-16 07:29:38','2021-03-16 07:29:38'),(1519,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',12,'',1,'2021-03-16 07:33:52','2021-03-16 07:33:52'),(1520,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',12,'',1,'2021-03-16 07:47:20','2021-03-16 07:47:20'),(1521,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',155,'',0,'2021-03-16 07:59:44','2021-03-16 07:59:44'),(1522,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',155,'',1,'2021-03-16 07:59:54','2021-03-16 07:59:54'),(1523,14,'01767778333','http://localhost:8080/scheme-application-submit','far_scheme_application',2,'',0,'2021-03-16 08:36:17','2021-03-16 08:36:17'),(1524,12,'01843867772','http://localhost:8080/daily-task#','my_assign_tasks',7,'',0,'2021-03-16 08:37:51','2021-03-16 08:37:51'),(1525,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',1,'',0,'2021-03-16 09:28:13','2021-03-16 09:28:13'),(1526,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',2,'',0,'2021-03-16 09:31:31','2021-03-16 09:31:31'),(1527,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',3,'',0,'2021-03-16 09:34:22','2021-03-16 09:34:22'),(1528,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',4,'',0,'2021-03-16 09:35:28','2021-03-16 09:35:28'),(1529,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_apps',1,'',0,'2021-03-16 09:35:49','2021-03-16 09:35:49'),(1530,14,'01767778333','http://localhost:8080/pump-operator-application','irrigation_payments',3,'',0,'2021-03-16 09:35:58','2021-03-16 09:35:58'),(1531,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',1,'',0,'2021-03-16 09:56:32','2021-03-16 09:56:32'),(1532,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',156,'',0,'2021-03-16 10:01:50','2021-03-16 10:01:50'),(1533,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',157,'',0,'2021-03-16 10:02:12','2021-03-16 10:02:12'),(1534,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',158,'',0,'2021-03-16 10:02:24','2021-03-16 10:02:24'),(1535,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','pum_opt_apps_approvals',2,'',0,'2021-03-16 10:10:52','2021-03-16 10:10:52'),(1536,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','pum_opt_apps_approvals',3,'',0,'2021-03-16 10:23:26','2021-03-16 10:23:26'),(1537,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','pum_opt_apps_approvals',4,'',0,'2021-03-16 10:38:05','2021-03-16 10:38:05'),(1538,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-app-survey','pump_opt_apps_surveys',2,'',0,'2021-03-16 10:45:52','2021-03-16 10:45:52'),(1539,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-app-survey','pump_opt_apps_surveys',1,'',0,'2021-03-16 10:49:56','2021-03-16 10:49:56'),(1540,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',1,'',2,'2021-03-16 11:13:50','2021-03-16 11:13:50'),(1541,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',1,'',2,'2021-03-16 11:14:00','2021-03-16 11:14:00'),(1542,19,'01730233031','http://localhost:8080/scheme-application-submit/1','far_scheme_application',1,'',1,'2021-03-16 11:15:00','2021-03-16 11:15:00'),(1543,19,'01730233031','http://localhost:8080/scheme-application-submit/1','far_scheme_application',1,'',1,'2021-03-16 11:18:08','2021-03-16 11:18:08'),(1544,19,'01730233031','http://localhost:8080/scheme-application-submit/1','far_scheme_application',1,'',1,'2021-03-16 11:18:21','2021-03-16 11:18:21'),(1545,19,'01730233031','http://localhost:8080/scheme-application-submit/1','far_scheme_application',1,'',1,'2021-03-16 11:23:41','2021-03-16 11:23:41'),(1546,12,'01843867772','http://localhost:8080/daily-task','my_assign_tasks',8,'',0,'2021-03-16 11:57:38','2021-03-16 11:57:38'),(1547,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',158,'',1,'2021-03-16 12:32:49','2021-03-16 12:32:49'),(1548,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',159,'',0,'2021-03-16 12:50:54','2021-03-16 12:50:54'),(1549,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',160,'',0,'2021-03-16 12:51:13','2021-03-16 12:51:13'),(1550,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',161,'',0,'2021-03-16 12:51:32','2021-03-16 12:51:32'),(1551,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',162,'',0,'2021-03-16 12:51:53','2021-03-16 12:51:53'),(1552,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',159,'',1,'2021-03-16 12:52:01','2021-03-16 12:52:01'),(1553,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',160,'',1,'2021-03-16 12:52:06','2021-03-16 12:52:06'),(1554,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',2,'',1,'2021-03-18 04:23:16','2021-03-18 04:23:16'),(1555,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_rejects',1,'',0,'2021-03-18 04:23:16','2021-03-18 04:23:16'),(1556,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',5,'',0,'2021-03-18 04:27:46','2021-03-18 04:27:46'),(1557,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_apps',1,'',0,'2021-03-18 04:27:52','2021-03-18 04:27:52'),(1558,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_scheme_application',1,'',1,'2021-03-18 04:34:50','2021-03-18 04:34:50'),(1559,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_rejects',1,'',0,'2021-03-18 04:34:50','2021-03-18 04:34:50'),(1560,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_scheme_application',1,'',1,'2021-03-18 04:36:22','2021-03-18 04:36:22'),(1561,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_rejects',1,'',0,'2021-03-18 04:36:22','2021-03-18 04:36:22'),(1562,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_scheme_application',1,'',1,'2021-03-18 04:38:19','2021-03-18 04:38:19'),(1563,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_rejects',1,'',0,'2021-03-18 04:38:19','2021-03-18 04:38:19'),(1564,14,'01767778333','http://localhost:8080/smart-card-application-form','irrigation_payments',4,'',0,'2021-03-18 04:40:59','2021-03-18 04:40:59'),(1565,14,'01767778333','http://localhost:8080/smart-card-application-form','far_smart_card_apps',2,'',0,'2021-03-18 04:40:59','2021-03-18 04:40:59'),(1566,74,'sumanadmin','http://localhost:8080/irrigation/card-payment/new-application','far_smart_card_apps',2,'',2,'2021-03-18 04:42:04','2021-03-18 04:42:04'),(1567,12,'01843867772','http://localhost:8080/daily-task#','my_assign_tasks',9,'',0,'2021-03-18 05:03:07','2021-03-18 05:03:07'),(1568,74,'sumanadmin','http://localhost:8080/irrigation/card-payment/new-application','far_smart_card_apps',2,'',0,'2021-03-18 05:03:10','2021-03-18 05:03:10'),(1569,12,'01843867772','http://localhost:8080/daily-task#','my_assign_tasks',10,'',0,'2021-03-18 05:09:42','2021-03-18 05:09:42'),(1570,12,'01843867772','http://localhost:8080/daily-task#','my_assign_tasks',11,'',0,'2021-03-18 05:11:17','2021-03-18 05:11:17'),(1571,12,'01843867772','http://localhost:8080/daily-task#','my_assign_tasks',12,'',0,'2021-03-18 05:14:23','2021-03-18 05:14:23'),(1572,74,'sumanadmin','http://localhost:8080/irrigation/water-testing/drinking-water','far_water_test_apps',1,'',2,'2021-03-18 05:19:21','2021-03-18 05:19:21'),(1573,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_docs',6,'',0,'2021-03-18 08:37:02','2021-03-18 08:37:02'),(1574,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_apps',1,'',0,'2021-03-18 09:16:34','2021-03-18 09:16:34'),(1575,19,'01730233031','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',2,'',0,'2021-03-18 09:23:39','2021-03-18 09:23:39'),(1576,19,'01730233031','http://localhost:8080/water-testing-request-list','irrigation_payments',5,'',0,'2021-03-18 09:23:41','2021-03-18 09:23:41'),(1577,19,'01730233031','http://localhost:8080/water-testing-request-list','pump_operators',2,'',1,'2021-03-18 09:26:33','2021-03-18 09:26:33'),(1578,19,'01730233031','http://localhost:8080/water-testing-request-list','pump_operators',2,'',1,'2021-03-18 09:27:11','2021-03-18 09:27:11'),(1579,19,'01730233031','http://localhost:8080/water-testing-request-list','pump_operators',2,'',1,'2021-03-18 09:57:21','2021-03-18 09:57:21'),(1580,19,'01730233031','http://localhost:8080/water-testing-request-list','pump_operators',2,'',1,'2021-03-18 10:02:53','2021-03-18 10:02:53'),(1581,19,'01730233031','http://localhost:8080/water-testing-request-list','pump_operators',2,'',1,'2021-03-18 10:02:59','2021-03-18 10:02:59'),(1582,19,'01730233031','http://localhost:8080/water-testing-request-list','pump_operators',2,'',1,'2021-03-18 10:03:07','2021-03-18 10:03:07'),(1583,19,'01730233031','http://localhost:8080/water-testing-request-list','pump_operators',2,'',1,'2021-03-18 10:03:14','2021-03-18 10:03:14'),(1584,19,'01730233031','http://localhost:8080/water-testing-request-list','pump_operators',2,'',1,'2021-03-18 10:21:22','2021-03-18 10:21:22'),(1585,19,'01730233031','http://localhost:8080/water-testing-request-list','pump_operators',2,'',1,'2021-03-18 11:05:02','2021-03-18 11:05:02'),(1586,19,'01730233031','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',3,'',0,'2021-03-18 11:05:25','2021-03-18 11:05:25'),(1587,19,'01730233031','http://localhost:8080/water-testing-request-list','irrigation_payments',6,'',0,'2021-03-18 11:05:26','2021-03-18 11:05:26'),(1588,19,'01730233031','http://localhost:8080/water-testing-request-list','pump_operators',2,'',1,'2021-03-18 11:05:41','2021-03-18 11:05:41'),(1589,46,'01846633959','http://localhost:8080/pump-opt-application','far_pump_opt_docs',7,'',0,'2021-03-18 11:24:28','2021-03-18 11:24:28'),(1590,46,'01846633959','http://localhost:8080/pump-opt-application','far_pump_opt_apps',1,'',0,'2021-03-18 11:24:29','2021-03-18 11:24:29'),(1591,46,'01846633959','http://localhost:8080/pump-opt-application/1','far_pump_opt_docs',4,'',2,'2021-03-18 11:24:42','2021-03-18 11:24:42'),(1592,46,'01846633959','http://localhost:8080/pump-opt-application/1','far_pump_opt_docs',5,'',2,'2021-03-18 11:24:43','2021-03-18 11:24:43'),(1593,46,'01846633959','http://localhost:8080/pump-opt-application/1','far_pump_opt_docs',3,'',2,'2021-03-18 11:24:44','2021-03-18 11:24:44'),(1594,46,'01846633959','http://localhost:8080/pump-opt-application/1','far_pump_opt_docs',2,'',2,'2021-03-18 11:24:45','2021-03-18 11:24:45'),(1595,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list','master_scheme_types',1,'',1,'2021-03-18 11:42:45','2021-03-18 11:42:45'),(1596,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list','master_scheme_types',2,'',1,'2021-03-18 11:42:51','2021-03-18 11:42:51'),(1597,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list','master_scheme_types',3,'',0,'2021-03-18 11:43:01','2021-03-18 11:43:01'),(1598,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list','master_scheme_types',4,'',0,'2021-03-18 11:43:16','2021-03-18 11:43:16'),(1599,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',5,'',0,'2021-03-18 11:44:15','2021-03-18 11:44:15'),(1600,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',6,'',0,'2021-03-18 11:44:25','2021-03-18 11:44:25'),(1601,19,'01730233031','http://localhost:8080/water-testing-request-list','pump_operators',2,'',1,'2021-03-18 11:45:19','2021-03-18 11:45:19'),(1602,19,'01730233031','http://localhost:8080/water-testing-request-list','pump_operators',2,'',1,'2021-03-18 11:45:38','2021-03-18 11:45:38'),(1603,19,'01730233031','http://localhost:8080/water-testing-request-list','pump_operators',2,'',1,'2021-03-18 12:12:56','2021-03-18 12:12:56'),(1604,19,'01730233031','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',4,'',0,'2021-03-18 12:19:34','2021-03-18 12:19:34'),(1605,19,'01730233031','http://localhost:8080/water-testing-request-list','irrigation_payments',7,'',0,'2021-03-18 12:19:37','2021-03-18 12:19:37'),(1606,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-type-list','master_scheme_types',1,'',1,'2021-03-20 22:49:46','2021-03-20 22:49:46'),(1607,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/refund-deduction','far_app_payment_refunds_deducts',44,'',0,'2021-03-21 05:22:02','2021-03-21 05:22:02'),(1608,2,'admin33','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',5,'',0,'2021-03-21 11:00:07','2021-03-21 11:00:07'),(1609,2,'admin33','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',6,'',0,'2021-03-21 11:00:29','2021-03-21 11:00:29'),(1610,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','pum_opt_apps_approvals',7,'',0,'2021-03-22 05:21:12','2021-03-22 05:21:12'),(1611,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','pum_opt_apps_approvals',8,'',0,'2021-03-22 07:25:05','2021-03-22 07:25:05'),(1612,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-app-survey','pump_opt_apps_surveys',1,'',0,'2021-03-22 07:27:17','2021-03-22 07:27:17'),(1613,19,'01730233031','http://localhost:8080/my-profile-form','far_basic_infos',7,'',1,'2021-03-22 11:45:46','2021-03-22 11:45:46'),(1614,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/store-item-list','master_items',2,'',1,'2021-03-23 03:34:48','2021-03-23 03:34:48'),(1615,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',6,'',1,'2021-03-23 03:35:16','2021-03-23 03:35:16'),(1616,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',7,'',0,'2021-03-23 03:35:43','2021-03-23 03:35:43'),(1617,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',1,'',0,'2021-03-23 03:39:04','2021-03-23 03:39:04'),(1618,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',5,'',1,'2021-03-23 03:40:28','2021-03-23 03:40:28'),(1619,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',6,'',1,'2021-03-23 03:40:41','2021-03-23 03:40:41'),(1620,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',6,'',1,'2021-03-23 03:40:59','2021-03-23 03:40:59'),(1621,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',6,'',1,'2021-03-23 03:41:28','2021-03-23 03:41:28'),(1622,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',8,'',0,'2021-03-23 03:42:12','2021-03-23 03:42:12'),(1623,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',9,'',0,'2021-03-23 03:42:27','2021-03-23 03:42:27'),(1624,14,'01767778333','http://localhost:8080/scheme-application-submit','far_scheme_application',3,'',0,'2021-03-23 03:55:10','2021-03-23 03:55:10'),(1625,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',2,'',0,'2021-03-23 03:55:45','2021-03-23 03:55:45'),(1626,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',3,'',0,'2021-03-23 03:56:17','2021-03-23 03:56:17'),(1627,14,'01767778333','http://localhost:8080/scheme-application','irrigation_payments',8,'',0,'2021-03-23 03:57:19','2021-03-23 03:57:19'),(1628,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',3,'',1,'2021-03-23 04:00:25','2021-03-23 04:00:25'),(1629,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',15,'',0,'2021-03-23 04:00:25','2021-03-23 04:00:25'),(1630,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',3,'',1,'2021-03-23 04:01:05','2021-03-23 04:01:05'),(1631,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',26,'',0,'2021-03-23 04:01:05','2021-03-23 04:01:05'),(1632,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',1,'',0,'2021-03-23 04:01:05','2021-03-23 04:01:05'),(1633,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',3,'',2,'2021-03-23 04:01:19','2021-03-23 04:01:19'),(1634,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',3,'',2,'2021-03-23 04:02:19','2021-03-23 04:02:19'),(1635,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',1,'',0,'2021-03-23 04:02:43','2021-03-23 04:02:43'),(1636,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',1,'',1,'2021-03-23 04:02:49','2021-03-23 04:02:49'),(1637,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',1,'',0,'2021-03-23 04:03:04','2021-03-23 04:03:04'),(1638,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',3,'',1,'2021-03-23 04:03:12','2021-03-23 04:03:12'),(1639,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',1,'',0,'2021-03-23 04:03:12','2021-03-23 04:03:12'),(1640,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',4,'',0,'2021-03-23 04:08:00','2021-03-23 04:08:00'),(1641,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',5,'',0,'2021-03-23 04:08:14','2021-03-23 04:08:14'),(1642,14,'01767778333','http://localhost:8080/scheme-application','irrigation_payments',9,'',0,'2021-03-23 04:19:01','2021-03-23 04:19:01'),(1643,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',1,'',0,'2021-03-23 04:21:06','2021-03-23 04:21:06'),(1644,17,'','http://localhost:8080/scheme-application-submit','far_scheme_application',4,'',0,'2021-03-23 04:32:35','2021-03-23 04:32:35'),(1645,17,'','http://localhost:8080/scheme-application','irrigation_payments',10,'',0,'2021-03-23 04:32:45','2021-03-23 04:32:45'),(1646,12,'01843867772','http://localhost:8080/my-profile-form','far_basic_infos',4,'',1,'2021-03-23 05:01:44','2021-03-23 05:01:44'),(1647,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_application',3,'',1,'2021-03-23 05:17:23','2021-03-23 05:17:23'),(1648,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',1,'',1,'2021-03-23 05:17:23','2021-03-23 05:17:23'),(1649,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_application',3,'',1,'2021-03-23 05:19:39','2021-03-23 05:19:39'),(1650,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_supply_equipments',1,'',0,'2021-03-23 05:19:39','2021-03-23 05:19:39'),(1651,19,'01730233031','http://localhost:8080/my-profile-form','far_basic_infos',7,'',1,'2021-03-23 05:26:24','2021-03-23 05:26:24'),(1652,19,'01730233031','http://localhost:8080/my-profile-form','far_basic_infos',7,'',1,'2021-03-23 05:27:27','2021-03-23 05:27:27'),(1653,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-23 05:39:56','2021-03-23 05:39:56'),(1654,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',16,'',0,'2021-03-23 05:39:56','2021-03-23 05:39:56'),(1655,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-23 05:44:21','2021-03-23 05:44:21'),(1656,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',16,'',0,'2021-03-23 05:44:21','2021-03-23 05:44:21'),(1657,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-23 05:45:16','2021-03-23 05:45:16'),(1658,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',16,'',0,'2021-03-23 05:45:16','2021-03-23 05:45:16'),(1659,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',16,'',0,'2021-03-23 05:47:44','2021-03-23 05:47:44'),(1660,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-23 05:47:44','2021-03-23 05:47:44'),(1661,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-23 05:48:06','2021-03-23 05:48:06'),(1662,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_reviews',1,'',0,'2021-03-23 05:48:06','2021-03-23 05:48:06'),(1663,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',16,'',0,'2021-03-23 06:09:40','2021-03-23 06:09:40'),(1664,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-23 06:09:40','2021-03-23 06:09:40'),(1665,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',1,'2021-03-23 06:10:16','2021-03-23 06:10:16'),(1666,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',27,'',0,'2021-03-23 06:10:16','2021-03-23 06:10:16'),(1667,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',2,'',0,'2021-03-23 06:10:16','2021-03-23 06:10:16'),(1668,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',4,'',2,'2021-03-23 06:11:52','2021-03-23 06:11:52'),(1669,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',4,'',2,'2021-03-23 06:12:21','2021-03-23 06:12:21'),(1670,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',2,'',0,'2021-03-23 06:12:35','2021-03-23 06:12:35'),(1671,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',2,'',1,'2021-03-23 06:12:39','2021-03-23 06:12:39'),(1672,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',2,'',0,'2021-03-23 06:14:39','2021-03-23 06:14:39'),(1673,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',4,'',1,'2021-03-23 06:14:53','2021-03-23 06:14:53'),(1674,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',2,'',0,'2021-03-23 06:14:54','2021-03-23 06:14:54'),(1675,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',2,'',0,'2021-03-23 06:16:48','2021-03-23 06:16:48'),(1676,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_application',4,'',1,'2021-03-23 06:17:08','2021-03-23 06:17:08'),(1677,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',2,'',1,'2021-03-23 06:17:08','2021-03-23 06:17:08'),(1678,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_application',4,'',1,'2021-03-23 06:25:30','2021-03-23 06:25:30'),(1679,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_supply_equipments',2,'',0,'2021-03-23 06:25:31','2021-03-23 06:25:31'),(1680,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',1,'',2,'2021-03-23 06:38:36','2021-03-23 06:38:36'),(1681,19,'01730233034','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',5,'',0,'2021-03-23 06:50:48','2021-03-23 06:50:48'),(1682,19,'01730233034','http://localhost:8080/water-testing-request-list','irrigation_payments',11,'',0,'2021-03-23 06:50:51','2021-03-23 06:50:51'),(1683,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',6,'',0,'2021-03-23 07:25:21','2021-03-23 07:25:21'),(1684,12,'01843867772','http://localhost:8080/scheme-application-submit','far_scheme_application',5,'',0,'2021-03-23 07:34:06','2021-03-23 07:34:06'),(1685,201,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',44,'',1,'2021-03-23 07:35:51','2021-03-23 07:35:51'),(1686,14,'01767778333','http://localhost:8080/pump-opt-application','far_pump_opt_apps',2,'',0,'2021-03-23 07:51:18','2021-03-23 07:51:18'),(1687,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',9,'',0,'2021-03-23 08:12:41','2021-03-23 08:12:41'),(1688,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',10,'',0,'2021-03-23 08:13:49','2021-03-23 08:13:49'),(1689,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','pum_opt_apps_approvals',11,'',0,'2021-03-23 08:39:02','2021-03-23 08:39:02'),(1690,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-app-survey','pump_opt_apps_surveys',2,'',0,'2021-03-23 08:43:33','2021-03-23 08:43:33'),(1691,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','farmer_land_details',18,'',0,'2021-03-23 09:11:02','2021-03-23 09:11:02'),(1692,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','farmer_land_details',19,'',0,'2021-03-23 10:13:19','2021-03-23 10:13:19'),(1693,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','farmer_land_details',20,'',0,'2021-03-23 10:14:08','2021-03-23 10:14:08'),(1694,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','farmer_land_details',21,'',0,'2021-03-23 10:15:35','2021-03-23 10:15:35'),(1695,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-23 10:15:55','2021-03-23 10:15:55'),(1696,202,'01730233032','http://localhost:8080/scheme-application-submit','far_scheme_application',6,'',0,'2021-03-23 10:17:56','2021-03-23 10:17:56'),(1697,202,'01730233032','http://localhost:8080/scheme-application','farmer_land_details',22,'',0,'2021-03-23 10:18:29','2021-03-23 10:18:29'),(1698,12,'01843867772','http://localhost:8080/scheme-application','farmer_land_details',23,'',0,'2021-03-23 10:20:52','2021-03-23 10:20:52'),(1699,202,'01730233032','http://localhost:8080/scheme-application','irrigation_payments',12,'',0,'2021-03-23 10:22:32','2021-03-23 10:22:32'),(1700,202,'01730233032','http://localhost:8080/pump-opt-application','far_pump_opt_apps',3,'',0,'2021-03-23 10:34:42','2021-03-23 10:34:42'),(1701,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',7,'',0,'2021-03-23 10:36:10','2021-03-23 10:36:10'),(1702,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',8,'',0,'2021-03-23 10:36:20','2021-03-23 10:36:20'),(1703,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',9,'',0,'2021-03-23 10:36:47','2021-03-23 10:36:47'),(1704,202,'01730233032','http://localhost:8080/pump-operator-application','irrigation_payments',13,'',0,'2021-03-23 10:37:24','2021-03-23 10:37:24'),(1705,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',12,'',0,'2021-03-23 10:38:40','2021-03-23 10:38:40'),(1706,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-app-survey','pump_opt_apps_surveys',3,'',0,'2021-03-23 10:44:13','2021-03-23 10:44:13'),(1707,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pump_operators',55,'',0,'2021-03-23 10:50:23','2021-03-23 10:50:23'),(1708,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',3,'',2,'2021-03-23 10:50:23','2021-03-23 10:50:23'),(1709,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',9,'',1,'2021-03-23 11:02:05','2021-03-23 11:02:05'),(1710,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',17,'',0,'2021-03-23 11:06:33','2021-03-23 11:06:33'),(1711,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',6,'',1,'2021-03-23 11:06:33','2021-03-23 11:06:33'),(1712,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',6,'',1,'2021-03-23 11:08:17','2021-03-23 11:08:17'),(1713,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',28,'',0,'2021-03-23 11:08:17','2021-03-23 11:08:17'),(1714,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',3,'',0,'2021-03-23 11:08:17','2021-03-23 11:08:17'),(1715,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',6,'',2,'2021-03-23 11:08:39','2021-03-23 11:08:39'),(1716,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',6,'',2,'2021-03-23 11:09:04','2021-03-23 11:09:04'),(1717,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',6,'',2,'2021-03-23 11:09:24','2021-03-23 11:09:24'),(1718,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',3,'',0,'2021-03-23 11:09:55','2021-03-23 11:09:55'),(1719,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',3,'',1,'2021-03-23 11:10:01','2021-03-23 11:10:01'),(1720,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',3,'',0,'2021-03-23 11:10:15','2021-03-23 11:10:15'),(1721,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',6,'',1,'2021-03-23 11:10:31','2021-03-23 11:10:31'),(1722,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',3,'',0,'2021-03-23 11:10:31','2021-03-23 11:10:31'),(1723,202,'01730233032','http://localhost:8080/scheme-application','irrigation_payments',14,'',0,'2021-03-23 11:11:10','2021-03-23 11:11:10'),(1724,202,'01730233032','http://localhost:8080/scheme-application','irrigation_payments',15,'',0,'2021-03-23 11:11:14','2021-03-23 11:11:14'),(1725,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',6,'',0,'2021-03-23 11:19:57','2021-03-23 11:19:57'),(1726,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-out','pump_stock_out_infos',9,'',0,'2021-03-23 11:20:42','2021-03-23 11:20:42'),(1727,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',3,'',0,'2021-03-23 11:22:36','2021-03-23 11:22:36'),(1728,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_application',6,'',1,'2021-03-23 11:22:44','2021-03-23 11:22:44'),(1729,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/requisition-list','far_scheme_requisitions',3,'',1,'2021-03-23 11:22:44','2021-03-23 11:22:44'),(1730,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_application',6,'',1,'2021-03-23 11:23:11','2021-03-23 11:23:11'),(1731,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/supply-equipment','far_scheme_supply_equipments',3,'',0,'2021-03-23 11:23:11','2021-03-23 11:23:11'),(1732,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','farmer_land_details',24,'',0,'2021-03-23 11:25:09','2021-03-23 11:25:09'),(1733,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-out','pump_stock_out_infos',10,'',0,'2021-03-23 11:38:54','2021-03-23 11:38:54'),(1734,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-out','pump_stock_out_infos',11,'',0,'2021-03-23 11:42:49','2021-03-23 11:42:49'),(1735,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-out','pump_stock_out_infos',12,'',0,'2021-03-23 11:55:13','2021-03-23 11:55:13'),(1736,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-out-approve','pump_stock_out_details',12,'',2,'2021-03-23 11:55:21','2021-03-23 11:55:21'),(1737,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',5,'',1,'2021-03-24 01:54:09','2021-03-24 01:54:09'),(1738,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/store-item-list','master_items',6,'',0,'2021-03-24 01:55:54','2021-03-24 01:55:54'),(1739,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',4,'',1,'2021-03-24 02:10:19','2021-03-24 02:10:19'),(1740,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',4,'',1,'2021-03-24 02:10:28','2021-03-24 02:10:28'),(1741,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',1,'',1,'2021-03-24 02:10:39','2021-03-24 02:10:39'),(1742,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',1,'',1,'2021-03-24 02:10:44','2021-03-24 02:10:44'),(1743,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',1,'',1,'2021-03-24 02:15:34','2021-03-24 02:15:34'),(1744,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',1,'',1,'2021-03-24 02:15:56','2021-03-24 02:15:56'),(1745,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',1,'',1,'2021-03-24 02:16:13','2021-03-24 02:16:13'),(1746,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',1,'',1,'2021-03-24 02:16:29','2021-03-24 02:16:29'),(1747,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',1,'',1,'2021-03-24 02:16:34','2021-03-24 02:16:34'),(1748,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',1,'',1,'2021-03-24 02:16:39','2021-03-24 02:16:39'),(1749,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',12,'',0,'2021-03-24 02:17:03','2021-03-24 02:17:03'),(1750,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_pump_opt_rejects',6,'',0,'2021-03-24 08:44:59','2021-03-24 08:44:59'),(1751,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_water_samples',1,'',0,'2021-03-24 08:44:59','2021-03-24 08:44:59'),(1752,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_pump_opt_rejects',7,'',0,'2021-03-24 08:46:03','2021-03-24 08:46:03'),(1753,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_water_samples',2,'',0,'2021-03-24 08:46:03','2021-03-24 08:46:03'),(1754,1,'admin','http://localhost:8080/irrigation/water-testing/testing-report-collection','far_water_test_apps',6,'',2,'2021-03-24 08:47:09','2021-03-24 08:47:09'),(1755,1,'admin','http://localhost:8080/irrigation/water-testing/testing-report-collection','far_water_test_apps',7,'',2,'2021-03-24 08:48:29','2021-03-24 08:48:29'),(1756,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_pump_opt_rejects',8,'',0,'2021-03-24 09:06:09','2021-03-24 09:06:09'),(1757,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_water_samples',3,'',0,'2021-03-24 09:06:09','2021-03-24 09:06:09'),(1758,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_pump_opt_rejects',9,'',0,'2021-03-24 09:06:26','2021-03-24 09:06:26'),(1759,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_water_samples',4,'',0,'2021-03-24 09:06:26','2021-03-24 09:06:26'),(1760,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/configuration/scheme-type-list','master_scheme_types',4,'',0,'2021-03-24 03:06:34','2021-03-24 03:06:34'),(1761,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/configuration/scheme-type-list','master_scheme_types',5,'',0,'2021-03-24 03:07:25','2021-03-24 03:07:25'),(1762,1,'admin','http://localhost:8080/irrigation/water-testing/testing-report-collection','far_water_test_apps',9,'',2,'2021-03-24 09:08:36','2021-03-24 09:08:36'),(1763,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/configuration/scheme-type-list','master_scheme_types',6,'',0,'2021-03-24 03:08:39','2021-03-24 03:08:39'),(1764,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/configuration/scheme-type-list','master_scheme_types',6,'',1,'2021-03-24 03:08:46','2021-03-24 03:08:46'),(1765,1,'admin','http://localhost:8080/irrigation/water-testing/testing-report-collection','far_water_test_apps',8,'',2,'2021-03-24 09:08:56','2021-03-24 09:08:56'),(1766,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/configuration/scheme-type-list','master_scheme_types',1,'',1,'2021-03-24 03:09:35','2021-03-24 03:09:35'),(1767,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',13,'',0,'2021-03-24 03:12:03','2021-03-24 03:12:03'),(1768,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',10,'',0,'2021-03-24 03:28:05','2021-03-24 03:28:05'),(1769,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',10,'',1,'2021-03-24 03:30:29','2021-03-24 03:30:29'),(1770,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/configuration/scheme-type-list','master_scheme_types',7,'',0,'2021-03-24 03:34:25','2021-03-24 03:34:25'),(1771,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list','master_laboratories',20,'',0,'2021-03-24 03:52:32','2021-03-24 03:52:32'),(1772,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','farmer_land_details',25,'',0,'2021-03-24 09:56:20','2021-03-24 09:56:20'),(1773,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',10,'',0,'2021-03-24 04:03:10','2021-03-24 04:03:10'),(1774,12,'01843867772','http://localhost:8080/my-profile-form','far_basic_infos',4,'',1,'2021-03-24 10:03:49','2021-03-24 10:03:49'),(1775,12,'01843867772','http://localhost:8080/scheme-application-submit/5','far_scheme_application',5,'',1,'2021-03-24 10:04:43','2021-03-24 10:04:43'),(1776,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',11,'',0,'2021-03-24 10:05:59','2021-03-24 10:05:59'),(1777,12,'01843867772','http://localhost:8080/scheme-application','irrigation_payments',16,'',0,'2021-03-24 10:06:07','2021-03-24 10:06:07'),(1778,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',18,'',0,'2021-03-24 10:06:23','2021-03-24 10:06:23'),(1779,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',5,'',1,'2021-03-24 10:06:23','2021-03-24 10:06:23'),(1780,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',5,'',1,'2021-03-24 10:06:35','2021-03-24 10:06:35'),(1781,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_surveys',29,'',0,'2021-03-24 10:06:35','2021-03-24 10:06:35'),(1782,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_notes',4,'',0,'2021-03-24 10:06:35','2021-03-24 10:06:35'),(1783,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',5,'',2,'2021-03-24 10:06:43','2021-03-24 10:06:43'),(1784,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',5,'',2,'2021-03-24 10:07:06','2021-03-24 10:07:06'),(1785,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',4,'',0,'2021-03-24 10:07:18','2021-03-24 10:07:18'),(1786,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',4,'',1,'2021-03-24 10:07:22','2021-03-24 10:07:22'),(1787,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',4,'',0,'2021-03-24 10:07:35','2021-03-24 10:07:35'),(1788,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',5,'',1,'2021-03-24 10:07:44','2021-03-24 10:07:44'),(1789,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',4,'',0,'2021-03-24 10:07:44','2021-03-24 10:07:44'),(1790,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',12,'',0,'2021-03-24 10:09:14','2021-03-24 10:09:14'),(1791,12,'01843867772','http://localhost:8080/scheme-application-submit','far_scheme_application',7,'',0,'2021-03-24 10:49:35','2021-03-24 10:49:35'),(1792,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list','master_pump_progress_types',9,'',0,'2021-03-24 10:53:20','2021-03-24 10:53:20'),(1793,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list','master_pump_progress_types',10,'',0,'2021-03-24 10:53:40','2021-03-24 10:53:40'),(1794,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','far_pump_opt_apps',1,'',2,'2021-03-24 10:54:33','2021-03-24 10:54:33'),(1795,12,'01843867772','http://localhost:8080/farmer-complain','far_complains',17,'',0,'2021-03-24 11:05:48','2021-03-24 11:05:48'),(1796,1,'admin','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',17,'',1,'2021-03-24 11:06:20','2021-03-24 11:06:20'),(1797,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','far_pump_opt_apps',2,'',2,'2021-03-24 11:08:15','2021-03-24 11:08:15'),(1798,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','pump_operators',56,'',0,'2021-03-24 11:10:20','2021-03-24 11:10:20'),(1799,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','far_pump_opt_apps',3,'',2,'2021-03-24 11:10:20','2021-03-24 11:10:20'),(1800,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/store-item-list','master_items',7,'',0,'2021-03-24 11:16:47','2021-03-24 11:16:47'),(1801,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/store-item-list','master_items',8,'',0,'2021-03-24 11:23:00','2021-03-24 11:23:00'),(1802,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/store-item-list','master_items',9,'',0,'2021-03-24 11:23:00','2021-03-24 11:23:00'),(1803,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/store-item-list','master_items',10,'',0,'2021-03-24 11:27:52','2021-03-24 11:27:52'),(1804,12,'01843867772','http://localhost:8080/scheme-application-submit','far_scheme_application',8,'',0,'2021-03-24 11:28:16','2021-03-24 11:28:16'),(1805,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',57,'',0,'2021-03-24 11:43:55','2021-03-24 11:43:55'),(1806,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance#','far_complains',17,'',1,'2021-03-24 11:53:22','2021-03-24 11:53:22'),(1807,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log-entry-form/5','pump_drilling_log',5,'',1,'2021-03-24 12:05:14','2021-03-24 12:05:14'),(1808,1,'admin','http://localhost:8080/irrigation/pump-information/drilling-log-entry-form/5','pump_drilling_log',5,'',1,'2021-03-24 12:05:34','2021-03-24 12:05:34'),(1809,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',13,'',0,'2021-03-24 12:16:26','2021-03-24 12:16:26'),(1810,1,'admin','http://localhost:8080/irrigation/pump-information/pump-operator-list','pump_operators',58,'',0,'2021-03-24 12:18:29','2021-03-24 12:18:29'),(1811,1,'admin','http://localhost:8080/irrigation/pump-information/pump-report-entry-form/12','pump_drilling_log',12,'',1,'2021-03-24 12:19:54','2021-03-24 12:19:54'),(1812,1,'admin','http://localhost:8080/irrigation/pump-information/pump-report-entry-form/12','pump_drilling_log',12,'',1,'2021-03-24 12:20:18','2021-03-24 12:20:18'),(1813,1,'admin','http://localhost:8080/irrigation/pump-information/pump-report-entry-form/12','pump_drilling_log',12,'',1,'2021-03-24 12:20:40','2021-03-24 12:20:40'),(1814,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_pump_opt_rejects',10,'',0,'2021-03-24 12:32:39','2021-03-24 12:32:39'),(1815,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_water_samples',5,'',0,'2021-03-24 12:32:39','2021-03-24 12:32:39'),(1816,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_pump_opt_rejects',11,'',0,'2021-03-24 12:32:51','2021-03-24 12:32:51'),(1817,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_water_samples',6,'',0,'2021-03-24 12:32:51','2021-03-24 12:32:51'),(1818,1,'admin','http://localhost:8080/irrigation/water-testing/testing-report-collection','far_water_test_apps',10,'',2,'2021-03-24 12:33:14','2021-03-24 12:33:14'),(1819,1,'admin','http://localhost:8080/irrigation/water-testing/testing-report-collection','far_water_test_apps',11,'',2,'2021-03-24 12:33:31','2021-03-24 12:33:31'),(1820,1,'admin','http://localhost:8080/irrigation/pump-information/pump-report-entry-form/12','pump_drilling_log',12,'',1,'2021-03-24 12:39:56','2021-03-24 12:39:56'),(1821,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',12,'',0,'2021-03-24 12:51:00','2021-03-24 12:51:00'),(1822,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',13,'',0,'2021-03-24 12:54:43','2021-03-24 12:54:43'),(1823,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complain_tro_equipments',7,'',0,'2021-03-24 13:07:30','2021-03-24 13:07:30'),(1824,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',14,'',1,'2021-03-24 13:07:34','2021-03-24 13:07:34'),(1825,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_requisitions',4,'',0,'2021-03-24 13:13:23','2021-03-24 13:13:23'),(1826,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complains',17,'',1,'2021-03-24 13:13:28','2021-03-24 13:13:28'),(1827,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_requisitions',4,'',1,'2021-03-24 13:13:28','2021-03-24 13:13:28'),(1828,1,'admin','http://localhost:8080/irrigation/pump-maintenance/supply-equipment','far_complain_supply_equipments',5,'',0,'2021-03-24 13:15:37','2021-03-24 13:15:37'),(1829,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',19,'',0,'2021-03-24 14:13:12','2021-03-24 14:13:12'),(1830,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',1,'',1,'2021-03-24 14:13:12','2021-03-24 14:13:12'),(1831,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-24 14:26:55','2021-03-24 14:26:55'),(1832,12,'01843867772','http://localhost:8080/farmer-complain','far_complains',18,'',0,'2021-03-25 03:35:27','2021-03-25 03:35:27'),(1833,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',7,'',0,'2021-03-24 23:00:09','2021-03-24 23:00:09'),(1834,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',7,'',1,'2021-03-24 23:00:24','2021-03-24 23:00:24'),(1835,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/item-category-list','master_item_categories',2,'',1,'2021-03-24 23:06:36','2021-03-24 23:06:36'),(1836,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-25 05:13:51','2021-03-25 05:13:51'),(1837,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-25 05:15:56','2021-03-25 05:15:56'),(1838,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-25 05:16:27','2021-03-25 05:16:27'),(1839,12,'01843867772','http://localhost:8080/smart-card-application-form','irrigation_payments',17,'',0,'2021-03-25 05:17:09','2021-03-25 05:17:09'),(1840,12,'01843867772','http://localhost:8080/smart-card-application-form','far_smart_card_apps',2,'',0,'2021-03-25 05:17:09','2021-03-25 05:17:09'),(1841,1,'admin','http://localhost:8080/irrigation/pump-information/pump-report-entry','deep_tubewell_yearly_final_report',1,'',2,'2021-03-25 05:17:24','2021-03-25 05:17:24'),(1842,1,'admin','http://localhost:8080/irrigation/pump-information/pump-report-entry','deep_tubewell_yearly_final_report',5,'',2,'2021-03-25 05:17:30','2021-03-25 05:17:30'),(1843,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-25 05:18:09','2021-03-25 05:18:09'),(1844,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-25 05:18:46','2021-03-25 05:18:46'),(1845,12,'01843867772','http://localhost:8080/smart-card-application-form','irrigation_payments',18,'',0,'2021-03-25 05:19:16','2021-03-25 05:19:16'),(1846,12,'01843867772','http://localhost:8080/smart-card-application-form','far_smart_card_apps',3,'',0,'2021-03-25 05:19:16','2021-03-25 05:19:16'),(1847,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-25 05:22:37','2021-03-25 05:22:37'),(1848,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/configuration/scheme-type-list','master_scheme_types',8,'',0,'2021-03-24 23:23:37','2021-03-24 23:23:37'),(1849,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-25 05:24:54','2021-03-25 05:24:54'),(1850,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-25 05:25:10','2021-03-25 05:25:10'),(1851,12,'01843867772','http://localhost:8080/rating','far_ratings',2,'',0,'2021-03-25 05:25:54','2021-03-25 05:25:54'),(1852,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-25 05:53:58','2021-03-25 05:53:58'),(1853,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-25 05:59:46','2021-03-25 05:59:46'),(1854,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',20,'',0,'2021-03-25 06:13:28','2021-03-25 06:13:28'),(1855,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',8,'',1,'2021-03-25 06:13:28','2021-03-25 06:13:28'),(1856,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',8,'',2,'2021-03-25 06:26:09','2021-03-25 06:26:09'),(1857,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/pump-installation/license-application-list','far_scheme_application',8,'',2,'2021-03-25 06:26:25','2021-03-25 06:26:25'),(1858,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',5,'',0,'2021-03-25 06:26:35','2021-03-25 06:26:35'),(1859,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/pump-installation/current-status','far_scheme_license',5,'',1,'2021-03-25 06:27:00','2021-03-25 06:27:00'),(1860,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreement',5,'',0,'2021-03-25 06:27:10','2021-03-25 06:27:10'),(1861,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_application',8,'',1,'2021-03-25 06:27:15','2021-03-25 06:27:15'),(1862,212,'bmdauser','http://localhost:8080/irrigation-scheme-service/pump-installation/contract-agreement','far_scheme_agreemt_doc',5,'',0,'2021-03-25 06:27:16','2021-03-25 06:27:16'),(1863,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',5,'',1,'2021-03-25 01:05:08','2021-03-25 01:05:08'),(1864,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',11,'',0,'2021-03-25 01:06:32','2021-03-25 01:06:32'),(1865,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',12,'',0,'2021-03-25 01:18:11','2021-03-25 01:18:11'),(1866,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',13,'',0,'2021-03-25 01:19:57','2021-03-25 01:19:57'),(1867,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',14,'',0,'2021-03-25 01:20:31','2021-03-25 01:20:31'),(1868,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',15,'',0,'2021-03-25 01:21:31','2021-03-25 01:21:31'),(1869,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',16,'',0,'2021-03-25 01:22:32','2021-03-25 01:22:32'),(1870,74,'sumanadmin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',14,'',0,'2021-03-25 08:10:37','2021-03-25 08:10:37'),(1871,74,'sumanadmin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',15,'',0,'2021-03-25 08:11:55','2021-03-25 08:11:55'),(1872,74,'sumanadmin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',16,'',0,'2021-03-25 08:14:30','2021-03-25 08:14:30'),(1873,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',13,'',0,'2021-03-25 08:42:18','2021-03-25 08:42:18'),(1874,1,'admin','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',18,'',1,'2021-03-25 08:55:23','2021-03-25 08:55:23'),(1875,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complain_tro_equipments',8,'',0,'2021-03-25 09:07:01','2021-03-25 09:07:01'),(1876,1,'admin','http://localhost:8080/irrigation/pump-maintenance/required-maintenance','far_complains',18,'',1,'2021-03-25 09:07:04','2021-03-25 09:07:04'),(1877,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_requisitions',5,'',0,'2021-03-25 09:11:47','2021-03-25 09:11:47'),(1878,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_progress_reports',10,'',0,'2021-03-25 09:12:10','2021-03-25 09:12:10'),(1879,1,'admin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_resolves',4,'',0,'2021-03-25 09:12:19','2021-03-25 09:12:19'),(1880,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',17,'',0,'2021-03-25 09:15:33','2021-03-25 09:15:33'),(1881,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',14,'',0,'2021-03-25 09:15:54','2021-03-25 09:15:54'),(1882,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_pump_opt_rejects',12,'',0,'2021-03-25 09:18:24','2021-03-25 09:18:24'),(1883,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-entry','far_water_samples',7,'',0,'2021-03-25 09:18:25','2021-03-25 09:18:25'),(1884,12,'01843867772','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',13,'',0,'2021-03-25 09:21:28','2021-03-25 09:21:28'),(1885,12,'01843867772','http://localhost:8080/water-testing-request-list','irrigation_payments',19,'',0,'2021-03-25 09:21:32','2021-03-25 09:21:32'),(1886,1,'admin','http://localhost:8080/irrigation/water-testing/drinking-water','far_water_test_apps',13,'',2,'2021-03-25 09:22:46','2021-03-25 09:22:46'),(1887,1,'admin','http://localhost:8080/irrigation/water-testing/testing-report-collection','far_water_test_apps',13,'',2,'2021-03-25 09:24:03','2021-03-25 09:24:03'),(1888,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-reported','far_water_test_apps',13,'',2,'2021-03-25 09:26:09','2021-03-25 09:26:09'),(1889,74,'sumanadmin','http://localhost:8080/irrigation/task/task-calendar','task_task_reports',6,'',0,'2021-03-25 09:45:14','2021-03-25 09:45:14'),(1890,14,'01767778333','http://localhost:8080/scheme-application','irrigation_payments',20,'',0,'2021-03-25 09:47:30','2021-03-25 09:47:30'),(1891,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-25 10:13:50','2021-03-25 10:13:50'),(1892,74,'sumanadmin','http://localhost:8080/irrigation/task/task-tracker','task_review_notes',5,'',0,'2021-03-25 10:21:41','2021-03-25 10:21:41'),(1893,202,'01730233032','http://localhost:8080/scheme-application','irrigation_payments',21,'',0,'2021-03-25 10:37:12','2021-03-25 10:37:12'),(1894,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',17,'',0,'2021-03-25 10:51:26','2021-03-25 10:51:26'),(1895,1,'admin','http://localhost:8080/irrigation/task/task-tracker','task_assign_tasks',17,'',2,'2021-03-25 10:55:12','2021-03-25 10:55:12'),(1896,1,'admin','http://localhost:8080/irrigation/task/task-tracker','task_assign_tasks',16,'',2,'2021-03-25 10:56:20','2021-03-25 10:56:20'),(1897,74,'sumanadmin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',18,'',0,'2021-03-25 11:03:34','2021-03-25 11:03:34'),(1898,74,'sumanadmin','http://localhost:8080/irrigation/task/task-calendar','task_task_reports',7,'',0,'2021-03-25 11:04:11','2021-03-25 11:04:11'),(1899,12,'01843867772','http://localhost:8080/my-profile-form','far_basic_infos',4,'',1,'2021-03-25 11:52:41','2021-03-25 11:52:41'),(1900,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/store-item-list','master_items',11,'',0,'2021-03-25 11:56:19','2021-03-25 11:56:19'),(1901,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-27 04:54:40','2021-03-27 04:54:40'),(1902,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-27 04:59:34','2021-03-27 04:59:34'),(1903,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-27 05:26:07','2021-03-27 05:26:07'),(1904,219,'01531875147','http://localhost:8080/my-profile-form','far_basic_infos',46,'',1,'2021-03-26 23:56:07','2021-03-26 23:56:07'),(1905,219,'01531875147','http://localhost:8080/pump-opt-application','far_pump_opt_docs',8,'',0,'2021-03-26 23:56:33','2021-03-26 23:56:33'),(1906,219,'01531875147','http://localhost:8080/pump-opt-application','far_pump_opt_apps',4,'',0,'2021-03-27 00:00:29','2021-03-27 00:00:29'),(1907,219,'01531875147','http://localhost:8080/pump-opt-application/4','far_pump_opt_apps',4,'',1,'2021-03-27 00:05:30','2021-03-27 00:05:30'),(1908,219,'01531875147','http://localhost:8080/pump-opt-application','far_pump_opt_apps',5,'',0,'2021-03-27 00:07:53','2021-03-27 00:07:53'),(1909,219,'01531875147','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',14,'',0,'2021-03-27 00:08:42','2021-03-27 00:08:42'),(1910,219,'01531875147','http://localhost:8080/water-testing-request-list','irrigation_payments',22,'',0,'2021-03-27 00:08:43','2021-03-27 00:08:43'),(1911,219,'01531875147','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',15,'',0,'2021-03-27 00:12:19','2021-03-27 00:12:19'),(1912,219,'01531875147','http://localhost:8080/water-testing-request-list','irrigation_payments',23,'',0,'2021-03-27 00:12:20','2021-03-27 00:12:20'),(1913,219,'01531875147','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',16,'',0,'2021-03-27 00:12:34','2021-03-27 00:12:34'),(1914,219,'01531875147','http://localhost:8080/water-testing-request-list','irrigation_payments',24,'',0,'2021-03-27 00:12:35','2021-03-27 00:12:35'),(1915,219,'01531875147','http://localhost:8080/water-testing-request-list','pump_operators',15,'',1,'2021-03-27 00:16:40','2021-03-27 00:16:40'),(1916,219,'01531875147','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',17,'',0,'2021-03-27 00:17:25','2021-03-27 00:17:25'),(1917,219,'01531875147','http://localhost:8080/water-testing-request-list','irrigation_payments',25,'',0,'2021-03-27 00:17:25','2021-03-27 00:17:25'),(1918,219,'01531875147','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',18,'',0,'2021-03-27 00:18:07','2021-03-27 00:18:07'),(1919,219,'01531875147','http://localhost:8080/water-testing-request-list','irrigation_payments',26,'',0,'2021-03-27 00:18:07','2021-03-27 00:18:07'),(1920,219,'01531875147','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',19,'',0,'2021-03-27 00:19:26','2021-03-27 00:19:26'),(1921,219,'01531875147','http://localhost:8080/water-testing-request-list','irrigation_payments',27,'',0,'2021-03-27 00:19:27','2021-03-27 00:19:27'),(1922,219,'01531875147','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',20,'',0,'2021-03-27 00:20:40','2021-03-27 00:20:40'),(1923,219,'01531875147','http://localhost:8080/water-testing-request-list','irrigation_payments',28,'',0,'2021-03-27 00:20:40','2021-03-27 00:20:40'),(1924,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',13,'',1,'2021-03-27 06:23:08','2021-03-27 06:23:08'),(1925,219,'01531875147','http://localhost:8080/water-testing-request-list','pump_operators',20,'',1,'2021-03-27 00:23:20','2021-03-27 00:23:20'),(1926,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','pum_opt_apps_approvals',14,'',0,'2021-03-27 06:24:27','2021-03-27 06:24:27'),(1927,219,'01531875147','http://localhost:8080/water-testing-request-list','pump_operators',20,'',1,'2021-03-27 00:25:25','2021-03-27 00:25:25'),(1928,219,'01531875147','http://localhost:8080/water-testing-request-list','pump_operators',20,'',1,'2021-03-27 00:25:34','2021-03-27 00:25:34'),(1929,219,'01531875147','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',21,'',0,'2021-03-27 00:25:56','2021-03-27 00:25:56'),(1930,219,'01531875147','http://localhost:8080/water-testing-request-list','irrigation_payments',29,'',0,'2021-03-27 00:25:56','2021-03-27 00:25:56'),(1931,219,'01531875147','http://localhost:8080/water-testing-request-list','pump_operators',21,'',1,'2021-03-27 00:26:58','2021-03-27 00:26:58'),(1932,219,'01531875147','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',22,'',0,'2021-03-27 00:27:25','2021-03-27 00:27:25'),(1933,219,'01531875147','http://localhost:8080/water-testing-request-list','irrigation_payments',30,'',0,'2021-03-27 00:27:25','2021-03-27 00:27:25'),(1934,219,'01531875147','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',23,'',0,'2021-03-27 00:30:07','2021-03-27 00:30:07'),(1935,219,'01531875147','http://localhost:8080/water-testing-request-list','irrigation_payments',31,'',0,'2021-03-27 00:30:07','2021-03-27 00:30:07'),(1936,219,'01531875147','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',24,'',0,'2021-03-27 00:30:33','2021-03-27 00:30:33'),(1937,219,'01531875147','http://localhost:8080/water-testing-request-list','irrigation_payments',32,'',0,'2021-03-27 00:30:33','2021-03-27 00:30:33'),(1938,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','pum_opt_apps_approvals',15,'',0,'2021-03-27 06:31:42','2021-03-27 06:31:42'),(1939,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','pum_opt_apps_approvals',16,'',0,'2021-03-27 06:34:58','2021-03-27 06:34:58'),(1940,220,'01531875147','http://localhost:8080/my-profile-form','far_basic_infos',47,'',1,'2021-03-27 00:37:49','2021-03-27 00:37:49'),(1941,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','pum_opt_apps_approvals',17,'',0,'2021-03-27 06:38:22','2021-03-27 06:38:22'),(1942,220,'01531875147','http://localhost:8080/scheme-application-submit','far_scheme_application',9,'',0,'2021-03-27 00:40:21','2021-03-27 00:40:21'),(1943,220,'01531875147','http://localhost:8080/scheme-application-submit/9','far_scheme_application',9,'',1,'2021-03-27 00:40:51','2021-03-27 00:40:51'),(1944,220,'01531875147','http://localhost:8080/scheme-application-submit/9','far_scheme_application',9,'',1,'2021-03-27 00:41:22','2021-03-27 00:41:22'),(1945,220,'01531875147','http://localhost:8080/scheme-application-submit/9','far_scheme_application',9,'',1,'2021-03-27 00:41:33','2021-03-27 00:41:33'),(1946,220,'01531875147','http://localhost:8080/pump-opt-application','far_pump_opt_apps',6,'',0,'2021-03-27 00:42:29','2021-03-27 00:42:29'),(1947,220,'01531875147','http://localhost:8080/pump-opt-application/6','far_pump_opt_apps',6,'',1,'2021-03-27 00:42:54','2021-03-27 00:42:54'),(1948,220,'01531875147','http://localhost:8080/pump-opt-application/6','far_pump_opt_apps',6,'',1,'2021-03-27 00:43:21','2021-03-27 00:43:21'),(1949,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','pum_opt_apps_approvals',18,'',0,'2021-03-27 06:43:25','2021-03-27 06:43:25'),(1950,220,'01531875147','http://localhost:8080/pump-opt-application/6','far_pump_opt_apps',6,'',1,'2021-03-27 00:44:11','2021-03-27 00:44:11'),(1951,220,'01531875147','http://localhost:8080/pump-opt-application/6','far_pump_opt_apps',6,'',1,'2021-03-27 00:44:33','2021-03-27 00:44:33'),(1952,220,'01531875147','http://localhost:8080/pump-opt-application/6','far_pump_opt_apps',6,'',1,'2021-03-27 00:45:24','2021-03-27 00:45:24'),(1953,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/receive-pump-opt-app','pum_opt_apps_approvals',19,'',0,'2021-03-27 06:47:22','2021-03-27 06:47:22'),(1954,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',20,'',0,'2021-03-27 06:51:18','2021-03-27 06:51:18'),(1955,74,'sumanadmin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-app-survey','pump_opt_apps_surveys',1,'',0,'2021-03-27 07:03:37','2021-03-27 07:03:37'),(1956,1,'admin','http://localhost:8080/irrigation/pump-information/pump-report-entry-form?id=12','deep_tubewell_yearly_final_report',12,'',1,'2021-03-28 04:54:53','2021-03-28 04:54:53'),(1957,221,'01924496004','http://localhost:8080/my-profile-form','far_basic_infos',48,'',1,'2021-03-27 22:58:56','2021-03-27 22:58:56'),(1958,222,'01850953185','http://localhost:8080/my-profile-form','far_basic_infos',49,'',1,'2021-03-27 23:12:04','2021-03-27 23:12:04'),(1959,223,'01924496004','http://localhost:8080/my-profile-form','far_basic_infos',50,'',1,'2021-03-27 23:21:53','2021-03-27 23:21:53'),(1960,225,'01531875147','http://localhost:8080/my-profile-form','far_basic_infos',51,'',1,'2021-03-27 23:46:34','2021-03-27 23:46:34'),(1961,225,'01531875147','http://localhost:8080/scheme-application-submit','far_scheme_application',10,'',0,'2021-03-27 23:47:47','2021-03-27 23:47:47'),(1962,225,'01531875147','http://localhost:8080/pump-opt-application','far_pump_opt_docs',9,'',0,'2021-03-27 23:48:24','2021-03-27 23:48:24'),(1963,225,'01531875147','http://localhost:8080/pump-opt-application','far_pump_opt_apps',7,'',0,'2021-03-27 23:49:22','2021-03-27 23:49:22'),(1964,225,'01531875147','http://localhost:8080/smart-card-application-form','irrigation_payments',33,'',0,'2021-03-27 23:50:44','2021-03-27 23:50:44'),(1965,225,'01531875147','http://localhost:8080/smart-card-application-form','far_smart_card_apps',4,'',0,'2021-03-27 23:50:44','2021-03-27 23:50:44'),(1966,225,'01531875147','http://localhost:8080/smart-card-application-form','irrigation_payments',34,'',0,'2021-03-27 23:50:55','2021-03-27 23:50:55'),(1967,225,'01531875147','http://localhost:8080/smart-card-application-form','far_smart_card_apps',5,'',0,'2021-03-27 23:50:55','2021-03-27 23:50:55'),(1968,225,'01531875147','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',13,'',0,'2021-03-27 23:51:39','2021-03-27 23:51:39'),(1969,225,'01531875147','http://localhost:8080/water-testing-request-list','irrigation_payments',35,'',0,'2021-03-27 23:51:39','2021-03-27 23:51:39'),(1970,225,'01531875147','http://localhost:8080/farmer-complain','far_complains',19,'',0,'2021-03-27 23:52:06','2021-03-27 23:52:06'),(1971,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-reported','far_water_test_apps',11,'',2,'2021-03-28 05:53:59','2021-03-28 05:53:59'),(1972,224,'01924496004','http://localhost:8080/my-profile-form','far_basic_infos',52,'',1,'2021-03-28 00:01:09','2021-03-28 00:01:09'),(1973,224,'01924496004','http://localhost:8080/my-profile-form','far_basic_infos',53,'',1,'2021-03-28 00:05:02','2021-03-28 00:05:02'),(1974,224,'01924496004','http://localhost:8080/my-profile-form','far_basic_infos',54,'',1,'2021-03-28 00:06:41','2021-03-28 00:06:41'),(1975,224,'01924496004','http://localhost:8080/my-profile-form','far_basic_infos',54,'',1,'2021-03-28 00:15:58','2021-03-28 00:15:58'),(1976,226,'01924496004','http://localhost:8080/my-profile-form','far_basic_infos',55,'',1,'2021-03-28 00:18:32','2021-03-28 00:18:32'),(1977,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list','master_pump_progress_types',3,'',1,'2021-03-28 07:18:08','2021-03-28 07:18:08'),(1978,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list','master_pump_progress_types',3,'',1,'2021-03-28 07:18:20','2021-03-28 07:18:20'),(1979,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list','master_pump_progress_types',11,'',0,'2021-03-28 07:19:09','2021-03-28 07:19:09'),(1980,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list','master_pump_progress_types',11,'',1,'2021-03-28 07:19:21','2021-03-28 07:19:21'),(1981,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',18,'',0,'2021-03-28 07:20:01','2021-03-28 07:20:01'),(1982,110,'01924496004','http://localhost:8080/my-profile-form','far_basic_infos',56,'',1,'2021-03-28 02:07:23','2021-03-28 02:07:23'),(1983,12,'01843867772','http://localhost:8080/my-profile-form','far_basic_infos',4,'',1,'2021-03-28 08:46:22','2021-03-28 08:46:22'),(1984,74,'sumanadmin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_requisitions',6,'',0,'2021-03-28 08:47:21','2021-03-28 08:47:21'),(1985,202,'01730233032','http://localhost:8080/my-profile-form','far_basic_infos',45,'',1,'2021-03-28 08:52:20','2021-03-28 08:52:20'),(1986,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pump_operators',59,'',0,'2021-03-28 08:55:17','2021-03-28 08:55:17'),(1987,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',3,'',2,'2021-03-28 08:55:17','2021-03-28 08:55:17'),(1988,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_app_reniews',1,'',0,'2021-03-28 09:09:06','2021-03-28 09:09:06'),(1989,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_apps',8,'',0,'2021-03-28 09:09:06','2021-03-28 09:09:06'),(1990,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',15,'',0,'2021-03-28 09:23:02','2021-03-28 09:23:02'),(1991,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_app_reniews',2,'',0,'2021-03-28 09:28:06','2021-03-28 09:28:06'),(1992,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_apps',9,'',0,'2021-03-28 09:28:06','2021-03-28 09:28:06'),(1993,202,'01730233032','http://localhost:8080/pump-operator-application','irrigation_payments',36,'',0,'2021-03-28 09:30:12','2021-03-28 09:30:12'),(1994,202,'01730233032','http://localhost:8080/farmer-complain','far_complains',20,'',0,'2021-03-28 09:31:54','2021-03-28 09:31:54'),(1995,202,'01730233032','http://localhost:8080/farmer-complain','far_complains',21,'',0,'2021-03-28 09:32:09','2021-03-28 09:32:09'),(1996,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_app_reniews',3,'',0,'2021-03-28 09:37:36','2021-03-28 09:37:36'),(1997,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_apps',10,'',0,'2021-03-28 09:37:36','2021-03-28 09:37:36'),(1998,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_app_reniews',4,'',0,'2021-03-28 09:40:16','2021-03-28 09:40:16'),(1999,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_apps',11,'',0,'2021-03-28 09:40:16','2021-03-28 09:40:16'),(2000,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_app_reniews',5,'',0,'2021-03-28 09:43:35','2021-03-28 09:43:35'),(2001,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_apps',12,'',0,'2021-03-28 09:43:35','2021-03-28 09:43:35'),(2002,1,'admin','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complains',21,'',1,'2021-03-28 09:43:44','2021-03-28 09:43:44'),(2003,1,'admin','http://localhost:8080/irrigation/pump-maintenance/complain-list','far_complain_resolves',5,'',0,'2021-03-28 09:44:17','2021-03-28 09:44:17'),(2004,74,'sumanadmin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_approvals',2,'',0,'2021-03-28 09:52:45','2021-03-28 09:52:45'),(2005,74,'sumanadmin','http://localhost:8080/irrigation/pump-maintenance/maintenance-task','far_complain_requisitions',6,'',1,'2021-03-28 09:52:45','2021-03-28 09:52:45'),(2006,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_app_reniews',6,'',0,'2021-03-28 10:41:06','2021-03-28 10:41:06'),(2007,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_apps',13,'',0,'2021-03-28 10:41:06','2021-03-28 10:41:06'),(2008,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_app_reniews',7,'',0,'2021-03-28 10:41:06','2021-03-28 10:41:06'),(2009,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_apps',14,'',0,'2021-03-28 10:41:06','2021-03-28 10:41:06'),(2010,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_app_reniews',8,'',0,'2021-03-28 10:55:04','2021-03-28 10:55:04'),(2011,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_apps',15,'',0,'2021-03-28 10:55:04','2021-03-28 10:55:04'),(2012,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_app_reniews',9,'',0,'2021-03-28 11:18:03','2021-03-28 11:18:03'),(2013,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_apps',16,'',0,'2021-03-28 11:18:03','2021-03-28 11:18:03'),(2014,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_app_reniews',10,'',0,'2021-03-28 11:19:51','2021-03-28 11:19:51'),(2015,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_apps',17,'',0,'2021-03-28 11:19:51','2021-03-28 11:19:51'),(2016,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_app_reniews',11,'',0,'2021-03-28 11:20:24','2021-03-28 11:20:24'),(2017,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_apps',18,'',0,'2021-03-28 11:20:24','2021-03-28 11:20:24'),(2018,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_app_reniews',12,'',0,'2021-03-28 11:24:36','2021-03-28 11:24:36'),(2019,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_apps',19,'',0,'2021-03-28 11:24:36','2021-03-28 11:24:36'),(2020,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',16,'',0,'2021-03-28 11:56:13','2021-03-28 11:56:13'),(2021,202,'01730233032','http://localhost:8080/pump-operator-application','irrigation_payments',37,'',0,'2021-03-28 11:58:44','2021-03-28 11:58:44'),(2022,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',19,'',0,'2021-03-28 12:02:26','2021-03-28 12:02:26'),(2023,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_app_reniews',13,'',0,'2021-03-28 12:21:04','2021-03-28 12:21:04'),(2024,202,'01730233032','http://localhost:8080/pump-opt-renew/3','far_pump_opt_apps',20,'',0,'2021-03-28 12:21:04','2021-03-28 12:21:04'),(2025,202,'01730233032','http://localhost:8080/pump-operator-application','irrigation_payments',38,'',0,'2021-03-28 12:21:10','2021-03-28 12:21:10'),(2026,202,'01730233032','http://localhost:8080/pump-operator-application','irrigation_payments',39,'',0,'2021-03-28 12:21:18','2021-03-28 12:21:18'),(2027,202,'01730233032','http://localhost:8080/pump-operator-application','irrigation_payments',40,'',0,'2021-03-28 12:25:21','2021-03-28 12:25:21'),(2028,112,'01733322220','http://localhost:8080/my-profile-form','far_basic_infos',57,'',1,'2021-03-28 12:26:54','2021-03-28 12:26:54'),(2029,112,'01733322220','http://localhost:8080/pump-opt-application','far_pump_opt_apps',21,'',0,'2021-03-28 12:27:25','2021-03-28 12:27:25'),(2030,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',17,'',0,'2021-03-28 12:31:16','2021-03-28 12:31:16'),(2031,112,'01733322220','http://localhost:8080/pump-operator-application','irrigation_payments',41,'',0,'2021-03-28 12:31:51','2021-03-28 12:31:51'),(2032,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',21,'',0,'2021-03-28 12:34:25','2021-03-28 12:34:25'),(2033,113,'01733322221','http://localhost:8080/my-profile-form','far_basic_infos',58,'',1,'2021-03-29 04:26:08','2021-03-29 04:26:08'),(2034,113,'01733322221','http://localhost:8080/pump-opt-application','far_pump_opt_apps',22,'',0,'2021-03-29 04:26:42','2021-03-29 04:26:42'),(2035,113,'01733322221','http://localhost:8080/pump-operator-application','irrigation_payments',42,'',0,'2021-03-29 04:26:50','2021-03-29 04:26:50'),(2036,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',22,'',0,'2021-03-29 04:30:27','2021-03-29 04:30:27'),(2037,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-app-survey','pump_opt_apps_surveys',2,'',0,'2021-03-29 04:30:40','2021-03-29 04:30:40'),(2038,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pump_operators',60,'',0,'2021-03-29 04:31:16','2021-03-29 04:31:16'),(2039,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',22,'',2,'2021-03-29 04:31:17','2021-03-29 04:31:17'),(2040,113,'01733322221','http://localhost:8080/pump-opt-renew/22','far_pump_opt_app_reniews',14,'',0,'2021-03-29 04:32:23','2021-03-29 04:32:23'),(2041,113,'01733322221','http://localhost:8080/pump-opt-renew/22','far_pump_opt_apps',23,'',0,'2021-03-29 04:32:23','2021-03-29 04:32:23'),(2042,113,'01733322221','http://localhost:8080/pump-operator-application','irrigation_payments',43,'',0,'2021-03-29 04:32:29','2021-03-29 04:32:29'),(2043,226,'01924496004','http://localhost:8080/smart-card-application-form','irrigation_payments',44,'',0,'2021-03-28 22:36:19','2021-03-28 22:36:19'),(2044,226,'01924496004','http://localhost:8080/smart-card-application-form','far_smart_card_apps',6,'',0,'2021-03-28 22:36:20','2021-03-28 22:36:20'),(2045,226,'01924496004','http://localhost:8080/smart-card-application-form','irrigation_payments',45,'',0,'2021-03-28 22:36:25','2021-03-28 22:36:25'),(2046,226,'01924496004','http://localhost:8080/smart-card-application-form','far_smart_card_apps',7,'',0,'2021-03-28 22:36:25','2021-03-28 22:36:25'),(2047,114,'01733322222','http://localhost:8080/my-profile-form','far_basic_infos',59,'',1,'2021-03-29 04:41:12','2021-03-29 04:41:12'),(2048,114,'01733322222','http://localhost:8080/pump-opt-application','far_pump_opt_apps',24,'',0,'2021-03-29 04:41:42','2021-03-29 04:41:42'),(2049,114,'01733322222','http://localhost:8080/pump-operator-application','irrigation_payments',46,'',0,'2021-03-29 04:41:51','2021-03-29 04:41:51'),(2050,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',23,'',0,'2021-03-29 04:43:07','2021-03-29 04:43:07'),(2051,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-app-survey','pump_opt_apps_surveys',3,'',0,'2021-03-29 04:43:42','2021-03-29 04:43:42'),(2052,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pump_operators',61,'',0,'2021-03-29 05:04:34','2021-03-29 05:04:34'),(2053,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',24,'',2,'2021-03-29 05:04:34','2021-03-29 05:04:34'),(2054,114,'01733322222','http://localhost:8080/pump-operator-application','irrigation_payments',47,'',0,'2021-03-29 05:05:14','2021-03-29 05:05:14'),(2055,114,'01733322222','http://localhost:8080/pump-opt-renew/24','far_pump_opt_app_reniews',15,'',0,'2021-03-29 05:05:52','2021-03-29 05:05:52'),(2056,114,'01733322222','http://localhost:8080/pump-opt-renew/24','far_pump_opt_apps',25,'',0,'2021-03-29 05:05:52','2021-03-29 05:05:52'),(2057,114,'01733322222','http://localhost:8080/pump-operator-application','irrigation_payments',48,'',0,'2021-03-29 05:06:43','2021-03-29 05:06:43'),(2058,114,'01733322222','http://localhost:8080/farmer-complain','far_complains',22,'',0,'2021-03-29 05:07:54','2021-03-29 05:07:54'),(2059,112,'01733322220','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',3,'',1,'2021-03-29 09:05:57','2021-03-29 09:05:57'),(2060,1,'admin','http://localhost:8080/irrigation/pump-maintenance/directory','master_item_sub_categories',1,'',1,'2021-03-29 10:24:14','2021-03-29 10:24:14'),(2061,1,'admin','http://localhost:8080/irrigation/card-payment/new-application','far_smart_card_apps',1,'',2,'2021-03-31 05:43:18','2021-03-31 05:43:18'),(2062,1,'admin','http://localhost:8080/irrigation/card-payment/generate-card','far_smart_card_apps',1,'',2,'2021-03-31 05:43:31','2021-03-31 05:43:31'),(2063,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',3,'',1,'2021-03-31 07:54:50','2021-03-31 07:54:50'),(2064,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',4,'',1,'2021-03-31 07:56:10','2021-03-31 07:56:10'),(2065,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',6,'',1,'2021-03-31 07:57:26','2021-03-31 07:57:26'),(2066,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',7,'',1,'2021-03-31 07:57:52','2021-03-31 07:57:52'),(2067,248,'01754019430','http://localhost:8080/my-profile-form','far_basic_infos',60,'',1,'2021-04-10 22:53:33','2021-04-10 22:53:33'),(2068,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-type-list','master_scheme_types',9,'',0,'2021-04-10 22:59:31','2021-04-10 22:59:31'),(2069,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list','master_scheme_types',5,'',0,'2021-04-10 23:00:26','2021-04-10 23:00:26'),(2070,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list#','master_scheme_types',5,'',1,'2021-04-10 23:05:52','2021-04-10 23:05:52'),(2071,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',42,'',0,'2021-04-10 23:24:59','2021-04-10 23:24:59'),(2072,248,'01754019430','http://localhost:8080/pump-opt-application','far_pump_opt_docs',11,'',0,'2021-04-10 23:27:59','2021-04-10 23:27:59'),(2073,248,'01754019430','http://localhost:8080/pump-opt-application','far_pump_opt_docs',12,'',0,'2021-04-10 23:28:12','2021-04-10 23:28:12'),(2074,248,'01754019430','http://localhost:8080/pump-opt-application','far_pump_opt_docs',13,'',0,'2021-04-10 23:28:19','2021-04-10 23:28:19'),(2075,248,'01754019430','http://localhost:8080/pump-opt-application','far_pump_opt_apps',26,'',0,'2021-04-10 23:28:30','2021-04-10 23:28:30'),(2076,248,'01754019430','http://localhost:8080/pump-opt-application/26','far_pump_opt_apps',26,'',1,'2021-04-10 23:29:42','2021-04-10 23:29:42'),(2077,248,'01754019430','http://localhost:8080/pump-opt-application/26','far_pump_opt_apps',26,'',1,'2021-04-10 23:30:20','2021-04-10 23:30:20'),(2078,248,'01754019430','http://localhost:8080/pump-operator-application','irrigation_payments',49,'',0,'2021-04-10 23:32:38','2021-04-10 23:32:38'),(2079,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','pump_informations',42,'',1,'2021-04-10 23:40:52','2021-04-10 23:40:52'),(2080,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','farmer_land_details',26,'',0,'2021-04-10 23:41:58','2021-04-10 23:41:58'),(2081,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','farmer_land_details',27,'',0,'2021-04-10 23:42:52','2021-04-10 23:42:52'),(2082,1,'admin','http://localhost:8080/irrigation/pump-information/pump-info-list','farmer_land_details',28,'',0,'2021-04-10 23:43:34','2021-04-10 23:43:34'),(2083,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',24,'',0,'2021-04-11 00:33:19','2021-04-11 00:33:19'),(2084,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/water-testing-parameter','water_testing_parameters',5,'',1,'2021-04-11 00:55:47','2021-04-11 00:55:47'),(2085,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',18,'',0,'2021-04-11 01:11:36','2021-04-11 01:11:36'),(2086,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',18,'',1,'2021-04-11 01:12:42','2021-04-11 01:12:42'),(2087,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',18,'',1,'2021-04-11 01:13:28','2021-04-11 01:13:28'),(2088,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payment_types',1,'',2,'2021-04-11 01:14:23','2021-04-11 01:14:23'),(2089,248,'01754019430','http://localhost:8080/water-testing-request-list','far_pump_opt_rejects',14,'',0,'2021-04-11 01:23:02','2021-04-11 01:23:02'),(2090,248,'01754019430','http://localhost:8080/water-testing-request-list','irrigation_payments',50,'',0,'2021-04-11 01:23:04','2021-04-11 01:23:04'),(2091,248,'01754019430','http://localhost:8080/water-testing-request-list','pump_operators',14,'',1,'2021-04-11 01:23:48','2021-04-11 01:23:48'),(2092,12,'01843867772','http://localhost:8080/scheme-application','farmer_land_details',29,'',0,'2021-04-11 08:46:54','2021-04-11 08:46:54'),(2093,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_scheme_application',26,'',1,'2021-04-11 03:00:34','2021-04-11 03:00:34'),(2094,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_rejects',1,'',0,'2021-04-11 03:00:34','2021-04-11 03:00:34'),(2095,248,'01754019430','http://localhost:8080/pump-opt-application/26','far_pump_opt_apps',26,'',2,'2021-04-11 03:01:05','2021-04-11 03:01:05'),(2096,248,'01754019430','http://localhost:8080/pump-opt-application/26','far_pump_opt_apps',26,'',2,'2021-04-11 03:01:14','2021-04-11 03:01:14'),(2097,248,'01754019430','http://localhost:8080/pump-opt-application/26','far_pump_opt_docs',13,'',2,'2021-04-11 03:01:32','2021-04-11 03:01:32'),(2098,248,'01754019430','http://localhost:8080/pump-opt-application/26','far_pump_opt_docs',12,'',2,'2021-04-11 03:01:37','2021-04-11 03:01:37'),(2099,248,'01754019430','http://localhost:8080/pump-opt-application/26','far_pump_opt_docs',11,'',2,'2021-04-11 03:01:38','2021-04-11 03:01:38'),(2100,248,'01754019430','http://localhost:8080/pump-opt-application/26','far_pump_opt_apps',26,'',2,'2021-04-11 03:01:45','2021-04-11 03:01:45'),(2101,248,'01754019430','http://localhost:8080/pump-opt-application/26','far_pump_opt_apps',26,'',1,'2021-04-11 03:02:38','2021-04-11 03:02:38'),(2102,248,'01754019430','http://localhost:8080/pump-operator-application','irrigation_payments',51,'',0,'2021-04-11 03:03:51','2021-04-11 03:03:51'),(2103,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',25,'',0,'2021-04-11 03:05:39','2021-04-11 03:05:39'),(2104,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_scheme_application',26,'',1,'2021-04-11 03:15:11','2021-04-11 03:15:11'),(2105,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_rejects',2,'',0,'2021-04-11 03:15:11','2021-04-11 03:15:11'),(2106,248,'01754019430','http://localhost:8080/pump-opt-application/26','far_pump_opt_apps',26,'',2,'2021-04-11 03:16:04','2021-04-11 03:16:04'),(2107,248,'01754019430','http://localhost:8080/pump-opt-application/26','far_pump_opt_apps',26,'',2,'2021-04-11 03:16:12','2021-04-11 03:16:12'),(2108,248,'01754019430','http://localhost:8080/pump-operator-application','irrigation_payments',52,'',0,'2021-04-11 03:16:43','2021-04-11 03:16:43'),(2109,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',26,'',0,'2021-04-11 03:17:04','2021-04-11 03:17:04'),(2110,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_scheme_application',26,'',1,'2021-04-11 03:21:45','2021-04-11 03:21:45'),(2111,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_rejects',3,'',0,'2021-04-11 03:21:45','2021-04-11 03:21:45'),(2112,248,'01754019430','http://localhost:8080/pump-opt-application/26','far_pump_opt_apps',26,'',2,'2021-04-11 03:22:00','2021-04-11 03:22:00'),(2113,248,'01754019430','http://localhost:8080/pump-opt-application/26','far_pump_opt_apps',26,'',2,'2021-04-11 03:22:03','2021-04-11 03:22:03'),(2114,248,'01754019430','http://localhost:8080/pump-operator-application','irrigation_payments',53,'',0,'2021-04-11 03:22:28','2021-04-11 03:22:28'),(2115,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',27,'',0,'2021-04-11 03:22:55','2021-04-11 03:22:55'),(2116,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_scheme_application',26,'',1,'2021-04-11 03:25:11','2021-04-11 03:25:11'),(2117,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_rejects',4,'',0,'2021-04-11 03:25:11','2021-04-11 03:25:11'),(2118,248,'01754019430','http://localhost:8080/pump-opt-application/26','far_pump_opt_apps',26,'',2,'2021-04-11 03:25:28','2021-04-11 03:25:28'),(2119,248,'01754019430','http://localhost:8080/pump-operator-application','irrigation_payments',54,'',0,'2021-04-11 03:26:15','2021-04-11 03:26:15'),(2120,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pum_opt_apps_approvals',28,'',0,'2021-04-11 03:26:37','2021-04-11 03:26:37'),(2121,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-opt-app-survey','pump_opt_apps_surveys',4,'',0,'2021-04-11 03:28:48','2021-04-11 03:28:48'),(2122,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','pump_operators',62,'',0,'2021-04-11 03:30:28','2021-04-11 03:30:28'),(2123,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/pump-operator-application-list','far_pump_opt_apps',26,'',2,'2021-04-11 03:30:28','2021-04-11 03:30:28'),(2124,248,'01754019430','http://localhost:8080/pump-operator-application','irrigation_payments',55,'',0,'2021-04-11 03:53:02','2021-04-11 03:53:02'),(2125,132,'01620656565','http://localhost:8080/my-profile-form','far_basic_infos',61,'',1,'2021-04-11 04:22:25','2021-04-11 04:22:25'),(2126,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',19,'',0,'2021-04-11 04:24:19','2021-04-11 04:24:19'),(2127,98,'01620506565','http://localhost:8080/my-profile-form','far_basic_infos',62,'',1,'2021-04-11 04:25:39','2021-04-11 04:25:39'),(2128,1,'admin','http://localhost:8080/irrigation/task/task-tracker','task_assign_tasks',19,'',2,'2021-04-11 04:28:29','2021-04-11 04:28:29'),(2129,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',20,'',0,'2021-04-11 04:30:36','2021-04-11 04:30:36'),(2130,1,'admin','http://localhost:8080/irrigation/task/task-tracker','task_review_notes',6,'',0,'2021-04-11 04:31:56','2021-04-11 04:31:56'),(2131,1,'admin','http://localhost:8080/irrigation/task/task-tracker','task_assign_tasks',20,'',2,'2021-04-11 04:32:17','2021-04-11 04:32:17'),(2132,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',21,'',0,'2021-04-11 04:36:46','2021-04-11 04:36:46'),(2133,132,'01620656565','http://localhost:8080/my-assign-task','task_task_reports',8,'',0,'2021-04-11 04:53:32','2021-04-11 04:53:32'),(2134,132,'01620656565','http://localhost:8080/my-assign-task','task_task_reports',9,'',0,'2021-04-11 05:09:08','2021-04-11 05:09:08'),(2135,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',6,'',2,'2021-04-11 22:12:23','2021-04-11 22:12:23'),(2136,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',6,'',2,'2021-04-11 22:12:26','2021-04-11 22:12:26'),(2137,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',7,'',0,'2021-04-11 22:13:16','2021-04-11 22:13:16'),(2138,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',8,'',0,'2021-04-11 22:14:29','2021-04-11 22:14:29'),(2139,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',6,'',2,'2021-04-11 22:14:44','2021-04-11 22:14:44'),(2140,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',6,'',2,'2021-04-11 22:15:15','2021-04-11 22:15:15'),(2141,1,'admin','http://localhost:8080/irrigation/task/task-tracker','task_assign_tasks',21,'',2,'2021-04-11 22:19:24','2021-04-11 22:19:24'),(2142,1,'admin','http://localhost:8080/irrigation/task/task-tracker','task_review_notes',7,'',0,'2021-04-11 22:19:36','2021-04-11 22:19:36'),(2143,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',21,'',2,'2021-04-11 22:20:40','2021-04-11 22:20:40'),(2144,1,'admin','http://localhost:8080/irrigation/task/assign-task','task_assign_tasks',21,'',2,'2021-04-11 22:21:32','2021-04-11 22:21:32'),(2145,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-out','pump_stock_out_infos',13,'',0,'2021-04-11 22:37:47','2021-04-11 22:37:47'),(2146,248,'01754019430','http://localhost:8080/smart-card-application-form','irrigation_payments',56,'',0,'2021-04-11 22:44:51','2021-04-11 22:44:51'),(2147,248,'01754019430','http://localhost:8080/smart-card-application-form','far_smart_card_apps',8,'',0,'2021-04-11 22:44:51','2021-04-11 22:44:51'),(2148,248,'01754019430','http://localhost:8080/smart-card-application-form','irrigation_payments',57,'',0,'2021-04-11 22:45:21','2021-04-11 22:45:21'),(2149,248,'01754019430','http://localhost:8080/smart-card-application-form','far_smart_card_apps',9,'',0,'2021-04-11 22:45:21','2021-04-11 22:45:21'),(2150,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',6,'',2,'2021-04-11 23:22:40','2021-04-11 23:22:40'),(2151,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/stock-in','pump_stock_in_infos',6,'',2,'2021-04-11 23:23:01','2021-04-11 23:23:01'),(2152,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',14,'',0,'2021-04-11 23:37:32','2021-04-11 23:37:32'),(2153,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',14,'',1,'2021-04-11 23:37:49','2021-04-11 23:37:49'),(2154,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',14,'',2,'2021-04-11 23:37:57','2021-04-11 23:37:57'),(2155,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/project-entry-list','master_projects',14,'',2,'2021-04-11 23:38:02','2021-04-11 23:38:02'),(2156,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',1,'',1,'2021-04-12 01:03:28','2021-04-12 01:03:28'),(2157,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',5,'',1,'2021-04-12 01:03:39','2021-04-12 01:03:39'),(2158,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',4,'',2,'2021-04-12 01:03:47','2021-04-12 01:03:47'),(2159,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',1,'',2,'2021-04-12 01:04:08','2021-04-12 01:04:08'),(2160,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',1,'',2,'2021-04-12 01:04:22','2021-04-12 01:04:22'),(2161,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',1,'',2,'2021-04-12 01:04:44','2021-04-12 01:04:44'),(2162,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',1,'',2,'2021-04-12 01:04:49','2021-04-12 01:04:49'),(2163,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',1,'',2,'2021-04-12 01:04:53','2021-04-12 01:04:53'),(2164,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',1,'',1,'2021-04-12 01:04:59','2021-04-12 01:04:59'),(2165,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',1,'',2,'2021-04-12 01:05:04','2021-04-12 01:05:04'),(2166,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',1,'',2,'2021-04-12 01:05:07','2021-04-12 01:05:07'),(2167,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',1,'',2,'2021-04-12 01:05:10','2021-04-12 01:05:10'),(2168,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',14,'',0,'2021-04-12 01:08:34','2021-04-12 01:08:34'),(2169,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',2,'',1,'2021-04-12 01:13:45','2021-04-12 01:13:45'),(2170,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',3,'',1,'2021-04-12 01:14:03','2021-04-12 01:14:03'),(2171,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',11,'',1,'2021-04-12 01:15:20','2021-04-12 01:15:20'),(2172,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',1,'',2,'2021-04-12 01:16:04','2021-04-12 01:16:04'),(2173,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',12,'',1,'2021-04-12 01:16:49','2021-04-12 01:16:49'),(2174,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',4,'',2,'2021-04-12 02:47:52','2021-04-12 02:47:52'),(2175,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',4,'',2,'2021-04-12 02:47:56','2021-04-12 02:47:56'),(2176,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',4,'',2,'2021-04-12 02:47:59','2021-04-12 02:47:59'),(2177,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/circle-area-list','master_circle_areas',4,'',2,'2021-04-12 02:48:02','2021-04-12 02:48:02'),(2178,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/contractor-list','master_contractors',1,'',1,'2021-04-12 02:49:51','2021-04-12 02:49:51'),(2179,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/contractor-list','master_contractors',4,'',2,'2021-04-12 02:50:44','2021-04-12 02:50:44'),(2180,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/contractor-list','master_contractors',4,'',2,'2021-04-12 02:50:48','2021-04-12 02:50:48'),(2181,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/scheme-form-affidavit-list','master_scheme_affidavits',1,'',1,'2021-04-12 02:52:12','2021-04-12 02:52:12'),(2182,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/item-category-list','master_item_categories',1,'',2,'2021-04-12 02:54:11','2021-04-12 02:54:11'),(2183,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/item-category-list','master_item_categories',1,'',2,'2021-04-12 02:54:15','2021-04-12 02:54:15'),(2184,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/item-category-list#','master_item_categories',3,'',1,'2021-04-12 02:57:56','2021-04-12 02:57:56'),(2185,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/item-category-list#','master_item_categories',4,'',1,'2021-04-12 02:58:13','2021-04-12 02:58:13'),(2186,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/item-category-list#','master_item_categories',1,'',2,'2021-04-12 02:58:54','2021-04-12 02:58:54'),(2187,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/item-category-list#','master_item_categories',1,'',2,'2021-04-12 02:58:58','2021-04-12 02:58:58'),(2188,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/item-category-list#','master_item_categories',1,'',1,'2021-04-12 02:59:02','2021-04-12 02:59:02'),(2189,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/item-category-list#','master_item_categories',6,'',0,'2021-04-12 02:59:49','2021-04-12 02:59:49'),(2190,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/store-item-list#','master_items',1,'',1,'2021-04-12 03:01:50','2021-04-12 03:01:50'),(2191,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/store-item-list','master_items',1,'',1,'2021-04-12 03:03:29','2021-04-12 03:03:29'),(2192,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-type-list','master_pump_types',5,'',0,'2021-04-12 03:07:01','2021-04-12 03:07:01'),(2193,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list','master_pump_progress_types',12,'',0,'2021-04-12 03:10:14','2021-04-12 03:10:14'),(2194,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list#','master_pump_progress_types',12,'',1,'2021-04-12 03:11:16','2021-04-12 03:11:16'),(2195,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list#','master_pump_progress_types',3,'',1,'2021-04-12 03:14:25','2021-04-12 03:14:25'),(2196,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list#','master_pump_progress_types',3,'',2,'2021-04-12 03:19:23','2021-04-12 03:19:23'),(2197,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/pump-installation-progress-type-list#','master_pump_progress_types',3,'',2,'2021-04-12 03:19:27','2021-04-12 03:19:27'),(2198,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list','master_laboratories',1,'',1,'2021-04-12 03:21:01','2021-04-12 03:21:01'),(2199,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list','master_laboratories',1,'',1,'2021-04-12 03:21:12','2021-04-12 03:21:12'),(2200,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list','master_laboratories',21,'',0,'2021-04-12 03:23:59','2021-04-12 03:23:59'),(2201,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list','master_laboratories',21,'',1,'2021-04-12 03:24:09','2021-04-12 03:24:09'),(2202,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',20,'',1,'2021-04-12 03:24:47','2021-04-12 03:24:47'),(2203,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',21,'',2,'2021-04-12 03:24:53','2021-04-12 03:24:53'),(2204,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',21,'',2,'2021-04-12 03:24:59','2021-04-12 03:24:59'),(2205,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',21,'',2,'2021-04-12 03:25:02','2021-04-12 03:25:02'),(2206,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',20,'',2,'2021-04-12 03:25:08','2021-04-12 03:25:08'),(2207,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',20,'',2,'2021-04-12 03:25:11','2021-04-12 03:25:11'),(2208,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',20,'',2,'2021-04-12 03:25:16','2021-04-12 03:25:16'),(2209,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',20,'',2,'2021-04-12 03:25:21','2021-04-12 03:25:21'),(2210,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',20,'',2,'2021-04-12 03:25:24','2021-04-12 03:25:24'),(2211,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',20,'',2,'2021-04-12 03:25:29','2021-04-12 03:25:29'),(2212,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',20,'',2,'2021-04-12 03:25:32','2021-04-12 03:25:32'),(2213,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',20,'',2,'2021-04-12 03:25:35','2021-04-12 03:25:35'),(2214,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',20,'',2,'2021-04-12 03:25:38','2021-04-12 03:25:38'),(2215,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',20,'',2,'2021-04-12 03:25:41','2021-04-12 03:25:41'),(2216,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',20,'',2,'2021-04-12 03:25:44','2021-04-12 03:25:44'),(2217,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',21,'',2,'2021-04-12 03:25:52','2021-04-12 03:25:52'),(2218,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',21,'',2,'2021-04-12 03:25:55','2021-04-12 03:25:55'),(2219,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/laboratory-list#','master_laboratories',21,'',2,'2021-04-12 03:26:16','2021-04-12 03:26:16'),(2220,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/report-heading-list','master_report_headers',2,'',1,'2021-04-12 03:28:42','2021-04-12 03:28:42'),(2221,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/equipment-type-list','master_equipment_types',1,'',1,'2021-04-12 03:38:06','2021-04-12 03:38:06'),(2222,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/equipment-type-list#','master_equipment_types',1,'',1,'2021-04-12 03:39:18','2021-04-12 03:39:18'),(2223,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list','master_scheme_types',6,'',0,'2021-04-12 03:47:06','2021-04-12 03:47:06'),(2224,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list','master_scheme_types',7,'',0,'2021-04-12 03:47:30','2021-04-12 03:47:30'),(2225,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list','master_scheme_types',8,'',0,'2021-04-12 03:47:38','2021-04-12 03:47:38'),(2226,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list','master_scheme_types',9,'',0,'2021-04-12 03:47:46','2021-04-12 03:47:46'),(2227,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list','master_scheme_types',10,'',0,'2021-04-12 03:48:48','2021-04-12 03:48:48'),(2228,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/sub-scheme-type-list','master_scheme_types',11,'',0,'2021-04-12 03:48:59','2021-04-12 03:48:59'),(2229,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',18,'',1,'2021-04-12 04:44:00','2021-04-12 04:44:00'),(2230,248,'01754019430','http://localhost:8080/scheme-application-submit','far_scheme_application',11,'',0,'2021-04-13 00:04:47','2021-04-13 00:04:47'),(2231,1,'admin','http://localhost:8080/irrigation-scheme-service/configuration/payment','master_payments',3,'',1,'2021-04-13 03:08:00','2021-04-13 03:08:00'),(2232,248,'01754019430','http://localhost:8080/scheme-application','irrigation_payments',58,'',0,'2021-04-13 03:09:22','2021-04-13 03:09:22'),(2233,1,'admin','http://localhost:8080/irrigation/water-testing/water-testing-reported','far_water_test_apps',10,'',2,'2021-04-13 03:19:11','2021-04-13 03:19:11'),(2234,248,'01754019430','http://localhost:8080/scheme-application','farmer_land_details',30,'',0,'2021-04-13 04:09:48','2021-04-13 04:09:48'),(2235,248,'01754019430','http://localhost:8080/scheme-application','farmer_land_details',31,'',0,'2021-04-13 04:10:30','2021-04-13 04:10:30'),(2236,248,'01754019430','http://localhost:8080/scheme-application','farmer_land_details',32,'',0,'2021-04-13 04:11:39','2021-04-13 04:11:39'),(2237,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_projects',21,'',0,'2021-04-13 04:27:55','2021-04-13 04:27:55'),(2238,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',11,'',1,'2021-04-13 04:27:55','2021-04-13 04:27:55'),(2239,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_application',11,'',1,'2021-04-13 04:31:10','2021-04-13 04:31:10'),(2240,1,'admin','http://localhost:8080/irrigation-scheme-service/pump-installation/application-list','far_scheme_reviews',2,'',0,'2021-04-13 04:31:10','2021-04-13 04:31:10'),(2241,12,'01843867772','http://localhost:8080/pump-opt-application','far_pump_opt_docs',14,'',0,'2021-04-13 10:32:16','2021-04-13 10:32:16'),(2242,12,'01843867772','http://localhost:8080/pump-opt-application','far_pump_opt_docs',15,'',0,'2021-04-13 10:32:27','2021-04-13 10:32:27');
/*!40000 ALTER TABLE `user_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `water_testing_parameters`
--

DROP TABLE IF EXISTS `water_testing_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `water_testing_parameters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name_bn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `org_id` bigint(20) unsigned NOT NULL,
  `testing_type_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=active, 1=inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `water_testing_parameters`
--

LOCK TABLES `water_testing_parameters` WRITE;
/*!40000 ALTER TABLE `water_testing_parameters` DISABLE KEYS */;
INSERT INTO `water_testing_parameters` VALUES (5,'Drinking water 1','Drinking water 1 Bn',3,1,1,1,0,'2021-03-18 11:44:15','2021-03-23 03:40:28'),(6,'irrigation water param','irrigation water param Bn',3,2,1,1,0,'2021-03-18 11:44:25','2021-03-23 03:41:28'),(7,'Indurstrial','Indurstrial bn',3,3,1,1,0,'2021-03-23 03:35:42','2021-03-23 03:35:42'),(8,'drinking 2','drinking 2 Bn',3,1,1,1,0,'2021-03-23 03:42:11','2021-03-23 03:42:11'),(9,'Drinking 3','Drinking 3 Bn',3,1,1,1,0,'2021-03-23 03:42:27','2021-03-23 03:42:27'),(10,'123','3',15,1,212,212,0,'2021-03-24 03:28:05','2021-03-24 03:28:05'),(11,'sss','sss',15,1,1,1,0,'2021-03-25 01:06:32','2021-03-25 01:06:32'),(12,'sumon','sumon',15,3,1,1,0,'2021-03-25 01:18:11','2021-03-25 01:18:11'),(13,'no','no',3,1,1,1,0,'2021-03-25 01:19:56','2021-03-25 01:19:56'),(14,'never','never',3,1,1,1,0,'2021-03-25 01:20:31','2021-03-25 01:20:31'),(15,'ruhul','ruhul',3,1,1,1,0,'2021-03-25 01:21:31','2021-03-25 01:21:31'),(16,'rana','rana',3,1,1,1,0,'2021-03-25 01:22:32','2021-03-25 01:22:32'),(17,'fff','fff',15,1,1,1,0,'2021-03-25 09:15:33','2021-03-25 09:15:33'),(18,'dddd','ddd',3,1,1,1,0,'2021-03-28 07:20:01','2021-03-28 07:20:01'),(19,'BMDA Drinking Water','BMDA Drinking Water',15,1,1,1,0,'2021-03-28 12:02:26','2021-03-28 12:02:26');
/*!40000 ALTER TABLE `water_testing_parameters` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-14  1:04:29
